import express from 'express';
import type { Request, Response } from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { getCanonicalUrl, injectCanonicalTag } from './src/utils/canonicalUrl.ts';
import { renderHtmlWithSeo } from './src/utils/seoData.ts';

dotenv.config();

const app = express();

app.use(express.json());

// Helper to get initialized Gemini client
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.trim() === '' || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Helper to execute generation with automatic model fallback during peak traffic
async function generateWithFallback(ai: GoogleGenAI, config: any) {
  const models = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-3.1-flash-lite'];
  let lastError: any = null;

  for (const model of models) {
    try {
      const response = await ai.models.generateContent({
        ...config,
        model,
      });
      return { response, modelUsed: model };
    } catch (err: any) {
      lastError = err;
      console.warn(`Model ${model} encountered an issue, trying fallback:`, err.message);
    }
  }

  throw lastError;
}

// Health & Gemini Configuration Status Check
app.get('/api/gemini-status', (_req: Request, res: Response) => {
  const apiKey = process.env.GEMINI_API_KEY;
  const isConfigured = Boolean(apiKey && apiKey.trim() !== '' && apiKey !== 'MY_GEMINI_API_KEY');
  res.json({
    configured: isConfigured,
    model: 'gemini-2.5-flash',
  });
});

// 1. AI Proposal Generator Endpoint
app.post('/api/generate-proposal', async (req: Request, res: Response) => {
  try {
    const { jobTitle, clientRequirements, yourSkills, experience, projectBudget, tone } = req.body;

    if (!jobTitle || !clientRequirements) {
      res.status(400).json({ error: 'Job title and client requirements are required.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please add your key in the AI Studio Secrets panel.',
        code: 'MISSING_API_KEY',
      });
      return;
    }

    const prompt = `You are an elite freelance business consultant and proposal strategist.
Draft a winning, highly customized freelance client proposal for the following project:

- Job Title: ${jobTitle}
- Client Brief / Requirements: ${clientRequirements}
- Freelancer Skills: ${yourSkills || 'Full-stack specialist'}
- Relevant Proof & Experience: ${experience || 'Extensive production experience'}
- Proposed Investment / Budget: ${projectBudget || 'Competitive milestone pricing'}
- Requested Tone: ${tone || 'Professional'}

Requirements:
1. Address the client's actual pain points directly in the first two sentences.
2. Outline a clear 4-step milestone roadmap.
3. Keep the tone strictly ${tone}.
4. Conclude with a strong, low-friction call-to-action to schedule a brief discovery call.
5. Do NOT include markdown code blocks wrapping the entire proposal (no \`\`\`markdown). Return pristine, formatted text.`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        temperature: 0.7,
      },
    });

    const proposal = response.text?.trim() || '';
    if (!proposal) {
      throw new Error('Gemini returned an empty proposal response.');
    }

    res.json({
      success: true,
      proposal,
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error generating proposal with Gemini:', error);
    res.status(500).json({
      error: error.message || 'An error occurred while communicating with Gemini API.',
      code: 'GEMINI_API_ERROR',
    });
  }
});

// 2. Amazon Keyword Generator Endpoint
app.post('/api/generate-keywords', async (req: Request, res: Response) => {
  try {
    const { productName, productCategory, mainFeatures, targetMarket } = req.body;

    if (!productName) {
      res.status(400).json({ error: 'Product name is required.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please add your key in the AI Studio Secrets panel.',
        code: 'MISSING_API_KEY',
      });
      return;
    }

    const prompt = `You are a top Amazon SEO & PPC optimization expert.
Generate high-converting long-tail keyword ideas, buyer search queries, and backend search terms for the following Amazon listing:

- Product Name: ${productName}
- Category: ${productCategory || 'General Merchandise'}
- Key Features / Specifications: ${mainFeatures || 'High durability, premium quality'}
- Target Market / Audience: ${targetMarket || 'Online Amazon shoppers'}

Generate between 12 and 16 highly relevant keyword clusters. Categorize each into:
- 'Exact / High Intent'
- 'Long-Tail'
- 'Broad Match'
- 'Competitor / Feature'

Assign estimated relevance score (70-99) and search volume category ('Very High', 'High', 'Medium', or 'Trending').
Return clean JSON matching the specified schema.`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            keywords: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  keyword: {
                    type: Type.STRING,
                    description: 'The keyword phrase search term',
                  },
                  type: {
                    type: Type.STRING,
                    description: 'One of: Exact / High Intent, Long-Tail, Broad Match, Competitor / Feature',
                  },
                  searchVolume: {
                    type: Type.STRING,
                    description: 'One of: Very High, High, Medium, Trending',
                  },
                  relevance: {
                    type: Type.INTEGER,
                    description: 'Relevance score from 70 to 99',
                  },
                },
                required: ['keyword', 'type', 'searchVolume', 'relevance'],
              },
            },
          },
          required: ['keywords'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{"keywords":[]}');
    res.json({
      success: true,
      keywords: parsed.keywords || [],
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error generating keywords with Gemini:', error);
    res.status(500).json({
      error: error.message || 'An error occurred while generating keywords with Gemini API.',
      code: 'GEMINI_API_ERROR',
    });
  }
});

// 3. Social Caption Generator Endpoint
app.post('/api/generate-captions', async (req: Request, res: Response) => {
  try {
    const { topic, platform, tone, captionCount } = req.body;

    if (!topic) {
      res.status(400).json({ error: 'Topic is required.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please add your key in the AI Studio Secrets panel.',
        code: 'MISSING_API_KEY',
      });
      return;
    }

    const count = Math.min(Math.max(Number(captionCount) || 3, 1), 5);
    const targetPlatform = platform || 'Instagram';
    const targetTone = tone || 'Educational';

    const prompt = `You are a viral social media strategist.
Create ${count} unique, high-engagement social media captions for ${targetPlatform} with a ${targetTone} tone.

- Topic / Angle: ${topic}
- Platform: ${targetPlatform}
- Tone: ${targetTone}
- Required Count: ${count}

Each caption must include:
1. An irresistible hook (first line) tailored to ${targetPlatform}'s algorithm.
2. Valuable, readable body copy formatted with line breaks suitable for ${targetPlatform}.
3. A high-converting call to action.
4. Curated hashtags (3 to 6 targeted tags).
5. The fullText containing the assembled hook, body, CTA, and hashtags ready to copy.`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            captions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  hook: {
                    type: Type.STRING,
                    description: 'Opening hook line',
                  },
                  body: {
                    type: Type.STRING,
                    description: 'Main body copy',
                  },
                  callToAction: {
                    type: Type.STRING,
                    description: 'Call to action text',
                  },
                  hashtags: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'List of hashtags with # symbol',
                  },
                  fullText: {
                    type: Type.STRING,
                    description: 'Complete caption text ready to copy',
                  },
                },
                required: ['hook', 'body', 'callToAction', 'hashtags', 'fullText'],
              },
            },
          },
          required: ['captions'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{"captions":[]}');
    const formattedCaptions = (parsed.captions || []).map((c: any, i: number) => ({
      id: `cap_gemini_${Date.now()}_${i}`,
      hook: c.hook || '',
      body: c.body || '',
      callToAction: c.callToAction || '',
      hashtags: Array.isArray(c.hashtags) ? c.hashtags : [],
      fullText: c.fullText || `${c.hook}\n\n${c.body}\n\n${c.callToAction}`,
      charCount: (c.fullText || '').length,
    }));

    res.json({
      success: true,
      captions: formattedCaptions,
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error generating captions with Gemini:', error);
    res.status(500).json({
      error: error.message || 'An error occurred while generating captions with Gemini API.',
      code: 'GEMINI_API_ERROR',
    });
  }
});

// ==========================================
// 4. CREATOR TOOL ENDPOINTS
// ==========================================

// 4.1 Trend Radar Endpoint
app.post('/api/creator/trend-radar', async (req: Request, res: Response) => {
  try {
    const { platform, niche, targetCountry, targetLanguage, contentFormat, optionalTopic } = req.body;
    if (!platform || !niche) {
      res.status(400).json({ error: 'Platform and niche are required.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'Gemini API not configured.', code: 'MISSING_API_KEY' });
      return;
    }

    const prompt = `You are a data-driven creator strategist and content intelligence analyst.
Analyze emerging topic ideas and audience demand patterns for:
- Platform: ${platform}
- Niche: ${niche}
- Target Country: ${targetCountry || 'Global'}
- Target Language: ${targetLanguage || 'English'}
- Content Format: ${contentFormat || 'Video'}
- Focus Theme: ${optionalTopic || 'General high-growth areas'}

Generate exactly 4 comprehensive, realistic topic opportunities.
For each topic provide:
1. topic name
2. trendStatus: Exactly one of 'Emerging', 'Growing', 'Established'
3. whyRelevant: Practical reasoning explaining why this theme resonates with this audience
4. contentAngles: 3 distinct angles
5. searchTerms: 4 related search queries viewers type into search
6. hashtags: 5 relevant hashtags
7. suggestedVideoIdea: Actionable 1-2 sentence concept

Important: Do NOT claim these are verified live trend charts; frame them as predictive AI topical analysis based on audience interest signals.`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            trends: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  topic: { type: Type.STRING },
                  trendStatus: { type: Type.STRING, description: 'Emerging, Growing, or Established' },
                  whyRelevant: { type: Type.STRING },
                  contentAngles: { type: Type.ARRAY, items: { type: Type.STRING } },
                  searchTerms: { type: Type.ARRAY, items: { type: Type.STRING } },
                  hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
                  suggestedVideoIdea: { type: Type.STRING },
                },
                required: ['topic', 'trendStatus', 'whyRelevant', 'contentAngles', 'searchTerms', 'hashtags', 'suggestedVideoIdea'],
              },
            },
          },
          required: ['trends'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{"trends":[]}');
    res.json({
      success: true,
      trends: parsed.trends || [],
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error in Trend Radar endpoint:', error);
    res.status(500).json({ error: error.message || 'Failed to generate trend radar.', code: 'GEMINI_API_ERROR' });
  }
});

// 4.2 Content Gap Finder Endpoint
app.post('/api/creator/content-gap', async (req: Request, res: Response) => {
  try {
    const { niche, mainTopic, platform, targetAudience, competitorExamples } = req.body;
    if (!niche || !mainTopic) {
      res.status(400).json({ error: 'Niche and main topic are required.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'Gemini API not configured.', code: 'MISSING_API_KEY' });
      return;
    }

    const prompt = `You are a senior audience researcher and video content strategist.
Perform a content vacuum analysis to identify what everyone is covering vs what questions remain unanswered for:
- Niche: ${niche}
- Main Topic: ${mainTopic}
- Platform: ${platform || 'YouTube / TikTok'}
- Target Audience: ${targetAudience || 'Beginner to Intermediate creators'}
- Reference Examples / Competitors: ${competitorExamples || 'Standard niche channels'}

Generate:
1. coveredAngles: 4 angles that are already saturated/clichéd
2. unansweredQuestions: 4 common friction points or real questions audience members ask in comments that are ignored
3. underservedAngles: 4 specific high-opportunity angles with:
   - angle: title of the angle
   - whyUseful: clear explanation
   - suggestedTitleHook: irresistible title or opening hook
   - contentIdea: practical video concept
   - opportunityScore: estimated integer score 75-98 (clearly an AI estimated metric)
   - scoreReasoning: 1 sentence justification`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            coveredAngles: { type: Type.ARRAY, items: { type: Type.STRING } },
            unansweredQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
            underservedAngles: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  angle: { type: Type.STRING },
                  whyUseful: { type: Type.STRING },
                  suggestedTitleHook: { type: Type.STRING },
                  contentIdea: { type: Type.STRING },
                  opportunityScore: { type: Type.INTEGER },
                  scoreReasoning: { type: Type.STRING },
                },
                required: ['angle', 'whyUseful', 'suggestedTitleHook', 'contentIdea', 'opportunityScore', 'scoreReasoning'],
              },
            },
          },
          required: ['coveredAngles', 'unansweredQuestions', 'underservedAngles'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{"coveredAngles":[],"unansweredQuestions":[],"underservedAngles":[]}');
    res.json({
      success: true,
      coveredAngles: parsed.coveredAngles || [],
      unansweredQuestions: parsed.unansweredQuestions || [],
      underservedAngles: parsed.underservedAngles || [],
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error in Content Gap endpoint:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze content gaps.', code: 'GEMINI_API_ERROR' });
  }
});

// 4.3 Hook Doctor Endpoint
app.post('/api/creator/hook-doctor', async (req: Request, res: Response) => {
  try {
    const { videoTopic, currentHook, videoFormat, targetAudience } = req.body;
    if (!videoTopic) {
      res.status(400).json({ error: 'Video topic is required.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'Gemini API not configured.', code: 'MISSING_API_KEY' });
      return;
    }

    const prompt = `You are a viral retention specialist and master script editor.
Diagnose and improve this video opening hook:
- Video Topic: ${videoTopic}
- Current Hook / First Sentence: ${currentHook || 'In this video I will discuss ' + videoTopic}
- Format: ${videoFormat || 'Short-form (Reels/TikTok/Shorts)'}
- Target Audience: ${targetAudience || 'General enthusiasts'}

Generate:
1. analysis: strengths, weaknesses, and 3 specific retention risk factors
2. firstThreeSecondsCue: visualAction, audioSpokenCue, and textOnScreen subtitle recommendation
3. exactly 5 improved hook variants:
   - Curiosity-Based
   - Educational / High Stakes
   - Story-Based / Vulnerability
   - Short-Form Punchy (under 2 seconds)
   - Visual / Pattern-Interrupt Contrast
   Include whyItWorks and suggestedPacing for each.`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: {
              type: Type.OBJECT,
              properties: {
                strengths: { type: Type.STRING },
                weaknesses: { type: Type.STRING },
                retentionRiskFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ['strengths', 'weaknesses', 'retentionRiskFactors'],
            },
            firstThreeSecondsCue: {
              type: Type.OBJECT,
              properties: {
                visualAction: { type: Type.STRING },
                audioSpokenCue: { type: Type.STRING },
                textOnScreen: { type: Type.STRING },
              },
              required: ['visualAction', 'audioSpokenCue', 'textOnScreen'],
            },
            improvedHooks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING },
                  hookText: { type: Type.STRING },
                  whyItWorks: { type: Type.STRING },
                  suggestedPacing: { type: Type.STRING },
                },
                required: ['type', 'hookText', 'whyItWorks'],
              },
            },
          },
          required: ['analysis', 'firstThreeSecondsCue', 'improvedHooks'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    res.json({
      success: true,
      analysis: parsed.analysis || { strengths: '', weaknesses: '', retentionRiskFactors: [] },
      firstThreeSecondsCue: parsed.firstThreeSecondsCue || { visualAction: '', audioSpokenCue: '', textOnScreen: '' },
      improvedHooks: parsed.improvedHooks || [],
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error in Hook Doctor endpoint:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze hook.', code: 'GEMINI_API_ERROR' });
  }
});

// 4.4 Video Performance Doctor Endpoint
app.post('/api/creator/video-performance', async (req: Request, res: Response) => {
  try {
    const {
      platform,
      videoLength,
      views,
      likes,
      comments,
      shares,
      averageWatchTime,
      averagePercentageViewed,
      impressions,
      ctr,
      followers,
      videoTitle,
    } = req.body;

    const viewsNum = Number(views) || 1;
    const likesNum = Number(likes) || 0;
    const commentsNum = Number(comments) || 0;
    const sharesNum = Number(shares) || 0;
    const totalEngage = likesNum + commentsNum + sharesNum;

    const calculations = {
      likeToViewRatio: Math.round((likesNum / viewsNum) * 1000) / 10,
      commentRatio: Math.round((commentsNum / viewsNum) * 1000) / 10,
      shareRatio: Math.round((sharesNum / viewsNum) * 1000) / 10,
      totalEngagementRate: Math.round((totalEngage / viewsNum) * 1000) / 10,
      estimatedRetentionRate: Number(averagePercentageViewed) || undefined,
    };

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'Gemini API not configured.', code: 'MISSING_API_KEY' });
      return;
    }

    const prompt = `You are a senior algorithmic diagnostics consultant for video platforms.
Analyze this video's analytics and diagnostic performance:
- Platform: ${platform || 'YouTube / TikTok'}
- Video Title / Theme: ${videoTitle || 'General video'}
- Video Length: ${videoLength || '60 seconds'}
- Views: ${viewsNum}
- Likes: ${likesNum} (Like/View: ${calculations.likeToViewRatio}%)
- Comments: ${commentsNum} (Comment/View: ${calculations.commentRatio}%)
- Shares: ${sharesNum} (Share/View: ${calculations.shareRatio}%)
- Avg Watch Time: ${averageWatchTime || 'Not provided'}
- Avg Percentage Viewed: ${averagePercentageViewed ? averagePercentageViewed + '%' : 'Not provided'}
- Impressions: ${impressions || 'Not provided'}
- CTR: ${ctr ? ctr + '%' : 'Not provided'}
- Creator Followers: ${followers || 'Not provided'}

Provide:
1. performanceObservations: 2-3 sentences evaluating the health of these numbers against typical platform benchmarks
2. possibleStrengths: 3 concrete positive signals from this data
3. possibleWeaknesses: 3 likely friction points or drop-off causes
4. reachObservations: analysis of discovery, CTR, and impressions
5. retentionObservations: analysis of watch time and completion rate
6. practicalSuggestions: exactly 3 tactical fixes for the next video
7. nextVideoRecommendations: 3 specific follow-up video ideas based on this topic`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            performanceObservations: { type: Type.STRING },
            possibleStrengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            possibleWeaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
            reachObservations: { type: Type.STRING },
            retentionObservations: { type: Type.STRING },
            practicalSuggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
            nextVideoRecommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: [
            'performanceObservations',
            'possibleStrengths',
            'possibleWeaknesses',
            'reachObservations',
            'retentionObservations',
            'practicalSuggestions',
            'nextVideoRecommendations',
          ],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    res.json({
      success: true,
      calculations,
      performanceObservations: parsed.performanceObservations || '',
      possibleStrengths: parsed.possibleStrengths || [],
      possibleWeaknesses: parsed.possibleWeaknesses || [],
      reachObservations: parsed.reachObservations || '',
      retentionObservations: parsed.retentionObservations || '',
      practicalSuggestions: parsed.practicalSuggestions || [],
      nextVideoRecommendations: parsed.nextVideoRecommendations || [],
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error in Video Performance Doctor endpoint:', error);
    res.status(500).json({ error: error.message || 'Failed to diagnose video performance.', code: 'GEMINI_API_ERROR' });
  }
});

// 4.5 Smart Hashtag & Keyword Mixer Endpoint
app.post('/api/creator/hashtag-mixer', async (req: Request, res: Response) => {
  try {
    const { platform, topic, niche, targetCountry, targetLanguage, audience, contentType } = req.body;
    if (!topic || !niche) {
      res.status(400).json({ error: 'Topic and niche are required.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'Gemini API not configured.', code: 'MISSING_API_KEY' });
      return;
    }

    const prompt = `You are a search discovery and metadata optimization specialist for ${platform || 'social video platforms'}.
Generate structured search terms and hashtags for:
- Platform: ${platform || 'Instagram / TikTok'}
- Topic: ${topic}
- Niche: ${niche}
- Target Country: ${targetCountry || 'Global'}
- Target Language: ${targetLanguage || 'English'}
- Target Audience: ${audience || 'Engaged followers'}
- Content Type: ${contentType || 'Tutorial / Breakdown'}

Provide:
1. broadHashtags: 6 wide discovery tags (starting with #)
2. nicheHashtags: 6 focused sub-community tags (starting with #)
3. specificHashtags: 6 hyper-specific topic tags (starting with #)
4. searchKeywords: 6 keyword phrases typed into platform search bars
5. longTailKeywords: 4 long-tail query questions
6. captionKeywords: 8 high-intent words to naturally incorporate into the caption body for algorithmic indexing
7. suggestedCombinations: 3 tailored copy-paste bundles with title, description, tags array, and readyText string`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            broadHashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
            nicheHashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
            specificHashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
            searchKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            longTailKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            captionKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestedCombinations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  tags: { type: Type.ARRAY, items: { type: Type.STRING } },
                  readyText: { type: Type.STRING },
                },
                required: ['title', 'description', 'tags', 'readyText'],
              },
            },
          },
          required: ['broadHashtags', 'nicheHashtags', 'specificHashtags', 'searchKeywords', 'longTailKeywords', 'captionKeywords', 'suggestedCombinations'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    res.json({
      success: true,
      broadHashtags: parsed.broadHashtags || [],
      nicheHashtags: parsed.nicheHashtags || [],
      specificHashtags: parsed.specificHashtags || [],
      searchKeywords: parsed.searchKeywords || [],
      longTailKeywords: parsed.longTailKeywords || [],
      captionKeywords: parsed.captionKeywords || [],
      suggestedCombinations: parsed.suggestedCombinations || [],
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error in Hashtag Mixer endpoint:', error);
    res.status(500).json({ error: error.message || 'Failed to mix hashtags and keywords.', code: 'GEMINI_API_ERROR' });
  }
});

// 4.6 Content Experiment Generator Endpoint
app.post('/api/creator/content-experiment', async (req: Request, res: Response) => {
  try {
    const { originalIdea, platform, audience, contentFormat, goal } = req.body;
    if (!originalIdea) {
      res.status(400).json({ error: 'Original idea is required.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'Gemini API not configured.', code: 'MISSING_API_KEY' });
      return;
    }

    const prompt = `You are a scientific content growth strategist who designs A/B/C split-testing blueprints for creators.
Turn this single content idea into exactly 3 radically different testable formats:
- Original Content Idea: ${originalIdea}
- Platform: ${platform || 'YouTube / TikTok / Reels'}
- Target Audience: ${audience || 'General audience'}
- Content Format: ${contentFormat || 'Short-form Video'}
- Primary Objective: ${goal || 'High Retention & Audience Growth'}

Return:
- experimentA: Curiosity & Pattern-Interrupt Approach (hook, title, contentAngle, cta, hypothesis)
- experimentB: Educational Framework & Actionable Blueprint Approach (hook, title, contentAngle, cta, hypothesis)
- experimentC: Storytelling, Personal Vulnerability & Case Study Approach (hook, title, contentAngle, cta, hypothesis)
- testingGuidelines: 3 practical rules on how to publish and evaluate these experiments without confusing followers`;

    const { response, modelUsed } = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            experimentA: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                hook: { type: Type.STRING },
                title: { type: Type.STRING },
                contentAngle: { type: Type.STRING },
                cta: { type: Type.STRING },
                hypothesis: { type: Type.STRING },
              },
              required: ['name', 'hook', 'title', 'contentAngle', 'cta', 'hypothesis'],
            },
            experimentB: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                hook: { type: Type.STRING },
                title: { type: Type.STRING },
                contentAngle: { type: Type.STRING },
                cta: { type: Type.STRING },
                hypothesis: { type: Type.STRING },
              },
              required: ['name', 'hook', 'title', 'contentAngle', 'cta', 'hypothesis'],
            },
            experimentC: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                hook: { type: Type.STRING },
                title: { type: Type.STRING },
                contentAngle: { type: Type.STRING },
                cta: { type: Type.STRING },
                hypothesis: { type: Type.STRING },
              },
              required: ['name', 'hook', 'title', 'contentAngle', 'cta', 'hypothesis'],
            },
            testingGuidelines: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ['experimentA', 'experimentB', 'experimentC', 'testingGuidelines'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    res.json({
      success: true,
      experimentA: parsed.experimentA,
      experimentB: parsed.experimentB,
      experimentC: parsed.experimentC,
      testingGuidelines: parsed.testingGuidelines || [],
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error in Content Experiment endpoint:', error);
    res.status(500).json({ error: error.message || 'Failed to generate content experiments.', code: 'GEMINI_API_ERROR' });
  }
});

// Health check routes for Cloud Run, Kubernetes, and container orchestration
const handleHealth = (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'ok',
    uptime: process.uptime(),
    port: Number(process.env.PORT || 3000),
    timestamp: new Date().toISOString(),
  });
};

app.get('/api/health', handleHealth);
app.get('/healthz', handleHealth);

// Public XML Sitemap for Search Engines & Crawlers
const SITEMAP_XML = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <!-- Core Public Pages -->
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/pricing</loc>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/about</loc>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/privacy</loc>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/terms</loc>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/contact</loc>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>

  <!-- Business & Freelancer Tools -->
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/proposal-generator</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/freelancer-rate-calculator</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>

  <!-- Amazon Seller Tools -->
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/amazon-profit-calculator</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/amazon-ppc-calculator</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/amazon-keyword-generator</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>

  <!-- Creator Tools -->
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/social-caption-generator</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/engagement-calculator</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/creator/trend-radar</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/creator/content-gap-finder</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/creator/hook-doctor</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/creator/video-performance-doctor</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/creator/hashtag-keyword-mixer</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/creator/content-experiment-generator</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>

  <!-- Public Educational Guides -->
  <url>
    <loc>https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/guides/how-to-calculate-freelance-hourly-rate</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>`;

app.get('/sitemap.xml', (_req: Request, res: Response) => {
  res.header('Content-Type', 'application/xml');
  res.status(200).send(SITEMAP_XML);
});

// Public robots.txt for Search Engines, Crawlers & AI Bots
const ROBOTS_TXT = `User-agent: *
Allow: /

User-agent: OAI-SearchBot
Allow: /

Sitemap: https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/sitemap.xml
`;

app.get('/robots.txt', (_req: Request, res: Response) => {
  res.header('Content-Type', 'text/plain; charset=utf-8');
  res.status(200).send(ROBOTS_TXT);
});

// Trailing slash 301 redirect for all non-root routes to prevent duplicate canonical issues
app.use((req: Request, res: Response, next) => {
  if (req.path.length > 1 && req.path.endsWith('/') && !req.path.includes('.')) {
    const cleanPath = req.path.replace(/\/+$/, '');
    const query = req.url.slice(req.path.length);
    return res.redirect(301, cleanPath + query);
  }
  next();
});

// Mount Vite middleware for development or serve built files for production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  // In Google Cloud Run environments with an NGINX sidecar on port 8080,
  // the Node application must listen on DEFAULT_APP_PORT (3000) where NGINX forwards traffic.
  const targetPort = process.env.DEFAULT_APP_PORT
    || (process.env.PORT && process.env.PORT !== process.env.NGINX_PORT ? process.env.PORT : '3000');
  const PORT = parseInt(targetPort, 10);

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'custom',
    });
    app.use(vite.middlewares);

    app.get('/sw.js', (_req: Request, res: Response) => {
      const swPath = path.resolve(process.cwd(), 'sw.js');
      if (fs.existsSync(swPath)) {
        res.type('application/javascript');
        res.sendFile(swPath);
      } else {
        res.status(404).send('sw.js not found');
      }
    });

    app.get('*', async (req: Request, res: Response, next) => {
      if (req.path.startsWith('/@') || req.path.startsWith('/src/') || req.path.includes('.')) {
        return next();
      }
      try {
        const indexPath = path.resolve(process.cwd(), 'index.html');
        if (fs.existsSync(indexPath)) {
          const rawHtml = fs.readFileSync(indexPath, 'utf-8');
          const transformedHtml = await vite.transformIndexHtml(req.originalUrl, rawHtml);
          const { html, statusCode, isPrivate } = renderHtmlWithSeo(transformedHtml, req.path);
          if (isPrivate || statusCode === 404) {
            res.setHeader('X-Robots-Tag', 'noindex, nofollow');
          }
          res.status(statusCode).setHeader('Content-Type', 'text/html; charset=utf-8').send(html);
        } else {
          res.status(503).send('index.html not found.');
        }
      } catch (err) {
        next(err);
      }
    });
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    // Prevent express.static from serving dist/index.html automatically on directory requests (e.g. '/')
    // so that all HTML requests pass through our dynamic canonical tag & metadata injector.
    app.use(express.static(distPath, { index: false }));

    app.get('/sw.js', (_req: Request, res: Response) => {
      const swPath = path.resolve(process.cwd(), 'sw.js');

      if (fs.existsSync(swPath)) {
        res.type('application/javascript');
        res.sendFile(swPath);
      } else {
        res.status(404).send('sw.js not found');
      }
    });

    app.get('*', (req: Request, res: Response) => {
      const indexPath = path.join(distPath, 'index.html');
      if (fs.existsSync(indexPath)) {
        try {
          const rawHtml = fs.readFileSync(indexPath, 'utf-8');
          const { html, statusCode, isPrivate } = renderHtmlWithSeo(rawHtml, req.path);
          if (isPrivate || statusCode === 404) {
            res.setHeader('X-Robots-Tag', 'noindex, nofollow');
          }
          res.status(statusCode).setHeader('Content-Type', 'text/html; charset=utf-8').send(html);
        } catch (err) {
          console.error('Error serving index.html with SEO metadata:', err);
          res.sendFile(indexPath);
        }
      } else {
        res.status(503).send('ToolFlow application is starting up or build assets are compiling. Please refresh.');
      }
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`ToolFlow server listening on 0.0.0.0:${PORT} (NODE_ENV=${process.env.NODE_ENV || 'development'})`);
  });

  // Graceful shutdown handling for Cloud Run revision rotation
  const shutdown = (signal: string) => {
    console.log(`${signal} received: closing ToolFlow HTTP server`);
    server.close(() => {
      console.log('HTTP server closed cleanly');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

startServer();
