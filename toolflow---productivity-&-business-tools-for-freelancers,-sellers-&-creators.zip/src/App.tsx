import React, { useState, useEffect } from 'react';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { ToastContainer } from './components/common/ToastContainer';

// Pages
import { HomePage } from './pages/HomePage';
import { ToolsPage } from './pages/ToolsPage';
import { DashboardPage } from './pages/DashboardPage';
import { SavedResultsPage } from './pages/SavedResultsPage';
import { PricingPage } from './pages/PricingPage';
import { AboutPage } from './pages/AboutPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';
import { TermsOfServicePage } from './pages/TermsOfServicePage';
import { ContactPage } from './pages/ContactPage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { SettingsPage } from './pages/SettingsPage';
import { NotFoundPage } from './pages/NotFoundPage';

// Tools Pages
import { ProposalGeneratorPage } from './pages/tools/ProposalGeneratorPage';
import { FreelancerRateCalculatorPage } from './pages/tools/FreelancerRateCalculatorPage';
import { AmazonProfitCalculatorPage } from './pages/tools/AmazonProfitCalculatorPage';
import { AmazonPpcCalculatorPage } from './pages/tools/AmazonPpcCalculatorPage';
import { AmazonKeywordGeneratorPage } from './pages/tools/AmazonKeywordGeneratorPage';
import { SocialCaptionGeneratorPage } from './pages/tools/SocialCaptionGeneratorPage';
import { EngagementRateCalculatorPage } from './pages/tools/EngagementRateCalculatorPage';

// Creator Tools Pages
import { TrendRadarPage } from './pages/tools/creator/TrendRadarPage';
import { ContentGapFinderPage } from './pages/tools/creator/ContentGapFinderPage';
import { HookDoctorPage } from './pages/tools/creator/HookDoctorPage';
import { VideoPerformanceDoctorPage } from './pages/tools/creator/VideoPerformanceDoctorPage';
import { HashtagKeywordMixerPage } from './pages/tools/creator/HashtagKeywordMixerPage';
import { ContentExperimentGeneratorPage } from './pages/tools/creator/ContentExperimentGeneratorPage';

// Guides
import { FreelanceHourlyRateGuidePage } from './pages/guides/FreelanceHourlyRateGuidePage';

function normalizePath(rawPath?: string): string {
  if (!rawPath) return '/';
  const clean = rawPath.replace(/\/+/g, '/').trim();
  if (clean.length > 1 && clean.endsWith('/')) {
    return clean.slice(0, -1);
  }
  return clean || '/';
}

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return normalizePath(window.location.pathname);
  });

  const [currentSearch, setCurrentSearch] = useState<string>(() => {
    return window.location.search || '';
  });

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(normalizePath(window.location.pathname));
      setCurrentSearch(window.location.search || '');
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (fullUrl: string) => {
    const [path, search] = fullUrl.split('?');
    const newPath = normalizePath(path);
    const newSearch = search ? `?${search}` : '';

    window.history.pushState({}, '', fullUrl);
    setCurrentPath(newPath);
    setCurrentSearch(newSearch);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Helper to extract query parameters
  const queryParams = new URLSearchParams(currentSearch);
  const categoryParam = queryParams.get('category') || undefined;
  const tabParam = queryParams.get('tab') || undefined;

  // Determine if this is a dedicated dashboard full-height layout view
  const isDashboardView =
    currentPath === '/dashboard' ||
    currentPath === '/saved' ||
    currentPath === '/settings';

  const renderContent = () => {
    switch (currentPath) {
      case '/':
        return <HomePage onNavigate={navigate} />;
      case '/tools':
        return <ToolsPage onNavigate={navigate} initialCategory={categoryParam} />;
      case '/tools/proposal-generator':
        return <ProposalGeneratorPage onNavigate={navigate} />;
      case '/tools/freelancer-rate-calculator':
        return <FreelancerRateCalculatorPage onNavigate={navigate} />;
      case '/tools/amazon-profit-calculator':
        return <AmazonProfitCalculatorPage onNavigate={navigate} />;
      case '/tools/amazon-ppc-calculator':
        return <AmazonPpcCalculatorPage onNavigate={navigate} />;
      case '/tools/amazon-keyword-generator':
        return <AmazonKeywordGeneratorPage onNavigate={navigate} />;
      case '/tools/social-caption-generator':
        return <SocialCaptionGeneratorPage onNavigate={navigate} />;
      case '/tools/engagement-calculator':
        return <EngagementRateCalculatorPage onNavigate={navigate} />;
      case '/tools/creator/trend-radar':
        return <TrendRadarPage onNavigate={navigate} />;
      case '/tools/creator/content-gap-finder':
        return <ContentGapFinderPage onNavigate={navigate} />;
      case '/tools/creator/hook-doctor':
        return <HookDoctorPage onNavigate={navigate} />;
      case '/tools/creator/video-performance-doctor':
        return <VideoPerformanceDoctorPage onNavigate={navigate} />;
      case '/tools/creator/hashtag-keyword-mixer':
        return <HashtagKeywordMixerPage onNavigate={navigate} />;
      case '/tools/creator/content-experiment-generator':
        return <ContentExperimentGeneratorPage onNavigate={navigate} />;
      case '/guides/how-to-calculate-freelance-hourly-rate':
        return <FreelanceHourlyRateGuidePage onNavigate={navigate} />;
      case '/dashboard':
        return <DashboardPage onNavigate={navigate} initialTab={tabParam} />;
      case '/saved':
        return <SavedResultsPage onNavigate={navigate} />;
      case '/pricing':
        return <PricingPage onNavigate={navigate} />;
      case '/about':
        return <AboutPage onNavigate={navigate} />;
      case '/privacy':
        return <PrivacyPolicyPage onNavigate={navigate} />;
      case '/terms':
        return <TermsOfServicePage onNavigate={navigate} />;
      case '/contact':
        return <ContactPage onNavigate={navigate} />;
      case '/login':
        return <LoginPage onNavigate={navigate} />;
      case '/signup':
        return <SignupPage onNavigate={navigate} />;
      case '/settings':
        return <SettingsPage onNavigate={navigate} />;
      default:
        return <NotFoundPage onNavigate={navigate} />;
    }
  };

  return (
    <AppProvider>
      <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans antialiased">
        {/* Render standard public Navbar on non-dashboard views */}
        {!isDashboardView && (
          <Navbar currentPath={currentPath} onNavigate={navigate} />
        )}

        {/* Main Content Area */}
        <main className="flex-1">{renderContent()}</main>

        {/* Render standard Footer on non-dashboard views */}
        {!isDashboardView && <Footer onNavigate={navigate} />}

        {/* Global Toast Stack */}
        <ToastContainer />
      </div>
    </AppProvider>
  );
}
