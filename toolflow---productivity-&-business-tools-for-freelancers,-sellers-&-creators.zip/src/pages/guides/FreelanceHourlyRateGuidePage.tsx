import React, { useState, useEffect } from 'react';
import { Card } from '../../components/common/Card';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import {
  ArrowLeft,
  ArrowRight,
  Calculator,
  Clock,
  DollarSign,
  CheckCircle2,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  AlertTriangle,
  TrendingUp,
  Sparkles,
  BookOpen,
  Briefcase,
  FileText,
  Share2,
  Check,
  Percent,
  Calendar,
} from 'lucide-react';

interface FreelanceHourlyRateGuidePageProps {
  onNavigate: (path: string) => void;
}

export const FreelanceHourlyRateGuidePage: React.FC<FreelanceHourlyRateGuidePageProps> = ({
  onNavigate,
}) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [copiedLink, setCopiedLink] = useState(false);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const handleShare = () => {
    const url = 'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/guides/how-to-calculate-freelance-hourly-rate';
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const faqItems = [
    {
      question: 'How often should I raise my freelance hourly rate?',
      answer:
        'Most established freelancers review their hourly rate every 6 to 12 months. Adjustments are typically warranted when your skills improve, your portfolio grows, demand exceeds your available billable capacity, or annual software and living costs rise. You can apply new rates immediately to incoming clients while giving existing retainer clients 30 to 60 days advance notice.',
    },
    {
      question: 'What is a typical billable hour percentage for freelancers?',
      answer:
        'Full-time freelancers typically maintain a 50% to 65% billable utilization rate. In a 35-to-40-hour work week, that equates to roughly 18 to 25 billable client hours. The remaining 12 to 18 hours are consumed by essential non-billable business activities such as client prospecting, proposal drafting, administrative bookkeeping, and professional skill development.',
    },
    {
      question: 'Should I charge by the hour or by the project?',
      answer:
        'Hourly pricing is ideal for open-ended assignments, ongoing consulting, technical troubleshooting, or projects with unclear specifications where scope creep is likely. Project-based (fixed-fee) pricing works best for well-defined deliverables where your efficiency allows you to earn a higher effective hourly rate without penalizing yourself for working quickly.',
    },
    {
      question: 'How do I account for taxes when calculating my freelance rate?',
      answer:
        'Unlike traditional W-2 employees whose employers pay half of payroll taxes, freelancers are responsible for full self-employment tax (Social Security and Medicare) plus federal and state income taxes. Depending on your tax jurisdiction and income bracket, setting aside 25% to 30% of your gross revenue for taxes ensures you are not underfunded when quarterly estimated taxes come due.',
    },
    {
      question: 'What if prospective clients say my hourly rate is too high?',
      answer:
        'Price resistance is normal in freelancing. Rather than immediately dropping your hourly rate, evaluate whether the client understands the return on investment and business outcome you deliver. You can offer to adjust the project scope or milestones to fit their budget, or use our AI Proposal Generator to communicate value and deliverables with greater clarity.',
    },
  ];

  // Technical SEO, Canonical, Robots, and Schema.org Structured Data
  useEffect(() => {
    const previousTitle = document.title;
    const pageTitle = 'How to Calculate Your Freelance Hourly Rate | ToolFlow';
    const pageDesc =
      'Learn how to calculate a freelance hourly rate based on income goals, working hours, expenses, taxes, and non-billable time with ToolFlow.';
    const canonicalHref =
      'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/guides/how-to-calculate-freelance-hourly-rate';

    document.title = pageTitle;

    // Meta Description
    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    if (metaDesc) {
      metaDesc.setAttribute('content', pageDesc);
    } else {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      metaDesc.setAttribute('content', pageDesc);
      document.head.appendChild(metaDesc);
    }

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    const prevCanonical = canonical ? canonical.getAttribute('href') : null;
    if (canonical) {
      canonical.setAttribute('href', canonicalHref);
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      canonical.setAttribute('href', canonicalHref);
      document.head.appendChild(canonical);
    }

    // Robots meta
    let robotsMeta = document.querySelector('meta[name="robots"]');
    const prevRobots = robotsMeta ? robotsMeta.getAttribute('content') : '';
    if (robotsMeta) {
      robotsMeta.setAttribute('content', 'index, follow');
    } else {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      robotsMeta.setAttribute('content', 'index, follow');
      document.head.appendChild(robotsMeta);
    }

    // OpenGraph & Twitter tags
    let ogTitle = document.querySelector('meta[property="og:title"]');
    const prevOgTitle = ogTitle ? ogTitle.getAttribute('content') : '';
    if (ogTitle) ogTitle.setAttribute('content', pageTitle);

    let ogDesc = document.querySelector('meta[property="og:description"]');
    const prevOgDesc = ogDesc ? ogDesc.getAttribute('content') : '';
    if (ogDesc) ogDesc.setAttribute('content', pageDesc);

    let ogType = document.querySelector('meta[property="og:type"]');
    const prevOgType = ogType ? ogType.getAttribute('content') : '';
    if (ogType) ogType.setAttribute('content', 'article');

    // JSON-LD Structured Data: Article, WebPage, and FAQPage
    const scriptId = 'freelance-hourly-rate-guide-schema';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }

    const structuredData = [
      {
        '@context': 'https://schema.org',
        '@type': 'Article',
        headline: 'How to Calculate Your Freelance Hourly Rate',
        description: pageDesc,
        url: canonicalHref,
        datePublished: '2026-10-07',
        dateModified: '2026-10-07',
        author: {
          '@type': 'Organization',
          name: 'ToolFlow',
          url: 'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/',
        },
        publisher: {
          '@type': 'Organization',
          name: 'ToolFlow',
          url: 'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/',
        },
        mainEntityOfPage: {
          '@type': 'WebPage',
          '@id': canonicalHref,
        },
      },
      {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqItems.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      },
    ];

    script.text = JSON.stringify(structuredData);

    return () => {
      document.title = previousTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      if (ogTitle && prevOgTitle) ogTitle.setAttribute('content', prevOgTitle);
      if (ogDesc && prevOgDesc) ogDesc.setAttribute('content', prevOgDesc);
      if (ogType && prevOgType) ogType.setAttribute('content', prevOgType);
      if (canonical && prevCanonical) {
        canonical.setAttribute('href', prevCanonical);
      } else if (canonical && !prevCanonical) {
        canonical.remove();
      }
      if (robotsMeta && prevRobots) {
        robotsMeta.setAttribute('content', prevRobots);
      } else if (robotsMeta && !prevRobots) {
        robotsMeta.remove();
      }
      const existingScript = document.getElementById(scriptId);
      if (existingScript) existingScript.remove();
    };
  }, []);

  return (
    <div className="bg-slate-50 min-h-screen py-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Navigation Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6" aria-label="Breadcrumb">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('/');
            }}
            className="hover:text-indigo-600 transition-colors"
          >
            Home
          </a>
          <span>/</span>
          <a
            href="/tools?category=freelancer"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('/tools?category=freelancer');
            }}
            className="hover:text-indigo-600 transition-colors"
          >
            Freelancer Guides
          </a>
          <span>/</span>
          <span className="text-slate-900 font-medium truncate">
            Calculate Freelance Hourly Rate
          </span>
        </nav>

        {/* Header Hero */}
        <header className="mb-10 text-left">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold mb-4 shadow-2xs">
            <BookOpen className="h-3.5 w-3.5" />
            <span>Freelance Pricing &amp; Finance Guide</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-[1.15] mb-4">
            How to Calculate Your Freelance Hourly Rate
          </h1>

          <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-3xl">
            Setting your freelance pricing should never rely on guesswork or copying salaried salaries. Discover the exact step-by-step formula to calculate a sustainable freelance hourly rate that covers taxes, business overhead, paid time off, and non-billable client management.
          </p>

          <div className="mt-6 pt-4 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
            <div className="flex items-center gap-4">
              <span>Published by ToolFlow Editorial Team</span>
              <span>•</span>
              <span>10 min read</span>
              <span>•</span>
              <span className="text-emerald-700 font-medium">Educational Guide</span>
            </div>

            <button
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-medium transition-colors cursor-pointer"
              title="Share article URL"
            >
              {copiedLink ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-600" />
                  <span className="text-emerald-600">Link Copied</span>
                </>
              ) : (
                <>
                  <Share2 className="h-3.5 w-3.5" />
                  <span>Share Guide</span>
                </>
              )}
            </button>
          </div>
        </header>

        {/* Primary Early Callout CTA */}
        <div className="mb-10 p-5 rounded-2xl bg-indigo-50/90 border border-indigo-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-600 text-white shrink-0 mt-0.5 shadow-xs">
              <Calculator className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 mb-0.5">
                Want to calculate your exact rate automatically?
              </h2>
              <p className="text-xs text-slate-600 leading-relaxed">
                Use ToolFlow’s interactive{' '}
                <a
                  href="/tools/freelancer-rate-calculator"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/tools/freelancer-rate-calculator');
                  }}
                  className="font-bold text-indigo-700 underline hover:text-indigo-800"
                >
                  Freelancer Rate Calculator
                </a>{' '}
                to compute your custom billable hourly requirement with live currency support.
              </p>
            </div>
          </div>
          <a
            href="/tools/freelancer-rate-calculator"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('/tools/freelancer-rate-calculator');
            }}
            className="shrink-0 inline-flex items-center justify-center font-medium rounded-lg transition-all text-xs px-3 py-1.5 gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs cursor-pointer"
          >
            <span>Launch Calculator</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </a>
        </div>

        {/* Main Article Body */}
        <article className="space-y-10 text-slate-800 leading-relaxed font-sans text-sm sm:text-base">
          {/* Section 1: What a freelance hourly rate means */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              1. What Does a Freelance Hourly Rate Actually Mean?
            </h2>
            <p>
              When an employee earns $35 per hour at a corporate job, their employer pays half of their payroll taxes, provides paid vacation days, funds healthcare coverage, supplies office computers, and covers commercial software licenses. The employee receives that hourly wage for every hour they sit at their desk, regardless of how much revenue the company generates that afternoon.
            </p>
            <p>
              In freelancing, your <strong>freelance hourly rate</strong> is not a standard wage—it is your business's top-line revenue rate. It represents the financial engine that must fund your entire business infrastructure, personal compensation, health insurance, sick leave, self-employment tax obligations, and professional retirement savings. If your rate only matches an employee salary, you are effectively subsidizing your clients at your own expense.
            </p>
          </section>

          {/* Section 2: Why freelancers must account for all costs */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              2. Why You Must Account for Expenses, Taxes, and Non-Billable Hours
            </h2>
            <p>
              Many creative and technical professionals leave full-time employment, estimate that they need $60,000 per year, divide that number by 2,080 working hours (40 hours × 52 weeks), and conclude that $28.85 per hour is sufficient. This is the single most common mathematical error in freelance business planning.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
              <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
                <span className="font-bold text-indigo-700 block mb-1 text-sm">Self-Employment Taxes</span>
                <p className="text-xs text-slate-600">
                  You are responsible for both the employer and employee portions of payroll taxes, plus state and federal income taxes.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
                <span className="font-bold text-indigo-700 block mb-1 text-sm">Operating Overhead</span>
                <p className="text-xs text-slate-600">
                  Hardware depreciation, cloud backups, domain fees, accounting software, and professional subscriptions come out of your revenue.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
                <span className="font-bold text-indigo-700 block mb-1 text-sm">Unpaid Time Off</span>
                <p className="text-xs text-slate-600">
                  Sick days, holidays, and vacations generate zero income. Your billable weeks must subsidize your non-working periods.
                </p>
              </div>
            </div>
          </section>

          {/* Section 3: The Calculation Formula */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              3. The Core Freelance Hourly Rate Calculation Method
            </h2>
            <p>
              To establish an accurate, durable rate, use this straightforward reverse-engineering formula:
            </p>
            <div className="p-5 rounded-xl bg-slate-900 text-white font-mono text-xs sm:text-sm space-y-2 border border-slate-800 shadow-sm">
              <p className="text-indigo-300 font-bold">Minimum Hourly Rate = Gross Annual Revenue Needed ÷ Total Annual Billable Hours</p>
              <div className="pt-2 text-slate-300 text-xs font-sans space-y-1">
                <p>• <strong>Gross Annual Revenue Needed</strong> = Desired Net Take-Home Income + Annual Business Expenses + Tax &amp; Benefits Reserve</p>
                <p>• <strong>Total Annual Billable Hours</strong> = (52 Weeks - Unpaid Weeks Off) × (Weekly Working Hours × Billable Utilization %)</p>
              </div>
            </div>
            <p className="text-xs text-slate-500 italic">
              Tip: You can use our interactive{' '}
              <a
                href="/tools/freelancer-rate-calculator"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('/tools/freelancer-rate-calculator');
                }}
                className="text-indigo-600 font-semibold underline"
              >
                freelance hourly rate calculator
              </a>{' '}
              to run this math instantly with your exact local expenses and tax numbers.
            </p>
          </section>

          {/* Section 4: Step-by-Step Example with Clear Numbers */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              4. Step-by-Step Example: Calculating a Real-World Freelance Rate
            </h2>
            <p>
              Let’s examine a practical hypothetical scenario for an independent UI designer or software consultant:
            </p>

            <Card className="p-6 bg-white border border-slate-200/90 shadow-xs space-y-4">
              <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-2">
                Hypothetical Freelance Financial Model
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
                <div className="space-y-2">
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-600">Target Annual Take-Home Income:</span>
                    <span className="font-bold text-slate-900">$60,000</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-600">Annual Business Overhead:</span>
                    <span className="font-bold text-slate-900">$6,000</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-600">Estimated Taxes &amp; Healthcare Reserve (30%):</span>
                    <span className="font-bold text-slate-900">$18,000</span>
                  </div>
                  <div className="flex justify-between py-1 font-bold text-indigo-700 bg-indigo-50/60 p-2 rounded">
                    <span>Total Gross Revenue Needed:</span>
                    <span>$84,000</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-600">Weeks Worked per Year:</span>
                    <span className="font-bold text-slate-900">48 weeks (4 wks off)</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-600">Total Work Hours per Week:</span>
                    <span className="font-bold text-slate-900">35 hours/week</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-600">Billable Utilization Rate (60%):</span>
                    <span className="font-bold text-slate-900">21 billable hrs/wk</span>
                  </div>
                  <div className="flex justify-between py-1 font-bold text-emerald-800 bg-emerald-50/60 p-2 rounded">
                    <span>Annual Billable Hours:</span>
                    <span>1,008 hours</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-4 rounded-xl">
                <div>
                  <span className="text-xs uppercase tracking-wider font-bold text-slate-500">
                    Calculated Result
                  </span>
                  <p className="text-sm font-semibold text-slate-800">
                    $84,000 gross revenue ÷ 1,008 billable hours
                  </p>
                </div>
                <div className="text-right sm:text-right">
                  <span className="text-2xl font-black text-indigo-600 font-mono">
                    $83.33 / hour
                  </span>
                  <span className="block text-[11px] text-slate-500">Recommended market floor: $85/hr</span>
                </div>
              </div>
            </Card>

            <p className="text-xs text-slate-600">
              Notice how an apparent $60,000 salary requires billing roughly <strong>$85 per hour</strong> once overhead, taxes, and non-billable time are factored in.
            </p>
          </section>

          {/* Section 5: Accounting for Software and Hardware */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              5. How to Itemize Business Expenses Correctly
            </h2>
            <p>
              Freelance overhead builds up quickly through micro-subscriptions and equipment maintenance. Itemize your operating costs across four primary categories:
            </p>
            <ul className="list-disc pl-5 space-y-2 text-xs sm:text-sm text-slate-700">
              <li>
                <strong>Software &amp; Digital Tools:</strong> Adobe Creative Cloud, Figma, GitHub, Notion, web hosting, accounting software, and specialized AI productivity tools.
              </li>
              <li>
                <strong>Hardware &amp; Equipment:</strong> Workstation laptops, external monitors, microphones, and backup drives, amortized over their typical 2-to-3-year lifespan.
              </li>
              <li>
                <strong>Workspace &amp; Utilities:</strong> High-speed internet service, mobile phone connectivity, and dedicated home-office utilities or coworking memberships.
              </li>
              <li>
                <strong>Professional Services:</strong> Certified public accountants, annual LLC filing fees, contract legal templates, and commercial banking charges.
              </li>
            </ul>
          </section>

          {/* Section 6: Non-Billable Hours and Utilization */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              6. How Non-Billable Work Impacts Your Real Hourly Return
            </h2>
            <p>
              A major surprise for new freelancers is discovering that only 50% to 65% of their working hours can actually be billed to clients. The remaining time is consumed by:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 rounded-lg bg-white border border-slate-200">
                <span className="font-bold text-slate-900 block mb-0.5">Client Proposals &amp; Pitches</span>
                <span className="text-slate-600">
                  Reviewing project briefs and generating winning pitches with tools like our{' '}
                  <a
                    href="/tools/proposal-generator"
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate('/tools/proposal-generator');
                    }}
                    className="text-indigo-600 font-semibold underline"
                  >
                    AI Proposal Generator
                  </a>.
                </span>
              </div>
              <div className="p-3.5 rounded-lg bg-white border border-slate-200">
                <span className="font-bold text-slate-900 block mb-0.5">Marketing &amp; Social Outreach</span>
                <span className="text-slate-600">
                  Writing case studies and sharing social content using our{' '}
                  <a
                    href="/tools/social-caption-generator"
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate('/tools/social-caption-generator');
                    }}
                    className="text-indigo-600 font-semibold underline"
                  >
                    Social Caption Generator
                  </a>.
                </span>
              </div>
              <div className="p-3.5 rounded-lg bg-white border border-slate-200">
                <span className="font-bold text-slate-900 block mb-0.5">Invoicing &amp; Bookkeeping</span>
                <span className="text-slate-600">
                  Tracking payments, managing receipts, and filing quarterly tax returns.
                </span>
              </div>
              <div className="p-3.5 rounded-lg bg-white border border-slate-200">
                <span className="font-bold text-slate-900 block mb-0.5">Ongoing Professional Learning</span>
                <span className="text-slate-600">
                  Staying updated with current coding frameworks, design trends, or e-commerce regulations.
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-600">
              If you work 40 hours per week but only bill 20 hours at $50/hour, your actual business take-home before taxes is only $25 per total working hour.
            </p>
          </section>

          {/* Section 7: Hourly Rate vs. Project-Based Pricing */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              7. Hourly Rate vs. Project-Based (Fixed-Fee) Pricing
            </h2>
            <p>
              Understanding your hourly rate is essential even if you quote flat project fees:
            </p>
            <div className="p-4 rounded-xl bg-white border border-slate-200/90 space-y-3 text-xs sm:text-sm">
              <p>
                <strong>When to charge hourly:</strong> Choose hourly billing when client requirements are vague, the project timeline is open-ended, or you are offering ongoing advisory support where the client dictates scope changes on the fly.
              </p>
              <p>
                <strong>When to charge by the project:</strong> Quote fixed fees when you have built repeatable processes that allow you to complete high-value deliverables quickly. If a brand redesign takes you 15 hours and delivers $5,000 of value, charging an hourly rate might penalize your speed, whereas a fixed fee rewards your efficiency.
              </p>
              <p className="text-slate-500 italic text-xs">
                In both models, your calculated minimum hourly rate serves as your internal baseline floor below which projects become unprofitable.
              </p>
            </div>
          </section>

          {/* Section 8: Reviewing and Updating Your Rate */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              8. When and How to Raise Your Freelance Rate
            </h2>
            <p>
              Your rate should not remain static. Review your numbers annually or whenever the following triggers occur:
            </p>
            <ul className="list-disc pl-5 space-y-1.5 text-xs sm:text-sm text-slate-700">
              <li>
                <strong>Capacity Bottlenecks:</strong> If you are constantly turning away inquiries or your schedule is booked 6+ weeks in advance, demand exceeds supply.
              </li>
              <li>
                <strong>Skill Expansion:</strong> When you acquire specialized industry competencies, such as full-stack app architecture or advanced e-commerce analytics (like auditing{' '}
                <a
                  href="/tools/amazon-profit-calculator"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/tools/amazon-profit-calculator');
                  }}
                  className="text-indigo-600 font-semibold underline"
                >
                  Amazon FBA unit profitability
                </a>
                ).
              </li>
              <li>
                <strong>Macro Inflation:</strong> If living expenses and software fees rise by 5% to 8%, your rates must adjust to preserve real purchasing power.
              </li>
            </ul>
          </section>

          {/* Section 9: Common Mistakes */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              9. Common Mistakes Freelancers Make When Setting Rates
            </h2>
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-rose-50/60 border border-rose-200/70 text-xs sm:text-sm">
                <span className="font-bold text-rose-800 block mb-1">Mistake 1: Competing Solely on Low Price</span>
                <p className="text-slate-600">
                  Low-budget clients often generate the highest scope creep and administrative friction. Compete on reliability, communication speed, and business outcomes instead of race-to-the-bottom hourly rates.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200/70 text-xs sm:text-sm">
                <span className="font-bold text-amber-800 block mb-1">Mistake 2: Forgetting Emergency Reserves</span>
                <p className="text-slate-600">
                  Freelance income fluctuates with client payment terms. If your hourly rate does not generate a surplus for a 3-month operating cushion, slow invoice cycles can cause severe cash-flow crunches.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm">
                <span className="font-bold text-slate-900 block mb-1">Mistake 3: Omitting Revisions and Scope Boundaries</span>
                <p className="text-slate-600">
                  Failing to specify how many revision rounds are included in your agreement will quickly erode your effective hourly rate on fixed deliverables.
                </p>
              </div>
            </div>
          </section>

          {/* Section 10: Conclusion & Call to Action */}
          <section className="p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-indigo-900 to-slate-900 text-white space-y-4 shadow-md">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">
              Action Step
            </span>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              10. Calculate Your Custom Freelance Hourly Rate Today
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
              Take the guesswork out of your freelance business finances. ToolFlow provides a free, dedicated{' '}
              <a
                href="/tools/freelancer-rate-calculator"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('/tools/freelancer-rate-calculator');
                }}
                className="text-white font-bold underline hover:text-indigo-200"
              >
                Freelancer Rate Calculator
              </a>{' '}
              that lets you input your exact desired net earnings, weekly hours, annual weeks worked, business expenses, and estimated tax rates to generate your ideal billable rate instantly.
            </p>
            <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center gap-3">
              <a
                href="/tools/freelancer-rate-calculator"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('/tools/freelancer-rate-calculator');
                }}
                className="inline-flex items-center justify-center font-semibold rounded-lg transition-all text-sm px-4 py-2 gap-2 bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs cursor-pointer"
              >
                <span>Open Freelancer Rate Calculator</span>
                <ArrowRight className="h-4 w-4" />
              </a>
              <a
                href="/tools"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('/tools');
                }}
                className="inline-flex items-center justify-center font-medium rounded-lg transition-all text-sm px-4 py-2 gap-2 border border-slate-600 hover:bg-slate-800 text-white cursor-pointer"
              >
                <span>Explore All Business Tools</span>
              </a>
            </div>
          </section>
        </article>

        {/* Interactive FAQ Section */}
        <section className="mt-16 pt-12 border-t border-slate-200/80 space-y-6">
          <div className="flex items-center gap-2 mb-2">
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Frequently Asked Questions About Freelance Rates
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Key questions about setting, adjusting, and communicating freelance hourly rates.
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200/80 bg-white shadow-xs p-6">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={index} className="py-4 first:pt-0 last:pb-0">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between text-left gap-4 group cursor-pointer focus:outline-none"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                      {item.question}
                    </span>
                    <span className="p-1 rounded-md text-slate-400 group-hover:text-indigo-600 shrink-0">
                      {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="mt-2.5 pr-8 text-xs sm:text-sm text-slate-600 leading-relaxed animate-in fade-in duration-200">
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Related Tool Links */}
        <section className="mt-12 p-6 rounded-2xl bg-white border border-slate-200/80 space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            More Helpful Tools for Freelancers &amp; Independent Operators
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <a
              href="/tools/freelancer-rate-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/freelancer-rate-calculator');
              }}
              className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:border-indigo-400 hover:bg-white transition-all group block"
            >
              <span className="font-bold text-slate-900 group-hover:text-indigo-600 block mb-0.5">
                Freelancer Rate Calculator →
              </span>
              <span className="text-slate-500">Compute your minimum billable rate and monthly target.</span>
            </a>
            <a
              href="/tools/proposal-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/proposal-generator');
              }}
              className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:border-indigo-400 hover:bg-white transition-all group block"
            >
              <span className="font-bold text-slate-900 group-hover:text-indigo-600 block mb-0.5">
                AI Proposal Generator →
              </span>
              <span className="text-slate-500">Generate winning freelance pitches and client proposals.</span>
            </a>
            <a
              href="/tools/social-caption-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/social-caption-generator');
              }}
              className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 hover:border-indigo-400 hover:bg-white transition-all group block"
            >
              <span className="font-bold text-slate-900 group-hover:text-indigo-600 block mb-0.5">
                Social Caption Generator →
              </span>
              <span className="text-slate-500">Craft client case studies and social outreach posts.</span>
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};
