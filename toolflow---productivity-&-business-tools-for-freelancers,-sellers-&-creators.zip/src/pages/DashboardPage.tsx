import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Card } from '../components/common/Card';
import { StatCard } from '../components/common/StatCard';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { ToolCard } from '../components/tools/ToolCard';
import { TOOLS, CREATOR_TOOLS_IDS, matchesToolSearch } from '../data/toolsData';
import { IconHelper } from '../components/common/IconHelper';
import {
  Sparkles,
  Bookmark,
  Clock,
  ArrowRight,
  TrendingUp,
  FileText,
  Calculator,
  Search,
  ExternalLink,
  Star,
  CheckCircle2,
  Trash2,
  Video,
  X,
  Briefcase,
  ShoppingBag,
  Bell,
  Settings,
  Activity,
  Flame,
  Layers,
} from 'lucide-react';
import { AdBanner, ResponsiveLeaderboard, SmartlinkPromo } from '../components/ads';
import { usePageSEO } from '../utils/usePageSEO';

interface DashboardPageProps {
  onNavigate: (path: string) => void;
  initialTab?: string;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate, initialTab }) => {
  usePageSEO({
    title: 'Dashboard | ToolFlow Workspace',
    description: 'Access your saved calculations, favorite tools, and recent workspace activity.',
    canonicalPath: '/dashboard',
    robots: 'noindex, nofollow',
  });

  const { user, savedResults, favorites, recentTools, deleteSavedResult } = useApp();
  const [activeTab, setActiveTab] = useState<'overview' | 'favorites' | 'history'>(
    initialTab === 'favorites' ? 'favorites' : initialTab === 'history' ? 'history' : 'overview'
  );
  const [toolsSearchQuery, setToolsSearchQuery] = useState('');

  // Categorized tool groupings
  const freelancerTools = TOOLS.filter((t) => t.category === 'freelancer');
  const amazonTools = TOOLS.filter((t) => t.category === 'amazon');
  const creatorToolsList = CREATOR_TOOLS_IDS.map((id) => TOOLS.find((t) => t.id === id)).filter(
    Boolean
  ) as typeof TOOLS;

  // Additional creator tools (e.g. social caption & engagement calculator)
  const allCreatorTools = TOOLS.filter((t) => t.category === 'creator');

  // Featured tools list (top 4 primary tools)
  const featuredTools = [
    TOOLS.find((t) => t.id === 'proposal-generator'),
    TOOLS.find((t) => t.id === 'amazon-profit-calculator'),
    TOOLS.find((t) => t.id === 'trend-radar'),
    TOOLS.find((t) => t.id === 'hook-doctor'),
  ].filter(Boolean) as typeof TOOLS;

  // Resolved favorites & recent
  const favoriteToolsList = TOOLS.filter((t) => favorites.includes(t.id));
  const recentToolsList = recentTools
    .map((id) => TOOLS.find((t) => t.id === id))
    .filter(Boolean) as typeof TOOLS;

  // Filtered tools when searching
  const searchedTools = TOOLS.filter((tool) => matchesToolSearch(tool, toolsSearchQuery));

  const activeNavValue =
    activeTab === 'favorites' ? 'favorites' : activeTab === 'history' ? 'history' : 'dashboard';

  return (
    <DashboardLayout
      currentPath="/dashboard"
      onNavigate={onNavigate}
      activeNav={activeNavValue}
    >
      <div className="space-y-8 pb-12">
        {/* Top Header Section */}
        <div className="rounded-2xl bg-[#0f131f] border border-zinc-800/80 p-6 sm:p-7 relative overflow-hidden shadow-sm">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 relative z-10">
            <div>
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-semibold mb-3 border border-indigo-500/20">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Productivity Suite</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                Welcome back 👋
              </h1>
              <p className="text-xs sm:text-sm text-zinc-400 mt-1.5 leading-relaxed max-w-xl">
                Manage your work, selling, and creator tools from one place.
              </p>
            </div>

            {/* Profile & Quick Navigation Controls */}
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-3 px-3.5 py-2 rounded-xl bg-zinc-900/90 border border-zinc-800 text-xs text-zinc-300">
                <img
                  src={
                    user?.avatarUrl ||
                    `https://api.dicebear.com/7.x/initials/svg?seed=${user?.name || 'Alex'}`
                  }
                  alt={user?.name || 'Alex'}
                  className="h-7 w-7 rounded-full bg-zinc-800 border border-zinc-700 object-cover shrink-0"
                />
                <div>
                  <p className="font-semibold text-white leading-none">{user?.name || 'Alex'}</p>
                  <span className="text-[10px] text-zinc-400 font-mono mt-0.5 inline-block">
                    {user?.plan ? `${user.plan.toUpperCase()} Tier` : 'PRO Tier'}
                  </span>
                </div>
              </div>

              <button
                onClick={() => onNavigate('/settings')}
                className="p-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700 transition-colors cursor-pointer"
                title="Workspace Settings"
                aria-label="Settings"
              >
                <Settings className="h-4 w-4" />
              </button>

              <button
                onClick={() => onNavigate('/tools')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                <Layers className="h-4 w-4" />
                <span>All 13 Tools</span>
              </button>
            </div>
          </div>
        </div>

        {/* Quick Stats Section */}
        <div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-3 px-1">
            Workspace Overview
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              label="Total Tools"
              value={TOOLS.length}
              subtext="Freelancer, Amazon & Creator"
              icon={<Layers className="h-5 w-5 text-indigo-400" />}
              dark
            />
            <StatCard
              label="Tasks Used"
              value={recentTools.length > 0 ? recentTools.length : 3}
              subtext="Active tools launched"
              icon={<Activity className="h-5 w-5 text-emerald-400" />}
              dark
            />
            <StatCard
              label="Saved Results"
              value={savedResults.length}
              subtext="Calculations & pitches"
              icon={<Bookmark className="h-5 w-5 text-amber-400" />}
              dark
            />
            <StatCard
              label="Current Plan"
              value={user?.plan ? `${user.plan.toUpperCase()} Tier` : 'PRO Tier'}
              subtext="Unlimited generations active"
              icon={<Sparkles className="h-5 w-5 text-purple-400" />}
              variant="highlight"
              dark
            />
          </div>
        </div>

        {/* Large Professional Tools Search Bar */}
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 pl-4 flex items-center text-zinc-500">
            <Search className="h-5 w-5" />
          </div>
          <input
            type="text"
            className="block w-full pl-12 pr-10 py-3.5 bg-[#11141f] rounded-xl border border-zinc-800/90 hover:border-zinc-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-sm text-white placeholder:text-zinc-500 shadow-sm transition-all"
            placeholder="Search tools…"
            value={toolsSearchQuery}
            onChange={(e) => setToolsSearchQuery(e.target.value)}
          />
          {toolsSearchQuery && (
            <button
              onClick={() => setToolsSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-zinc-400 hover:text-white cursor-pointer"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Tab Controls: Overview / Favorites / History */}
        {!toolsSearchQuery.trim() && (
          <div className="flex items-center gap-2 border-b border-zinc-800/80 pb-3">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-zinc-800 text-white border border-zinc-700/80'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('favorites')}
              className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'favorites'
                  ? 'bg-zinc-800 text-white border border-zinc-700/80'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              <Star className="h-3.5 w-3.5 text-amber-400" />
              <span>Favorites ({favorites.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'history'
                  ? 'bg-zinc-800 text-white border border-zinc-700/80'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              <Clock className="h-3.5 w-3.5 text-zinc-400" />
              <span>Recently Used ({recentToolsList.length})</span>
            </button>
          </div>
        )}

        {/* Search Mode: Displays Search Results */}
        {toolsSearchQuery.trim() ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-white tracking-tight">Search Results</h3>
                <p className="text-xs text-zinc-400">
                  {searchedTools.length} {searchedTools.length === 1 ? 'tool' : 'tools'} matching "
                  {toolsSearchQuery}"
                </p>
              </div>
              <button
                onClick={() => setToolsSearchQuery('')}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
              >
                Clear Search
              </button>
            </div>

            {searchedTools.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {searchedTools.map((tool) => (
                  <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} variant="dark" />
                ))}
              </div>
            ) : (
              <div className="p-12 text-center bg-[#11141f] rounded-2xl border border-dashed border-zinc-800">
                <Search className="h-8 w-8 text-zinc-600 mx-auto mb-3" />
                <h4 className="text-base font-semibold text-white">No tools found. Try another search.</h4>
                <p className="text-xs text-zinc-400 max-w-sm mx-auto mt-1 mb-5">
                  Try searching for "Amazon", "PPC", "proposal", "creator", "hashtags", "hooks", or
                  "trends".
                </p>
                <Button variant="outline" size="sm" onClick={() => setToolsSearchQuery('')}>
                  Reset Search
                </Button>
              </div>
            )}
          </div>
        ) : (
          <>
            {/* OVERVIEW TAB CONTENT */}
            {activeTab === 'overview' && (
              <div className="space-y-10">
                {/* 1. Featured Tools Section */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        <Flame className="h-4 w-4" />
                      </div>
                      <div>
                        <h3 className="text-base font-bold text-white tracking-tight">Featured Tools</h3>
                        <p className="text-xs text-zinc-400">
                          Handpicked high-impact tools for client proposals, Amazon audits, and creator growth.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {featuredTools.map((tool) => (
                      <ToolCard
                        key={tool.id}
                        tool={tool}
                        onNavigate={onNavigate}
                        compact
                        variant="dark"
                      />
                    ))}
                  </div>
                </div>

                {/* 2. Freelancer Tools Section */}
                <div className="p-6 rounded-2xl bg-[#0f131f] border border-zinc-800/80 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-zinc-800/80">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                        <Briefcase className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-bold text-white tracking-tight">Freelancer Tools</h3>
                          <span className="text-[10px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-400 px-2 py-0.5 rounded-full border border-indigo-500/30">
                            {freelancerTools.length} Tools
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400 mt-0.5">
                          Win contracts, craft tailored proposals, and price billable project rates.
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => onNavigate('/tools?category=freelancer')}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-400 hover:text-white transition-colors cursor-pointer self-start sm:self-center"
                    >
                      <span>View Suite</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {freelancerTools.map((tool) => (
                      <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} variant="dark" />
                    ))}
                  </div>
                </div>

                {/* 3. Amazon Seller Tools Section */}
                <div className="p-6 rounded-2xl bg-[#0f131f] border border-zinc-800/80 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-zinc-800/80">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                        <ShoppingBag className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-bold text-white tracking-tight">Amazon Seller Tools</h3>
                          <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/30">
                            {amazonTools.length} Tools
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400 mt-0.5">
                          Calculate FBA unit economics, audit PPC ACOS thresholds, and build keyword clusters.
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => onNavigate('/tools?category=amazon')}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-400 hover:text-white transition-colors cursor-pointer self-start sm:self-center"
                    >
                      <span>View Suite</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {amazonTools.map((tool) => (
                      <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} variant="dark" />
                    ))}
                  </div>
                </div>

                {/* 4. Creator Tools Section */}
                <div className="p-6 rounded-2xl bg-[#0f131f] border border-zinc-800/80 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-zinc-800/80">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
                        <Video className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-bold text-white tracking-tight">Creator Tools</h3>
                          <span className="text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-400 px-2 py-0.5 rounded-full border border-rose-500/30">
                            {creatorToolsList.length} Dedicated Tools
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400 mt-0.5">
                          Discover trending topics, find content gaps, audit video hooks, analyze retention, and test A/B variations.
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => onNavigate('/tools?category=creator')}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-400 hover:text-white transition-colors cursor-pointer self-start sm:self-center"
                    >
                      <span>View Suite</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {creatorToolsList.map((tool) => (
                      <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} variant="dark" />
                    ))}
                  </div>
                </div>

                {/* 5. Recent Activity Section */}
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-3 px-1">
                    Recent Activity
                  </h3>
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    {/* Left: Saved Results Activity */}
                    <div className="lg:col-span-7">
                      <div className="p-5 sm:p-6 rounded-2xl bg-[#11141f] border border-zinc-800/80 shadow-xs">
                        <div className="flex items-center justify-between pb-4 border-b border-zinc-800/80 mb-4">
                          <div>
                            <h4 className="text-sm font-bold text-white">Saved Records & Exports</h4>
                            <p className="text-xs text-zinc-400">Calculations, copy, and strategies</p>
                          </div>
                          <button
                            onClick={() => onNavigate('/saved')}
                            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
                          >
                            View All ({savedResults.length})
                          </button>
                        </div>

                        {savedResults.length > 0 ? (
                          <div className="space-y-2.5">
                            {savedResults.slice(0, 4).map((item) => (
                              <div
                                key={item.id}
                                className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800/80 hover:border-zinc-700 transition-colors flex items-start justify-between gap-3"
                              >
                                <div className="min-w-0 flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded">
                                      {item.toolName}
                                    </span>
                                    <span className="text-[10px] text-zinc-500">
                                      {new Date(item.createdAt).toLocaleDateString()}
                                    </span>
                                  </div>
                                  <h5 className="text-xs sm:text-sm font-bold text-white truncate">
                                    {item.title}
                                  </h5>
                                  <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">
                                    {item.preview}
                                  </p>
                                </div>

                                <div className="flex items-center gap-1 shrink-0">
                                  <button
                                    onClick={() => onNavigate('/saved')}
                                    className="px-2.5 py-1 text-xs font-medium rounded-lg bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-white border border-zinc-700/80 transition-colors cursor-pointer"
                                  >
                                    Open
                                  </button>
                                  <button
                                    onClick={() => deleteSavedResult(item.id)}
                                    className="p-1.5 text-zinc-500 hover:text-rose-400 rounded-md transition-colors cursor-pointer"
                                    title="Delete record"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-xs text-zinc-500">
                            No recent activity yet.
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right: Recently Used Fast Links */}
                    <div className="lg:col-span-5">
                      <div className="p-5 sm:p-6 rounded-2xl bg-[#11141f] border border-zinc-800/80 shadow-xs">
                        <h4 className="text-sm font-bold text-white mb-1">Recently Used Utilities</h4>
                        <p className="text-xs text-zinc-400 mb-4">Quick launch your recent workflows</p>

                        {recentToolsList.length > 0 ? (
                          <div className="space-y-2">
                            {recentToolsList.slice(0, 5).map((tool) => (
                              <button
                                key={tool.id}
                                onClick={() => onNavigate(tool.path)}
                                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800/80 hover:border-zinc-700 text-left transition-colors cursor-pointer group"
                              >
                                <div className="flex items-center gap-3">
                                  <div className="p-2 rounded-lg bg-zinc-800 text-zinc-300 group-hover:bg-indigo-500/20 group-hover:text-indigo-400 transition-colors border border-zinc-700/60">
                                    <IconHelper name={tool.iconName} className="h-4 w-4" />
                                  </div>
                                  <div>
                                    <p className="text-xs font-bold text-white group-hover:text-indigo-400 transition-colors">
                                      {tool.name}
                                    </p>
                                    <span className="text-[10px] text-zinc-500 uppercase font-semibold">
                                      {tool.categoryLabel}
                                    </span>
                                  </div>
                                </div>
                                <ArrowRight className="h-3.5 w-3.5 text-zinc-500 group-hover:text-indigo-400 group-hover:translate-x-0.5 transition-transform" />
                              </button>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-xs text-zinc-500">
                            No recent activity yet.
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Dashboard Ad Units in dark styled container */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center pt-2">
                  <div className="flex justify-center p-4 rounded-2xl bg-[#11141f] border border-zinc-800/80">
                    <AdBanner size="300x250" />
                  </div>
                  <SmartlinkPromo
                    variant="card"
                    title="Verified Freelancer & Creator Deals"
                    description="Exclusive discounts, high-ticket freelance client opportunities, and growth resources."
                  />
                </div>

                {/* Responsive Leaderboard banner */}
                <div className="pt-2 flex justify-center">
                  <ResponsiveLeaderboard />
                </div>
              </div>
            )}

            {/* FAVORITES TAB CONTENT */}
            {activeTab === 'favorites' && (
              <div>
                <h3 className="text-base font-bold text-white mb-4">
                  Your Pinned Favorites ({favoriteToolsList.length})
                </h3>
                {favoriteToolsList.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {favoriteToolsList.map((tool) => (
                      <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} variant="dark" />
                    ))}
                  </div>
                ) : (
                  <div className="p-12 text-center bg-[#11141f] rounded-2xl border border-dashed border-zinc-800">
                    <Star className="h-8 w-8 text-amber-400 mx-auto mb-2" />
                    <h4 className="text-base font-semibold text-white">No favorites pinned</h4>
                    <p className="text-xs text-zinc-400 max-w-sm mx-auto mt-1 mb-4">
                      Click the star icon on any tool card in the directory to pin your top tools here.
                    </p>
                    <button
                      onClick={() => onNavigate('/tools')}
                      className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold cursor-pointer transition-colors"
                    >
                      Explore Tools Directory
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* HISTORY TAB CONTENT */}
            {activeTab === 'history' && (
              <div>
                <h3 className="text-base font-bold text-white mb-4">
                  Recently Opened Utilities ({recentToolsList.length})
                </h3>
                {recentToolsList.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {recentToolsList.map((tool) => (
                      <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} variant="dark" />
                    ))}
                  </div>
                ) : (
                  <div className="p-12 text-center bg-[#11141f] rounded-2xl border border-dashed border-zinc-800">
                    <Clock className="h-8 w-8 text-zinc-500 mx-auto mb-2" />
                    <h4 className="text-base font-semibold text-white">No recent activity yet.</h4>
                    <p className="text-xs text-zinc-400 max-w-sm mx-auto mt-1 mb-4">
                      As you use tools and calculators, your recently accessed tools will appear here.
                    </p>
                    <button
                      onClick={() => onNavigate('/tools')}
                      className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold cursor-pointer transition-colors"
                    >
                      Launch a Tool
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
};
