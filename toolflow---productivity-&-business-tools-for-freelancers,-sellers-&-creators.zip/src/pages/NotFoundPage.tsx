import React from 'react';
import { Button } from '../components/common/Button';
import { usePageSEO } from '../utils/usePageSEO';
import { ArrowLeft, Home, Grid } from 'lucide-react';

interface NotFoundPageProps {
  onNavigate: (path: string) => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: '404 – Page Not Found | ToolFlow',
    description: "The page you are looking for doesn't exist on ToolFlow.",
    canonicalPath: '/',
    robots: 'noindex, nofollow',
  });

  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 py-16 text-center">
      <span className="text-5xl sm:text-6xl font-extrabold text-indigo-600 font-mono tracking-tight mb-2">
        404
      </span>
      <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
        Page Not Found
      </h1>
      <p className="text-sm text-slate-500 max-w-md mb-8">
        The tool or page you are looking for doesn't exist or has moved. Explore our tools directory or head back to the dashboard.
      </p>

      <div className="flex flex-col sm:flex-row items-center gap-3">
        <Button
          variant="primary"
          size="md"
          href="/"
          onNavigate={onNavigate}
          leftIcon={<Home className="h-4 w-4" />}
        >
          Return Home
        </Button>
        <Button
          variant="outline"
          size="md"
          href="/tools"
          onNavigate={onNavigate}
          leftIcon={<Grid className="h-4 w-4" />}
        >
          Browse All Tools
        </Button>
      </div>
    </div>
  );
};
