import React from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { usePageSEO } from '../utils/usePageSEO';
import { Shield, Lock, Eye, FileText, CheckCircle2, ArrowLeft } from 'lucide-react';

interface PrivacyPolicyPageProps {
  onNavigate: (path: string) => void;
}

export const PrivacyPolicyPage: React.FC<PrivacyPolicyPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Privacy Policy | ToolFlow',
    description:
      'Read the ToolFlow Privacy Policy. Learn how we handle your browser data, calculations, third-party advertising partners, and privacy rights.',
    canonicalPath: '/privacy',
    robots: 'index, follow',
  });

  const { brandName } = useApp();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
      {/* Back link */}
      <div className="mb-6">
        <a
          href="/"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Home
        </a>
      </div>

      {/* Header */}
      <div className="mb-10 pb-6 border-b border-slate-200">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/70 text-indigo-700 text-xs font-semibold mb-4">
          <Shield className="h-3.5 w-3.5" />
          <span>Legal & Transparency</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Privacy Policy
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          Effective Date: October 2026 &bull; Last Updated: October 2026
        </p>
      </div>

      {/* Content */}
      <div className="space-y-8 text-slate-700 text-sm leading-relaxed">
        {/* Section 1 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Eye className="h-5 w-5 text-indigo-600" />
            1. Overview &amp; Commitment
          </h2>
          <p>
            At {brandName}, we prioritize user privacy, data security, and operational transparency.
            This Privacy Policy outlines how our web applications, calculators, generators, and workspace utilities collect, handle, and protect your information when you visit and use our services.
          </p>
          <p>
            Most tools on {brandName} (such as our Freelancer Rate Calculator, Amazon Profit Calculator, and Engagement Rate Calculator) perform computations locally in your web browser without transmitting your input variables to external servers.
          </p>
        </Card>

        {/* Section 2 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <FileText className="h-5 w-5 text-indigo-600" />
            2. Information We Collect
          </h2>
          <div className="space-y-2">
            <h3 className="font-semibold text-slate-900">A. Browser Local Storage Data</h3>
            <p>
              When you use our workspace features (such as saving calculation audits, proposals, or customizing your preferred currency), this data is stored in your web browser&apos;s local storage. You retain total control over this data and may clear it at any time directly through your browser or the Workspace Settings page.
            </p>
          </div>
          <div className="space-y-2 pt-2">
            <h3 className="font-semibold text-slate-900">B. AI Generation Inputs</h3>
            <p>
              When using AI-assisted utilities (such as the AI Proposal Generator or Social Caption Generator), the prompt variables you supply are processed through our secure server-side API proxy to generate the requested output via Google Gemini. These inputs are used strictly to generate your requested content and are not used to train private personal profiles.
            </p>
          </div>
          <div className="space-y-2 pt-2">
            <h3 className="font-semibold text-slate-900">C. Server Logs &amp; Technical Diagnostics</h3>
            <p>
              Like most web services, our hosting environment automatically logs non-identifying technical data including HTTP request methods, response status codes, browser user-agent strings, and timestamps to maintain infrastructure security and detect abusive traffic.
            </p>
          </div>
        </Card>

        {/* Section 3 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Lock className="h-5 w-5 text-indigo-600" />
            3. Third-Party Advertising &amp; Analytics
          </h2>
          <p>
            To keep our core productivity tools and business calculators freely accessible to users worldwide, {brandName} partners with third-party digital advertising networks, including Adsterra and Monetag.
          </p>
          <ul className="list-disc list-inside space-y-1.5 pl-2 text-slate-600">
            <li>
              Advertising partners may use cookies, web beacons, or browser service workers (such as sw.js) to deliver relevant advertisements and measure ad performance.
            </li>
            <li>
              These ad networks operate under their respective privacy policies. They do not have access to your private calculator financial values or generated proposal texts stored in your browser session.
            </li>
            <li>
              You can manage cookie settings or opt out of personalized interest-based advertising through your browser&apos;s cookie management controls or through standard industry opt-out portals (such as the Digital Advertising Alliance or Network Advertising Initiative).
            </li>
          </ul>
        </Card>

        {/* Section 4 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-indigo-600" />
            4. How We Use and Protect Information
          </h2>
          <p>
            We do not sell, rent, or trade your personal information. Any data processed by {brandName} is used exclusively to:
          </p>
          <ul className="list-disc list-inside space-y-1 pl-2 text-slate-600">
            <li>Provide real-time calculation results and AI-generated outputs.</li>
            <li>Maintain application stability, prevent spam, and secure server endpoints.</li>
            <li>Enable seamless client-side saving and exporting of your work.</li>
          </ul>
        </Card>

        {/* Section 5 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Shield className="h-5 w-5 text-indigo-600" />
            5. Your Rights &amp; Data Control
          </h2>
          <p>
            You have the right to inspect, export, and delete any data stored in your workspace. Because your results are saved locally in your browser&apos;s storage, you can erase all saved results instantly by clicking &quot;Clear All&quot; in the Saved Results page or by clearing your browser cache and cookies.
          </p>
        </Card>

        {/* Section 6 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <FileText className="h-5 w-5 text-indigo-600" />
            6. Changes to This Privacy Policy
          </h2>
          <p>
            We may update this Privacy Policy from time to time to reflect operational, legal, or regulatory modifications. Any revisions will be reflected on this page with an updated &quot;Last Updated&quot; timestamp.
          </p>
          <div className="pt-2">
            <p>
              If you have any questions or concerns regarding this policy, please reach out through our{' '}
              <a
                href="/contact"
                onClick={(e) => {
                  if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                    e.preventDefault();
                    onNavigate('/contact');
                  }
                }}
                className="text-indigo-600 font-semibold hover:underline"
              >
                Contact Page
              </a>
              .
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};
