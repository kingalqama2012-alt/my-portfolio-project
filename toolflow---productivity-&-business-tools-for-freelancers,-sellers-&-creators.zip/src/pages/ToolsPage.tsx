import React, { useState, useMemo } from 'react';
import { TOOLS, CATEGORIES, matchesToolSearch } from '../data/toolsData';
import { ToolCard } from '../components/tools/ToolCard';
import { EmptyState } from '../components/common/EmptyState';
import { Search, Grid, Filter, Sparkles, X } from 'lucide-react';
import { ResponsiveLeaderboard, AdBanner, NativeAdBanner } from '../components/ads';
import { usePageSEO } from '../utils/usePageSEO';

interface ToolsPageProps {
  onNavigate: (path: string) => void;
  initialCategory?: string;
}

export const ToolsPage: React.FC<ToolsPageProps> = ({ onNavigate, initialCategory }) => {
  usePageSEO({
    title: 'All Productivity & Business Tools | ToolFlow Directory',
    description:
      "Browse ToolFlow's complete directory of free productivity calculators, AI generators, and business utilities for freelancers, Amazon sellers, and creators.",
    canonicalPath: '/tools',
    robots: 'index, follow',
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory || 'all');

  const filterTabs = [
    { id: 'all', label: 'All Tools', count: TOOLS.length },
    { id: 'freelancer', label: 'Freelancers', count: TOOLS.filter((t) => t.category === 'freelancer').length },
    { id: 'amazon', label: 'Amazon', count: TOOLS.filter((t) => t.category === 'amazon').length },
    { id: 'creator', label: 'Creators', count: TOOLS.filter((t) => t.category === 'creator').length },
  ];

  const filteredTools = useMemo(() => {
    return TOOLS.filter((tool) => {
      const matchesCategory =
        selectedCategory === 'all' || tool.category === selectedCategory;

      const matchesSearch = matchesToolSearch(tool, searchQuery);

      return matchesCategory && matchesSearch;
    });
  }, [searchQuery, selectedCategory]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12">
      {/* Header Section */}
      <div className="text-center max-w-2xl mx-auto mb-8">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          All Tools
        </h1>
        <p className="text-base text-slate-500 mt-2">
          Choose a tool to simplify your work.
        </p>
      </div>

      {/* Adsterra Top Leaderboard (728x90 desktop / 320x50 mobile) */}
      <div className="mb-8 flex justify-center">
        <ResponsiveLeaderboard />
      </div>

      {/* Search Bar & Category Filter Controls */}
      <div className="max-w-4xl mx-auto mb-10 space-y-4">
        {/* Search Input */}
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 pl-4 flex items-center text-slate-400">
            <Search className="h-5 w-5" />
          </div>
          <input
            type="text"
            className="block w-full pl-11 pr-10 py-3.5 bg-white rounded-xl border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-xs transition-shadow"
            placeholder="Search tools..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
          {filterTabs.map((tab) => {
            const isActive = selectedCategory === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedCategory(tab.id)}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-2 ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`text-[11px] px-1.5 py-0.2 rounded-full font-mono ${
                    isActive ? 'bg-slate-800 text-slate-200' : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tool Grid or Empty State */}
      {filteredTools.length > 0 ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTools.map((tool) => (
              <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} />
            ))}
          </div>

          {/* Adsterra Standard Banner 468x60 */}
          <div className="mt-12 flex justify-center">
            <AdBanner size="468x60" />
          </div>

          {/* Adsterra Native Banner */}
          <div className="mt-8">
            <NativeAdBanner />
          </div>
        </>
      ) : (
        <div className="max-w-md mx-auto">
          <EmptyState
            icon={<Search className="h-6 w-6" />}
            title="No tools found. Try another search."
            description={`We couldn't find any tools matching "${searchQuery}". Try a different keyword or reset filters.`}
            actionText="Reset Search"
            onAction={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
          />
        </div>
      )}
    </div>
  );
};

