import React from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { usePageSEO } from '../utils/usePageSEO';
import { FileCheck, AlertTriangle, Scale, Shield, ArrowLeft } from 'lucide-react';

interface TermsOfServicePageProps {
  onNavigate: (path: string) => void;
}

export const TermsOfServicePage: React.FC<TermsOfServicePageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Terms of Service | ToolFlow',
    description:
      'Review the Terms of Service for ToolFlow regarding the use of our online calculators, AI generators, productivity tools, and disclaimers.',
    canonicalPath: '/terms',
    robots: 'index, follow',
  });

  const { brandName } = useApp();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
      {/* Back link */}
      <div className="mb-6">
        <a
          href="/"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Home
        </a>
      </div>

      {/* Header */}
      <div className="mb-10 pb-6 border-b border-slate-200">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/70 text-indigo-700 text-xs font-semibold mb-4">
          <Scale className="h-3.5 w-3.5" />
          <span>User Agreement</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Terms of Service
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          Effective Date: October 2026 &bull; Last Updated: October 2026
        </p>
      </div>

      {/* Content */}
      <div className="space-y-8 text-slate-700 text-sm leading-relaxed">
        {/* Section 1 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <FileCheck className="h-5 w-5 text-indigo-600" />
            1. Agreement to Terms
          </h2>
          <p>
            By accessing or using {brandName} (including all associated websites, subpaths, calculators, and API endpoints), you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, please discontinue use of the platform immediately.
          </p>
        </Card>

        {/* Section 2 - Important Disclaimer */}
        <Card className="p-6 bg-amber-50/50 border-amber-200 space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            2. Calculator Formulas &amp; Informational Disclaimer
          </h2>
          <p className="text-slate-800">
            <strong>Important Notice:</strong> All calculators and financial diagnostic tools provided by {brandName} (including the Amazon Profit Calculator, Amazon PPC Calculator, Freelancer Rate Calculator, and Engagement Rate Calculator) are designed for informational and estimation purposes only.
          </p>
          <ul className="list-disc list-inside space-y-1.5 pl-2 text-slate-700">
            <li>
              <strong>Amazon Fees &amp; Marketplace Policies:</strong> Amazon referral fees, FBA fulfillment fees, storage surcharges, and advertising CPC rates are subject to change by Amazon at any time. Sellers should always cross-verify figures with their official Amazon Seller Central reports.
            </li>
            <li>
              <strong>Tax &amp; Legal Advice:</strong> Freelance hourly rate estimations and self-employment tax calculations are general models and do not constitute formal certified public accounting (CPA) advice or legal counsel.
            </li>
            <li>
              <strong>No Warranty of Profitability:</strong> {brandName} makes no guarantees regarding financial returns, ad campaign success, or client acquisition outcomes based on tool calculations.
            </li>
          </ul>
        </Card>

        {/* Section 3 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Shield className="h-5 w-5 text-indigo-600" />
            3. AI-Generated Content &amp; Acceptable Use
          </h2>
          <p>
            When using our AI generators (including the AI Proposal Generator, Social Caption Generator, and Creator utilities):
          </p>
          <ul className="list-disc list-inside space-y-1.5 pl-2 text-slate-600">
            <li>
              You are responsible for reviewing, verifying, and editing all generated content prior to sending proposals to clients or publishing captions online.
            </li>
            <li>
              You agree not to use our tools to generate unlawful, defamatory, deceptive, fraudulent, or harassing material.
            </li>
            <li>
              You retain ownership of the customized prompts you submit and the resulting text outputs generated for your work.
            </li>
          </ul>
        </Card>

        {/* Section 4 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Scale className="h-5 w-5 text-indigo-600" />
            4. Intellectual Property &amp; Brand Rights
          </h2>
          <p>
            The software, design system, illustrations, code, and branding of {brandName} are the intellectual property of the service operators and are protected by applicable copyright and trademark laws. You may not copy, reverse engineer, or redistribute our software architecture without prior written authorization.
          </p>
        </Card>

        {/* Section 5 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-indigo-600" />
            5. Limitation of Liability
          </h2>
          <p>
            In no event shall {brandName}, its creators, or its affiliates be liable for any indirect, incidental, special, consequential, or punitive damages, including loss of profits, data, or business opportunities, arising out of your access to or inability to use the platform.
          </p>
        </Card>

        {/* Section 6 */}
        <Card className="p-6 bg-white space-y-3">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <FileCheck className="h-5 w-5 text-indigo-600" />
            6. Inquiries &amp; Contact
          </h2>
          <p>
            For questions regarding these Terms of Service or to submit general inquiries, please visit our{' '}
            <a
              href="/contact"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/contact');
                }
              }}
              className="text-indigo-600 font-semibold hover:underline"
            >
              Contact Page
            </a>
            .
          </p>
        </Card>
      </div>
    </div>
  );
};
