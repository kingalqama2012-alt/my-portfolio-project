import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/common/Button';
import { Input } from '../components/common/Input';
import { Card } from '../components/common/Card';
import { usePageSEO } from '../utils/usePageSEO';
import { Layers, Lock, Mail, User, CheckCircle2 } from 'lucide-react';

interface SignupPageProps {
  onNavigate: (path: string) => void;
}

export const SignupPage: React.FC<SignupPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Create Your Free Account | ToolFlow',
    description: 'Sign up for a free ToolFlow account to save calculator results and sync your workspace.',
    canonicalPath: '/signup',
    robots: 'noindex, nofollow',
  });

  const { brandName, login, addToast } = useApp();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.name.trim() || !formData.email.trim() || !formData.password.trim()) {
      setError('Please fill in all required fields.');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match. Please verify.');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    login(formData.email, formData.name);
    addToast({
      title: 'Account Created',
      message: `Welcome to ${brandName}, ${formData.name}!`,
      type: 'success',
    });
    onNavigate('/dashboard');
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <button
            onClick={() => onNavigate('/')}
            className="inline-flex items-center gap-2 mb-4 group cursor-pointer"
          >
            <div className="h-9 w-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs group-hover:bg-indigo-700 transition-colors">
              <Layers className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">{brandName}</span>
          </button>
          <h1 className="text-2xl font-extrabold text-slate-900">Create Free Account</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Access every business calculator, AI generator, and save your project results.
          </p>
        </div>

        <Card className="p-6 sm:p-8 bg-white shadow-sm border-slate-200">
          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Full Name"
              type="text"
              placeholder="e.g. Alex Morgan"
              leftPrefix={<User className="h-4 w-4 text-slate-400" />}
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />

            <Input
              label="Work Email"
              type="email"
              placeholder="alex@example.com"
              leftPrefix={<Mail className="h-4 w-4 text-slate-400" />}
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />

            <Input
              label="Password"
              type="password"
              placeholder="At least 6 characters"
              leftPrefix={<Lock className="h-4 w-4 text-slate-400" />}
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />

            <Input
              label="Confirm Password"
              type="password"
              placeholder="Re-enter password"
              leftPrefix={<Lock className="h-4 w-4 text-slate-400" />}
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              required
            />

            <div className="pt-2">
              <Button type="submit" variant="primary" size="md" className="w-full font-semibold">
                Complete Registration
              </Button>
            </div>

            <p className="text-[11px] text-slate-400 text-center leading-relaxed">
              By creating an account, you agree to our Terms of Service and Privacy Policy.
            </p>
          </form>

          <div className="mt-6 pt-4 border-t border-slate-100 text-center text-xs text-slate-500">
            Already have an account?{' '}
            <button
              onClick={() => onNavigate('/login')}
              className="text-indigo-600 font-semibold hover:underline cursor-pointer"
            >
              Sign In
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
};
