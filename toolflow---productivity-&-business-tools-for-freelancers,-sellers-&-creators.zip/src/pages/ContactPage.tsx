import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Input } from '../components/common/Input';
import { Select } from '../components/common/Select';
import { usePageSEO } from '../utils/usePageSEO';
import {
  Mail,
  MessageSquare,
  Send,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  ArrowLeft,
  ArrowRight,
} from 'lucide-react';

interface ContactPageProps {
  onNavigate: (path: string) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Contact Support & Feedback | ToolFlow',
    description:
      'Contact the ToolFlow team with tool feedback, bug reports, feature suggestions, or business inquiries.',
    canonicalPath: '/contact',
    robots: 'index, follow',
  });

  const { brandName, addToast } = useApp();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: 'feedback',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      addToast({
        title: 'Missing Fields',
        message: 'Please complete all required fields.',
        type: 'warning',
      });
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      addToast({
        title: 'Feedback Received',
        message: 'Thank you! Your submission has been received by our product team.',
        type: 'success',
      });
    }, 400);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      topic: 'feedback',
      message: '',
    });
    setSubmitted(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
      {/* Back link */}
      <div className="mb-6">
        <a
          href="/"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Home
        </a>
      </div>

      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
          Get in Touch
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mt-3 mb-3">
          Contact &amp; Feedback
        </h1>
        <p className="text-base text-slate-600 leading-relaxed">
          Have an idea for a new calculator, found a bug, or have a partnership inquiry? We welcome your input to improve {brandName}.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        {/* Left Side: Helpful Information */}
        <div className="md:col-span-5 space-y-6">
          <Card className="p-6 bg-white space-y-4">
            <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <MessageSquare className="h-5 w-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-900">
              How Can We Help?
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {brandName} is continually adding new calculations and refining existing formulas for freelancers, sellers, and creators.
            </p>
            <div className="space-y-3 pt-2 text-xs text-slate-600">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Bug Reports:</strong> Encountered a formula discrepancy or UI issue? Let us know the browser and tool.
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <Sparkles className="h-4 w-4 text-indigo-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Feature Requests:</strong> Suggest a new calculator or AI generator for your industry workflow.
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <HelpCircle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Partnership:</strong> Inquire about affiliate integrations or specialized tools.
                </span>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-slate-50 border-slate-200/80">
            <h3 className="text-sm font-bold text-slate-900 mb-2">
              Looking for Immediate Answers?
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Explore our comprehensive tools directory or review our detailed guides to learn how our calculators operate.
            </p>
            <div className="space-y-2">
              <a
                href="/tools"
                onClick={(e) => {
                  if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                    e.preventDefault();
                    onNavigate('/tools');
                  }
                }}
                className="flex items-center justify-between text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-white p-2.5 rounded-lg border border-slate-200"
              >
                <span>Browse All Tools</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </a>
              <a
                href="/guides/how-to-calculate-freelance-hourly-rate"
                onClick={(e) => {
                  if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                    e.preventDefault();
                    onNavigate('/guides/how-to-calculate-freelance-hourly-rate');
                  }
                }}
                className="flex items-center justify-between text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-white p-2.5 rounded-lg border border-slate-200"
              >
                <span>Freelance Rate Guide</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </a>
            </div>
          </Card>
        </div>

        {/* Right Side: Form */}
        <div className="md:col-span-7">
          <Card className="p-6 sm:p-8 bg-white shadow-xs">
            {submitted ? (
              <div className="text-center py-10 space-y-4">
                <div className="h-14 w-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">
                  Message Sent Successfully!
                </h3>
                <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                  Thank you for reaching out, <strong>{formData.name}</strong>. Your feedback regarding{' '}
                  <span className="font-semibold">{formData.topic}</span> has been logged for our product development team.
                </p>
                <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
                  <Button variant="primary" size="sm" href="/tools" onNavigate={onNavigate}>
                    Back to Tools
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleReset}>
                    Send Another Message
                  </Button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex items-center gap-2 mb-2 pb-3 border-b border-slate-100">
                  <Mail className="h-4 w-4 text-indigo-600" />
                  <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                    Send a Message
                  </h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input
                    label="Your Name"
                    placeholder="e.g. Jordan Smith"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />

                  <Input
                    label="Email Address"
                    type="email"
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>

                <Select
                  label="Topic / Inquiry Type"
                  value={formData.topic}
                  onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  options={[
                    { label: 'Tool Feedback or Suggestion', value: 'feedback' },
                    { label: 'Bug Report / Formula Issue', value: 'bug' },
                    { label: 'Feature Request / New Tool', value: 'feature' },
                    { label: 'Partnership or Business Inquiry', value: 'business' },
                    { label: 'General Question', value: 'general' },
                  ]}
                />

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    Your Message
                  </label>
                  <textarea
                    rows={5}
                    className="w-full rounded-xl border border-slate-300 p-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-2xs"
                    placeholder="Describe your feedback, request, or question in detail..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    required
                  />
                </div>

                <div className="pt-2 flex justify-end">
                  <Button
                    type="submit"
                    variant="primary"
                    size="md"
                    isLoading={isSubmitting}
                    rightIcon={<Send className="h-4 w-4" />}
                  >
                    Submit Feedback
                  </Button>
                </div>
              </form>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};
