import React, { useState, useEffect } from 'react';
import { AmazonKeywordFormData, KeywordItem } from '../../types';
import { generateAmazonKeywords } from '../../services/keywordService';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Card } from '../../components/common/Card';
import { Badge } from '../../components/common/Badge';
import {
  Search,
  Copy,
  Check,
  RotateCcw,
  Bookmark,
  ArrowLeft,
  Filter,
  Sparkles,
  ExternalLink,
  Layers,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
  Target,
  Key,
  DollarSign,
  TrendingUp,
  FileText,
  Clock,
  Info,
  Tag,
} from 'lucide-react';

interface AmazonKeywordGeneratorPageProps {
  onNavigate: (path: string) => void;
}

export const AmazonKeywordGeneratorPage: React.FC<AmazonKeywordGeneratorPageProps> = ({
  onNavigate,
}) => {
  const { saveResult, addToast } = useApp();

  const [formData, setFormData] = useState<AmazonKeywordFormData>({
    productName: 'Stainless Steel French Press Coffee Maker',
    productCategory: 'Kitchen & Dining',
    mainFeatures: 'Double-wall insulation, 34oz capacity, 4-level filtration, rust-proof, dishwasher safe',
    targetMarket: 'Coffee enthusiasts, campers, home baristas',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [keywords, setKeywords] = useState<KeywordItem[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);
  const [filterType, setFilterType] = useState<string>('All');
  const [apiError, setApiError] = useState<string | null>(null);
  const [isGeminiPowered, setIsGeminiPowered] = useState<boolean>(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'What is an Amazon keyword generator?',
      answer:
        'An Amazon keyword generator is an e-commerce research tool designed to help sellers discover customer search queries, buyer-intent phrases, and relevant Amazon search terms for product listings. By analyzing product titles, category contexts, and key features, it provides structured clusters of keywords to help optimize listing metadata and discoverability.',
    },
    {
      question: 'How do I find keywords for an Amazon product?',
      answer:
        'Sellers can find keywords by analyzing high-intent customer search habits, evaluating similar category listings, using the Amazon search auto-suggest bar, reviewing customer search term reports in Amazon Brand Analytics, and utilizing an Amazon keyword research tool like ToolFlow to generate targeted broad and long-tail keyword clusters.',
    },
    {
      question: 'What are Amazon long-tail keywords?',
      answer:
        'Amazon long-tail keywords are highly specific search phrases typically containing three or more words (such as "double wall stainless steel french press 34oz" instead of just "french press"). While long-tail queries generally have lower overall search volume than broad seed terms, they frequently exhibit clearer shopper intent and lower competition.',
    },
    {
      question: 'What are Amazon backend search terms?',
      answer:
        'Amazon backend search terms are hidden keywords entered in the "Generic Keywords" field within Amazon Seller Central. They are not visible to shoppers browsing the product page, but Amazon’s search algorithm indexes them to match listings with relevant customer queries. They have a strict 250-byte limit and should not repeat words already in the title or bullet points.',
    },
    {
      question: 'How should I use keywords in an Amazon listing?',
      answer:
        'Place your most relevant primary keywords in your product title and feature bullet points naturally, ensuring the copy remains readable and customer-focused. Secondary keywords, synonyms, and variations can be woven into the product description and backend search terms. Avoid keyword stuffing, as repetitive listings detract from shopper clarity.',
    },
    {
      question: 'Can an Amazon keyword generator guarantee rankings or sales?',
      answer:
        'No keyword research tool can guarantee organic rankings, impressions, conversions, or sales on Amazon. Amazon’s search algorithm considers multiple dynamic factors—including product pricing, customer review ratings, fulfillment method (FBA vs. FBM), stock availability, click-through rates, and historical sales velocity. Keywords help improve indexation and relevance, but sales depend on overall product appeal, pricing, and execution.',
    },
    {
      question: 'Can beginners use an Amazon keyword research tool?',
      answer:
        'Yes, beginners can easily use ToolFlow’s keyword generator for Amazon sellers to explore customer search vocabulary and learn how buyers describe products. However, beginners should always manually review all generated suggestions to confirm that each keyword accurately describes their specific product before adding it to their listing or ad campaigns.',
    },
  ];

  // Technical SEO & Structured Data
  useEffect(() => {
    const previousTitle = document.title;
    document.title = 'Amazon Keyword Generator – Find Amazon Keywords & Search Terms | ToolFlow';

    // Unique Meta Description (159 characters targeting primary keywords)
    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    const newDesc =
      "Use ToolFlow's free Amazon keyword generator for Amazon keyword research. Discover relevant Amazon search terms and Amazon product keywords for your listings.";

    if (metaDesc) {
      metaDesc.setAttribute('content', newDesc);
    } else {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      metaDesc.setAttribute('content', newDesc);
      document.head.appendChild(metaDesc);
    }

    // Canonical URL pointing to published URL
    const canonicalHref =
      'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/amazon-keyword-generator';
    let canonical = document.querySelector('link[rel="canonical"]');
    const prevCanonical = canonical ? canonical.getAttribute('href') : null;
    if (canonical) {
      canonical.setAttribute('href', canonicalHref);
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      canonical.setAttribute('href', canonicalHref);
      document.head.appendChild(canonical);
    }

    // OpenGraph & Twitter tags
    let ogTitle = document.querySelector('meta[property="og:title"]');
    const prevOgTitle = ogTitle ? ogTitle.getAttribute('content') : '';
    if (ogTitle)
      ogTitle.setAttribute(
        'content',
        'Amazon Keyword Generator – Find Amazon Keywords & Search Terms | ToolFlow'
      );

    let ogDesc = document.querySelector('meta[property="og:description"]');
    const prevOgDesc = ogDesc ? ogDesc.getAttribute('content') : '';
    if (ogDesc) ogDesc.setAttribute('content', newDesc);

    // Robots meta tag to ensure index, follow
    let robotsMeta = document.querySelector('meta[name="robots"]');
    const prevRobots = robotsMeta ? robotsMeta.getAttribute('content') : '';
    if (robotsMeta) {
      robotsMeta.setAttribute('content', 'index, follow');
    } else {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      robotsMeta.setAttribute('content', 'index, follow');
      document.head.appendChild(robotsMeta);
    }

    // Schema.org JSON-LD Structured Data
    const scriptId = 'amazon-keyword-generator-schema';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }

    const structuredData = [
      {
        '@context': 'https://schema.org',
        '@type': 'WebApplication',
        name: 'Amazon Keyword Generator',
        applicationCategory: 'BusinessApplication',
        operatingSystem: 'All',
        url: canonicalHref,
        description: newDesc,
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'USD',
        },
      },
      {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqItems.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      },
    ];

    script.text = JSON.stringify(structuredData);

    return () => {
      document.title = previousTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      if (ogTitle && prevOgTitle) ogTitle.setAttribute('content', prevOgTitle);
      if (ogDesc && prevOgDesc) ogDesc.setAttribute('content', prevOgDesc);
      if (canonical && prevCanonical) {
        canonical.setAttribute('href', prevCanonical);
      } else if (canonical && !prevCanonical) {
        canonical.remove();
      }
      if (robotsMeta && prevRobots) {
        robotsMeta.setAttribute('content', prevRobots);
      } else if (robotsMeta && !prevRobots) {
        robotsMeta.remove();
      }
      const existingScript = document.getElementById(scriptId);
      if (existingScript) existingScript.remove();
    };
  }, []);

  const handleGenerate = async (e?: React.FormEvent | null, forceFallback = false) => {
    if (e) e.preventDefault();
    if (!formData.productName.trim()) {
      addToast({
        title: 'Product Name Required',
        message: 'Please provide a product title to generate keyword clusters.',
        type: 'error',
      });
      return;
    }

    setApiError(null);
    setIsLoading(true);
    try {
      const results = await generateAmazonKeywords(formData, forceFallback);
      setKeywords(results.keywords);
      setIsGeminiPowered(results.isGemini);
      addToast({
        title: results.isGemini ? 'Keywords Generated via Gemini' : 'Keywords Generated (Local)',
        message: results.isGemini
          ? `Extracted ${results.keywords.length} AI keyword clusters using Gemini 3.8 Flash.`
          : `Generated ${results.keywords.length} keyword clusters.`,
        type: 'success',
      });
    } catch (err: any) {
      const msg = err.message || 'Could not generate keywords via Gemini.';
      setApiError(msg);
      addToast({
        title: 'Keyword Notice',
        message: msg,
        type: 'warning',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyIndividual = (keyword: string, idx: number) => {
    navigator.clipboard.writeText(keyword);
    setCopiedIndex(idx);
    addToast({
      title: 'Keyword Copied',
      message: `"${keyword}" copied to clipboard.`,
      type: 'success',
    });
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleCopyAll = () => {
    if (keywords.length === 0) return;
    const text = keywords.map((k) => k.keyword).join('\n');
    navigator.clipboard.writeText(text);
    setCopiedAll(true);
    addToast({
      title: 'All Keywords Copied',
      message: `${keywords.length} keywords copied as newline-separated list.`,
      type: 'success',
    });
    setTimeout(() => setCopiedAll(false), 2000);
  };

  const handleSave = () => {
    if (keywords.length === 0) return;
    const text = keywords.map((k) => `[${k.type}] ${k.keyword} (${k.searchVolume})`).join('\n');
    saveResult({
      toolId: 'amazon-keyword-generator',
      toolName: 'Amazon Keyword Generator',
      category: 'amazon',
      title: `Keywords: ${formData.productName.slice(0, 35)}...`,
      preview: `${keywords.length} keywords generated for ${formData.productCategory} | High-intent search terms`,
      content: `Product: ${formData.productName}\nCategory: ${formData.productCategory}\nTarget: ${formData.targetMarket}\n\nKeywords (${keywords.length} terms):\n${text}`,
      data: {
        ...formData,
        keywords,
      },
    });
  };

  const filteredKeywords = filterType === 'All'
    ? keywords
    : keywords.filter((k) => k.type === filterType);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="mb-6">
        <a
          href="/tools"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors mb-3 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Tools Directory
        </a>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="amber">Amazon Seller Tools</Badge>
              <Badge variant="indigo">SEO & PPC Indexing</Badge>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Amazon Keyword Generator
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Discover high-converting search queries, exact match buyer intent, and backend search terms.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Column */}
        <div className="lg:col-span-5">
          <Card className="p-5 sm:p-6 bg-white shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-5 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Search className="h-4 w-4 text-indigo-600" />
              Listing Specifications
            </h2>

            <form onSubmit={handleGenerate} className="space-y-4">
              <Input
                label="Product Name"
                placeholder="e.g. Stainless Steel French Press Coffee Maker"
                value={formData.productName}
                onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                required
              />

              <Input
                label="Product Category"
                placeholder="e.g. Kitchen & Dining, Sports & Outdoors"
                value={formData.productCategory}
                onChange={(e) => setFormData({ ...formData, productCategory: e.target.value })}
                required
              />

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Main Product Features / USPs
                </label>
                <textarea
                  rows={3}
                  className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 transition-colors placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="e.g. Double wall insulation, 34oz capacity, 4-level filtration..."
                  value={formData.mainFeatures}
                  onChange={(e) => setFormData({ ...formData, mainFeatures: e.target.value })}
                  required
                />
              </div>

              <Input
                label="Target Customer Market"
                placeholder="e.g. Coffee lovers, campers, home baristas"
                value={formData.targetMarket}
                onChange={(e) => setFormData({ ...formData, targetMarket: e.target.value })}
              />

              <div className="pt-2">
                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  className="w-full"
                  isLoading={isLoading}
                  leftIcon={<Sparkles className="h-4 w-4" />}
                >
                  {isLoading ? 'Synthesizing Keywords...' : 'Generate Keywords'}
                </Button>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg text-xs text-slate-500 leading-relaxed">
                <span>Architecture ready for Helium 10 / Jungle Scout / Brand Analytics API integration in production.</span>
              </div>
            </form>
          </Card>
        </div>

        {/* Results Column */}
        <div className="lg:col-span-7">
          <Card className="p-5 sm:p-6 bg-white min-h-[500px] flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 mb-4">
                <div>
                  <h2 className="text-sm font-bold text-slate-900">
                    Keyword Results {keywords.length > 0 && `(${filteredKeywords.length} of ${keywords.length})`}
                  </h2>
                  <span className="text-xs text-slate-400">
                    {keywords.length > 0 ? 'Ready for listing copy & PPC targeting' : 'No keywords generated yet'}
                  </span>
                </div>

                {keywords.length > 0 && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCopyAll}
                      leftIcon={copiedAll ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    >
                      {copiedAll ? 'Copied All' : 'Copy All'}
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handleSave}
                      leftIcon={<Bookmark className="h-3.5 w-3.5" />}
                    >
                      Save List
                    </Button>
                  </div>
                )}
              </div>

              {apiError && (
                <div className="mb-4 p-3.5 rounded-lg bg-amber-50 border border-amber-200/80 text-xs text-amber-900 flex items-start gap-2.5">
                  <Sparkles className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-bold">Gemini API Notice</p>
                    <p className="mt-0.5 leading-relaxed">{apiError}</p>
                    <div className="mt-2 flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => handleGenerate(null, true)}
                        className="text-xs font-semibold text-indigo-700 hover:text-indigo-900 underline cursor-pointer"
                      >
                        Generate with local template engine instead
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Filter Tabs if keywords exist */}
              {keywords.length > 0 && (
                <div className="flex flex-wrap items-center gap-1.5 mb-4 pb-2">
                  {['All', 'Exact / High Intent', 'Long-Tail', 'Broad Match', 'Competitor / Feature'].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setFilterType(tab)}
                      className={`text-xs px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                        filterType === tab
                          ? 'bg-slate-900 text-white font-medium'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              )}

              {/* Keyword List or Empty State */}
              {isLoading ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-indigo-600 mb-4" />
                  <p className="text-sm font-semibold text-slate-800">
                    Extracting keyword clusters...
                  </p>
                  <p className="text-xs text-slate-400 mt-1 max-w-xs">
                    Calculating buyer search intent, match types, and long-tail variants...
                  </p>
                </div>
              ) : keywords.length > 0 ? (
                <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
                  {filteredKeywords.map((item, idx) => {
                    const volumeBadge = {
                      'Very High': 'emerald',
                      High: 'indigo',
                      Medium: 'slate',
                      Trending: 'amber',
                    }[item.searchVolume] as 'emerald' | 'indigo' | 'slate' | 'amber';

                    return (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-3 rounded-lg border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/60 transition-colors group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="text-xs font-mono text-slate-400 w-5 text-right shrink-0">
                            {idx + 1}
                          </span>
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-slate-900 truncate">
                              {item.keyword}
                            </p>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-[11px] text-slate-500">{item.type}</span>
                              <span className="text-slate-300">•</span>
                              <span className="text-[11px] text-slate-400">Relevance: {item.relevance}%</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <Badge variant={volumeBadge} size="sm">
                            {item.searchVolume}
                          </Badge>
                          <button
                            onClick={() => handleCopyIndividual(item.keyword, idx)}
                            className="p-1.5 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
                            title="Copy keyword"
                            aria-label={`Copy ${item.keyword}`}
                          >
                            {copiedIndex === idx ? (
                              <Check className="h-4 w-4 text-emerald-600" />
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-slate-200 rounded-xl bg-slate-50/40 p-8">
                  <div className="h-12 w-12 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mb-3">
                    <Search className="h-6 w-6" />
                  </div>
                  <h3 className="text-base font-semibold text-slate-800">No Keywords Generated</h3>
                  <p className="text-xs text-slate-500 max-w-sm mt-1">
                    Enter your product details on the left and click "Generate Keywords" to produce Amazon-indexed search terms.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-4"
                    onClick={(e) => handleGenerate(e as any)}
                  >
                    Load Sample & Generate
                  </Button>
                </div>
              )}
            </div>

            {keywords.length > 0 && (
              <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-500">
                <div className="flex items-center gap-2">
                  <span>Displaying {filteredKeywords.length} terms</span>
                  <span className="text-slate-300">•</span>
                  <span className={`inline-flex items-center gap-1 font-semibold ${isGeminiPowered ? 'text-indigo-600' : 'text-slate-500'}`}>
                    <Sparkles className="h-3 w-3" />
                    {isGeminiPowered ? 'Gemini 3.8 Flash' : 'Local Synthesis'}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => handleGenerate(e as any)}
                  leftIcon={<RotateCcw className="h-3.5 w-3.5" />}
                >
                  Regenerate
                </Button>
              </div>
            )}
            <div className="mt-2 text-[11px] text-slate-400 italic">
              * Note: Search volume categories are contextual AI estimates. Live verified search volumes require connecting an Amazon Brand Analytics API.
            </div>
          </Card>
        </div>
      </div>

      {/* SEO & Educational Guide Section */}
      <section className="mt-16 pt-12 border-t border-slate-200/80 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-700 text-xs font-semibold mb-3 border border-amber-100">
            <Lightbulb className="h-3.5 w-3.5 text-amber-600" />
            <span>Amazon SEO & Keyword Strategy Guide</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            How to Master Amazon Keyword Research & Discoverability
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Understand how customers search on Amazon, discover relevant search terms, structure your product listing metadata, and leverage an Amazon keyword generator to enhance catalog discoverability.
          </p>
        </div>

        {/* 3 Core Conceptual Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4 font-bold">
              <Search className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              What an Amazon Keyword Generator Does
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              An <strong>Amazon keyword generator</strong> is a specialized research utility that helps sellers discover customer search phrases, buyer vocabulary, and category-relevant <strong>Amazon search terms</strong>. By evaluating product titles, attributes, and use cases, it organizes related queries into structured keyword clusters.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4 font-bold">
              <Key className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              Why Keyword Research Matters
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Amazon functions primarily as a product search engine. If your product listing does not include the exact search phrases shoppers enter into the search bar, your catalog item cannot be indexed or retrieved. Thorough <strong>Amazon keyword research</strong> ensures your product is visible for relevant search intent.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 font-bold">
              <Target className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              Keyword Relevance & Discoverability
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Discoverability on Amazon is driven by topical relevance. Incorporating terms that accurately reflect your item's features, dimensions, and specifications helps connect you with shoppers actively seeking your solution. Irrelevant keywords confuse buyers and degrade listing engagement.
            </p>
          </Card>
        </div>

        {/* Detailed Breakdown: Keyword Types, Listing Strategy & Backend Terms */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80 space-y-6">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
              Listing Optimization Strategy
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              Broad Terms vs. Long-Tail Keywords vs. Specific Phrases
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Building a resilient Amazon catalog requires balancing different search term formats across your titles, bullets, and backend fields:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-50 text-indigo-700 mb-2">
                Broad Product Terms
              </span>
              <h4 className="text-sm font-bold text-slate-900 mb-1">High-Level Category Terms</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Short search queries such as "coffee maker" or "french press." These broad keywords reflect general customer curiosity, carry high search interest, and experience intense competition among established marketplace brands.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-700 mb-2">
                Long-Tail Keywords
              </span>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Targeted Multi-Word Queries</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Phrases containing 3 to 5 words, such as "insulated stainless steel french press." <strong>Amazon long-tail keywords</strong> represent shoppers with specific needs who know exactly what specifications they are seeking.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 mb-2">
                Specific Feature Phrases
              </span>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Use-Case & Material Terms</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Attribute-focused terms like "camping coffee press rust proof" or "dishwasher safe double wall brewer." These phrases capture shoppers filtering for niche functional capabilities or recipient gift ideas.
              </p>
            </div>
          </div>

          {/* Natural Keyword Placement & Backend Search Terms */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600 shrink-0 mt-0.5">
                  <FileText className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    Using Keywords Naturally in Your Listing
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Write for human shoppers first and search indexing second. Integrate primary <strong>Amazon listing keywords</strong> seamlessly into your title and 5 key bullet points. Avoid comma-separated keyword stuffing or repetitive phrase strings, which look spammy and reduce customer reading comprehension.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0 mt-0.5">
                  <Layers className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    Amazon Backend Search Terms & Purpose
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    <strong>Amazon backend keywords</strong> are entered in the 250-byte "Generic Keywords" field in Seller Central. They remain invisible to shoppers on the storefront but are indexed by Amazon. Use this space for synonyms, abbreviations, alternative spellings, and related terms not already present in your visible title or bullet points.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Search Volume, Dynamic Competition & Manual Verification */}
          <div className="p-5 rounded-xl bg-white border border-slate-200/70">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 shrink-0 mt-0.5">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">
                  Why Search Volume Varies & Why You Must Review Generated Terms
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Search volume and competitive intensity are never static—they fluctuate across marketplace regions (US, UK, DE, etc.), seasonal holidays, customer demand cycles, and promotional periods. An <strong>Amazon product keyword generator</strong> synthesizes relevant possibilities based on pattern models, but sellers must always critically review each suggested term. Never include competitor trademarked brand names, unverified certifications, or features that your product does not actually possess.
                </p>
              </div>
            </div>
          </div>

          {/* How to use the ToolFlow generator */}
          <div className="p-5 rounded-xl bg-white border border-slate-200/70">
            <h4 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              How to Use ToolFlow's Amazon Keyword Generator (5 Easy Steps)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">1. Product Title</span>
                <span className="text-slate-500">Enter your primary product name and model details.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">2. Category</span>
                <span className="text-slate-500">Select the applicable Amazon retail department.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">3. Core Features</span>
                <span className="text-slate-500">List materials, dimensions, filtration, or key specs.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">4. Target Audience</span>
                <span className="text-slate-500">Specify buyer personas, gift recipients, or use settings.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">5. Generate & Filter</span>
                <span className="text-slate-500">Filter by broad, long-tail, or feature terms and copy.</span>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Frequently Asked Questions
              </h3>
              <p className="text-xs sm:text-sm text-slate-500">
                Common questions about Amazon keyword research, backend search terms, and listing optimization.
              </p>
            </div>
          </div>

          <div className="mt-6 divide-y divide-slate-100">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={index} className="py-4 first:pt-0 last:pb-0">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between text-left gap-4 group cursor-pointer focus:outline-none"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                      {item.question}
                    </span>
                    <span className="p-1 rounded-md text-slate-400 group-hover:text-amber-600 shrink-0">
                      {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="mt-2.5 pr-8 text-xs sm:text-sm text-slate-600 leading-relaxed font-sans animate-in fade-in duration-200">
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Internal Links Directory */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80">
          <div className="mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Explore More Tools
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              E-Commerce & Freelance Productivity Suite
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Streamline your e-commerce financial analysis, PPC campaigns, client proposals, and marketing content with our free tools:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Amazon Profit Calculator */}
            <a
              href="/tools/amazon-profit-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-profit-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-amber-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
                  <DollarSign className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-amber-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                Amazon Profit Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Calculate net profit margins, Amazon FBA fulfillment fees, product COGS, and return on investment for inventory batches.
              </p>
            </a>

            {/* Amazon PPC Calculator */}
            <a
              href="/tools/amazon-ppc-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-ppc-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-blue-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
                  <TrendingUp className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                Amazon PPC Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Determine target ACoS, break-even ad spend, and optimal cost-per-click bids for your sponsored product ad campaigns.
              </p>
            </a>

            {/* AI Proposal Generator */}
            <a
              href="/tools/proposal-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/proposal-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                  <FileText className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                AI Proposal Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Draft tailored, high-converting client proposals and consulting pitches for Upwork, Fiverr, and agency contracts.
              </p>
            </a>

            {/* Freelancer Rate Calculator */}
            <a
              href="/tools/freelancer-rate-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/freelancer-rate-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-emerald-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                  <Clock className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                Freelancer Rate Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Determine your minimum billable hourly rate accounting for business overhead, self-employment taxes, and take-home goals.
              </p>
            </a>

            {/* Social Caption Generator */}
            <a
              href="/tools/social-caption-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/social-caption-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-pink-400 hover:shadow-xs transition-all group block sm:col-span-2 lg:col-span-1"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-pink-50 text-pink-600">
                  <Sparkles className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-pink-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-pink-600 transition-colors">
                Social Caption Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Create engaging social media copy, viral product hooks, and hashtag recommendations for client campaigns and e-commerce brands.
              </p>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
