import React, { useState, useEffect } from 'react';
import { SocialCaptionFormData, GeneratedCaption } from '../../types';
import { generateSocialCaptions } from '../../services/captionService';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Select } from '../../components/common/Select';
import { Card } from '../../components/common/Card';
import { Badge } from '../../components/common/Badge';
import {
  Sparkles,
  Copy,
  Check,
  RotateCcw,
  Bookmark,
  ArrowLeft,
  Share2,
  Video,
  Hash,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
  Target,
  FileText,
  Clock,
  DollarSign,
  TrendingUp,
  Search,
  MessageSquare,
  Users,
} from 'lucide-react';

interface SocialCaptionGeneratorPageProps {
  onNavigate: (path: string) => void;
}

export const SocialCaptionGeneratorPage: React.FC<SocialCaptionGeneratorPageProps> = ({
  onNavigate,
}) => {
  const { saveResult, addToast } = useApp();

  const [formData, setFormData] = useState<SocialCaptionFormData>({
    topic: 'How to price freelance services without losing clients',
    platform: 'Instagram',
    tone: 'Educational',
    captionCount: 3,
  });

  const [isLoading, setIsLoading] = useState(false);
  const [captions, setCaptions] = useState<GeneratedCaption[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  const [isGeminiPowered, setIsGeminiPowered] = useState<boolean>(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'What is an AI social media caption generator?',
      answer:
        'An AI social media caption generator is a digital copywriting utility that applies machine learning to craft creative post captions, opening hooks, and relevant hashtag suggestions. By analyzing your post topic, platform format, and preferred tone, it produces structured drafts in seconds.',
    },
    {
      question: 'Can I use an AI caption generator for Instagram?',
      answer:
        'Yes, ToolFlow’s caption generator for Instagram produces tailored formats with punchy opening hooks, clean line spacing, and contextual hashtags suited for Instagram Reels, carousels, and feed photos.',
    },
    {
      question: 'How do I write a good social media caption?',
      answer:
        'A strong social media caption starts with an attention-grabbing first line (the hook) that compels users to tap "more." It provides concise value or context in the body, maintains easy-to-read line breaks, and closes with a clear, low-friction call to action (such as saving the post or sharing their thoughts).',
    },
    {
      question: 'Can AI generate captions for businesses and creators?',
      answer:
        'Yes, the tool accommodates both commercial brands and personal creators. By adjusting the tone—such as Professional, Casual, Persuasive, or Humorous—businesses can draft product announcements and educational tips, while creators can generate relatable storytelling and community prompts.',
    },
    {
      question: 'Should I edit an AI-generated caption before posting?',
      answer:
        'Yes, you should always review and refine AI-generated drafts. Personalizing the copy with your unique voice, adding real-life anecdotes, verifying factual claims, and fine-tuning hashtags ensures your content feels authentic and aligns directly with your visual media.',
    },
    {
      question: 'Can a caption generator guarantee viral posts or more views?',
      answer:
        'No software or caption tool can guarantee viral reach, higher view counts, follower growth, or specific engagement rates. Social media algorithm distribution depends on many dynamic factors, including visual quality, watch time, audience relevance, posting schedule, and genuine viewer interaction. Captions improve clarity and viewer retention, but overall performance depends on holistic content quality.',
    },
    {
      question: 'Can beginners use a social media caption generator?',
      answer:
        'Absolutely. A free caption generator is particularly helpful for beginners, small business owners, and solo freelancers who struggle with writer’s block or need fresh social media post ideas. It provides ready-to-use templates that demonstrate how to structure effective hooks and calls to action.',
    },
  ];

  // Technical SEO & Structured Data
  useEffect(() => {
    const previousTitle = document.title;
    document.title =
      'Free AI Social Media Caption Generator | Instagram & Social Captions | ToolFlow';

    // Unique Meta Description (160 characters targeting primary keywords)
    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    const newDesc =
      "Use ToolFlow's free AI caption generator and social media caption generator to craft social media captions and hooks. The ultimate Instagram caption generator.";

    if (metaDesc) {
      metaDesc.setAttribute('content', newDesc);
    } else {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      metaDesc.setAttribute('content', newDesc);
      document.head.appendChild(metaDesc);
    }

    // Canonical URL pointing to published URL
    const canonicalHref =
      'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/social-caption-generator';
    let canonical = document.querySelector('link[rel="canonical"]');
    const prevCanonical = canonical ? canonical.getAttribute('href') : null;
    if (canonical) {
      canonical.setAttribute('href', canonicalHref);
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      canonical.setAttribute('href', canonicalHref);
      document.head.appendChild(canonical);
    }

    // OpenGraph & Twitter tags
    let ogTitle = document.querySelector('meta[property="og:title"]');
    const prevOgTitle = ogTitle ? ogTitle.getAttribute('content') : '';
    if (ogTitle)
      ogTitle.setAttribute(
        'content',
        'Free AI Social Media Caption Generator | Instagram & Social Captions | ToolFlow'
      );

    let ogDesc = document.querySelector('meta[property="og:description"]');
    const prevOgDesc = ogDesc ? ogDesc.getAttribute('content') : '';
    if (ogDesc) ogDesc.setAttribute('content', newDesc);

    // Robots meta tag to ensure index, follow
    let robotsMeta = document.querySelector('meta[name="robots"]');
    const prevRobots = robotsMeta ? robotsMeta.getAttribute('content') : '';
    if (robotsMeta) {
      robotsMeta.setAttribute('content', 'index, follow');
    } else {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      robotsMeta.setAttribute('content', 'index, follow');
      document.head.appendChild(robotsMeta);
    }

    // Schema.org JSON-LD Structured Data
    const scriptId = 'social-caption-generator-schema';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }

    const structuredData = [
      {
        '@context': 'https://schema.org',
        '@type': 'WebApplication',
        name: 'Social Caption Generator',
        applicationCategory: 'BusinessApplication',
        operatingSystem: 'All',
        url: canonicalHref,
        description: newDesc,
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'USD',
        },
      },
      {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqItems.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      },
    ];

    script.text = JSON.stringify(structuredData);

    return () => {
      document.title = previousTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      if (ogTitle && prevOgTitle) ogTitle.setAttribute('content', prevOgTitle);
      if (ogDesc && prevOgDesc) ogDesc.setAttribute('content', prevOgDesc);
      if (canonical && prevCanonical) {
        canonical.setAttribute('href', prevCanonical);
      } else if (canonical && !prevCanonical) {
        canonical.remove();
      }
      if (robotsMeta && prevRobots) {
        robotsMeta.setAttribute('content', prevRobots);
      } else if (robotsMeta && !prevRobots) {
        robotsMeta.remove();
      }
      const existingScript = document.getElementById(scriptId);
      if (existingScript) existingScript.remove();
    };
  }, []);

  const handleGenerate = async (e?: React.FormEvent | null, forceFallback = false) => {
    if (e) e.preventDefault();
    if (!formData.topic.trim()) {
      addToast({
        title: 'Topic Required',
        message: 'Please enter a post topic or hook theme.',
        type: 'error',
      });
      return;
    }

    setApiError(null);
    setIsLoading(true);
    try {
      const results = await generateSocialCaptions(formData, forceFallback);
      setCaptions(results.captions);
      setIsGeminiPowered(results.isGemini);
      addToast({
        title: results.isGemini ? 'Captions Generated via Gemini' : 'Captions Generated (Local)',
        message: results.isGemini
          ? `Created ${results.captions.length} platform-tailored variations with Gemini 3.8 Flash.`
          : `Created ${results.captions.length} variations.`,
        type: 'success',
      });
    } catch (err: any) {
      const msg = err.message || 'Could not generate captions via Gemini.';
      setApiError(msg);
      addToast({
        title: 'Caption Notice',
        message: msg,
        type: 'warning',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyCaption = (caption: GeneratedCaption) => {
    navigator.clipboard.writeText(caption.fullText);
    setCopiedId(caption.id);
    addToast({
      title: 'Caption Copied',
      message: 'Full caption and hashtags copied to clipboard.',
      type: 'success',
    });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSaveCaption = (caption: GeneratedCaption, idx: number) => {
    saveResult({
      toolId: 'social-caption-generator',
      toolName: 'Social Caption Generator',
      category: 'creator',
      title: `${formData.platform} (${formData.tone}): ${formData.topic.slice(0, 30)}...`,
      preview: caption.fullText.slice(0, 130) + '...',
      content: caption.fullText,
      data: {
        ...formData,
        captionIndex: idx,
        charCount: caption.charCount,
      },
    });
  };

  const handleRegenerateSingle = async (idx: number) => {
    try {
      const fresh = await generateSocialCaptions({ ...formData, captionCount: 1 }, !isGeminiPowered);
      if (fresh.captions.length > 0) {
        setCaptions((prev) => {
          const next = [...prev];
          next[idx] = fresh.captions[0];
          return next;
        });
        addToast({
          title: 'Caption Refreshed',
          message: `Variation #${idx + 1} updated with new hook.`,
          type: 'info',
        });
      }
    } catch (e: any) {
      addToast({
        title: 'Refresh Error',
        message: e.message || 'Failed to refresh single variation.',
        type: 'error',
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="mb-6">
        <a
          href="/tools"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors mb-3 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Tools Directory
        </a>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="rose">Creator Tools</Badge>
              <Badge variant="indigo">Multi-Platform AI</Badge>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Social Caption Generator
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Produce viral hooks, engaging body copy, and platform-specific call-to-actions.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form */}
        <div className="lg:col-span-5">
          <Card className="p-5 sm:p-6 bg-white shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-5 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Share2 className="h-4 w-4 text-indigo-600" />
              Content Parameters
            </h2>

            <form onSubmit={handleGenerate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Content Topic or Angle
                </label>
                <textarea
                  rows={3}
                  className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 transition-colors placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="e.g. 3 productivity habits that saved me 15 hours a week..."
                  value={formData.topic}
                  onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Select
                  label="Target Platform"
                  value={formData.platform}
                  onChange={(e) => setFormData({ ...formData, platform: e.target.value as any })}
                  options={[
                    { label: 'Instagram', value: 'Instagram' },
                    { label: 'TikTok', value: 'TikTok' },
                    { label: 'LinkedIn', value: 'LinkedIn' },
                    { label: 'Facebook', value: 'Facebook' },
                    { label: 'YouTube', value: 'YouTube' },
                  ]}
                />

                <Select
                  label="Tone of Voice"
                  value={formData.tone}
                  onChange={(e) => setFormData({ ...formData, tone: e.target.value as any })}
                  options={[
                    { label: 'Educational', value: 'Educational' },
                    { label: 'Professional', value: 'Professional' },
                    { label: 'Inspirational', value: 'Inspirational' },
                    { label: 'Casual', value: 'Casual' },
                    { label: 'Funny & Relatable', value: 'Funny' },
                  ]}
                />
              </div>

              <Select
                label="Number of Variations"
                value={formData.captionCount.toString()}
                onChange={(e) => setFormData({ ...formData, captionCount: parseInt(e.target.value) || 3 })}
                options={[
                  { label: '2 Captions', value: '2' },
                  { label: '3 Captions', value: '3' },
                  { label: '4 Captions', value: '4' },
                  { label: '5 Captions', value: '5' },
                ]}
              />

              <div className="pt-2">
                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  className="w-full"
                  isLoading={isLoading}
                  leftIcon={<Sparkles className="h-4 w-4" />}
                >
                  {isLoading ? 'Generating Captions...' : 'Generate Captions'}
                </Button>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg text-xs text-slate-500 leading-relaxed">
                Includes platform-optimized spacing, call to action, and curated hashtag clusters.
              </div>
            </form>
          </Card>
        </div>

        {/* Results */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between pb-1">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Generated Captions {captions.length > 0 && `(${captions.length})`}
              </h2>
              {captions.length > 0 && (
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded ${isGeminiPowered ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/60' : 'bg-slate-100 text-slate-600'}`}>
                  {isGeminiPowered ? 'Gemini 3.8 Flash' : 'Local Engine'}
                </span>
              )}
            </div>
            {captions.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => handleGenerate(e as any)}
                leftIcon={<RotateCcw className="h-3.5 w-3.5" />}
              >
                Regenerate All
              </Button>
            )}
          </div>

          {apiError && (
            <div className="p-3.5 rounded-lg bg-amber-50 border border-amber-200/80 text-xs text-amber-900 flex items-start gap-2.5">
              <Sparkles className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-bold">Gemini API Notice</p>
                <p className="mt-0.5 leading-relaxed">{apiError}</p>
                <div className="mt-2 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => handleGenerate(null, true)}
                    className="text-xs font-semibold text-indigo-700 hover:text-indigo-900 underline cursor-pointer"
                  >
                    Generate with local fallback templates instead
                  </button>
                </div>
              </div>
            </div>
          )}

          {isLoading ? (
            <Card className="p-12 text-center bg-white">
              <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-indigo-600 mx-auto mb-4" />
              <p className="text-sm font-semibold text-slate-800">
                Crafting hooks for {formData.platform}...
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                Applying {formData.tone.toLowerCase()} tone formatting and engagement triggers...
              </p>
            </Card>
          ) : captions.length > 0 ? (
            <div className="space-y-4">
              {captions.map((caption, idx) => (
                <Card key={caption.id} className="p-5 bg-white border border-slate-200 shadow-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                        Option #{idx + 1}
                      </span>
                      <span className="text-xs text-slate-400">
                        {caption.charCount} characters
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleRegenerateSingle(idx)}
                        leftIcon={<RotateCcw className="h-3 w-3" />}
                      >
                        Regen
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => handleSaveCaption(caption, idx)}
                        leftIcon={<Bookmark className="h-3 w-3" />}
                      >
                        Save
                      </Button>
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => handleCopyCaption(caption)}
                        leftIcon={copiedId === caption.id ? <Check className="h-3 w-3 text-white" /> : <Copy className="h-3 w-3" />}
                      >
                        {copiedId === caption.id ? 'Copied' : 'Copy'}
                      </Button>
                    </div>
                  </div>

                  <div className="text-xs sm:text-sm text-slate-700 whitespace-pre-wrap font-sans leading-relaxed bg-slate-50/70 p-3.5 rounded-lg border border-slate-100">
                    {caption.fullText}
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center bg-white border-dashed">
              <div className="h-12 w-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3">
                <Sparkles className="h-6 w-6" />
              </div>
              <h3 className="text-base font-semibold text-slate-800">No Captions Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                Select your platform and topic on the left to generate audience-tested social media copy.
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-4"
                onClick={(e) => handleGenerate(e as any)}
              >
                Load Sample & Generate
              </Button>
            </Card>
          )}
        </div>
      </div>

      {/* SEO & Educational Guide Section */}
      <section className="mt-16 pt-12 border-t border-slate-200/80 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-50 text-pink-700 text-xs font-semibold mb-3 border border-pink-100">
            <Lightbulb className="h-3.5 w-3.5 text-pink-600" />
            <span>Social Media Copywriting Guide</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            How to Write Compelling Social Media Captions
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Discover how to craft clear, engaging post copy, tailor captions across platforms, structure effective opening hooks, and leverage a free AI caption generator for social media post ideas.
          </p>
        </div>

        {/* 3 Core Conceptual Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center mb-4 font-bold">
              <Sparkles className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              What an AI Caption Generator Does
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              An <strong>AI social media caption generator</strong> is a smart drafting tool that transforms your topic, product highlight, or core message into structured post variations. Rather than staring at a blank screen, it provides creative hooks, body paragraphs, and hashtag suggestions tailored to your chosen tone.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4 font-bold">
              <MessageSquare className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              Communicating Post Purpose & Value
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              While imagery and video capture initial eye contact, <strong>social media captions</strong> communicate context, backstory, and actionable value. A well-structured caption explains why the content matters, answers customer questions, and invites viewers to participate in meaningful conversation.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-4 font-bold">
              <Users className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              Why Tone & Audience Matter
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Different communities respond to distinct communication styles. A B2B audience on LinkedIn values authoritative insights and case studies, whereas Instagram and TikTok audiences favor concise, conversational storytelling and relatable energy. Aligning tone with audience expectations builds trust.
            </p>
          </Card>
        </div>

        {/* Detailed Breakdown: Platforms, Structure & Hashtags */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80 space-y-6">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-wider text-pink-600">
              Platform Adaptation & Strategy
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              Writing Captions for Different Social Media Channels
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Every major social platform has unique reading conventions, character behaviors, and formatting practices:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-pink-50 text-pink-700 mb-2">
                Instagram & Threads
              </span>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Visual Hook & Clean Spacing</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Use an <strong>Instagram caption generator</strong> to produce irresistible opening lines before the "...more" cutoff. Employ clean line breaks, concise bullet points for carousels, and 3 to 5 targeted niche hashtags.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-blue-50 text-blue-700 mb-2">
                LinkedIn & Professional
              </span>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Insightful Takeaways</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Lead with a counterintuitive observation or career lesson. Structure text with generous paragraph breaks for mobile skimming, and close with an open-ended professional discussion prompt.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-purple-50 text-purple-700 mb-2">
                TikTok & YouTube Shorts
              </span>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Short Context & Keywords</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Keep descriptions compact (under 150 characters) so they do not obstruct screen overlays. Incorporate natural search phrases to assist algorithmic recommendation feeds.
              </p>
            </div>
          </div>

          {/* Practical Craft: Conciseness, Matching Content & Hashtag Usage */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-pink-50 text-pink-600 shrink-0 mt-0.5">
                  <Target className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    Matching Captions to Actual Content
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Always ensure your <strong>social media captions</strong> accurately reflect what is shown in the image or video. Avoid exaggerated clickbait hooks that fail to deliver in the post itself, as mismatched expectations lead to quick drop-offs, negative comments, and lost audience trust.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0 mt-0.5">
                  <Hash className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    Intentional Hashtag Usage Without Spam
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Modern discovery algorithms categorize content using visual tags, audio transcripts, and caption text. Adding 3 to 5 hyper-specific, relevant hashtags categorizes your topic cleanly. Pasting 30 generic tags (like #viral or #explore) appears spammy and does not enhance relevance.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Reviewing and Personalizing AI Captions */}
          <div className="p-5 rounded-xl bg-white border border-slate-200/70">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 shrink-0 mt-0.5">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">
                  Why You Should Review and Personalize AI Drafts
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  A <strong>free caption generator</strong> excels at breaking writer’s block, structuring opening hooks, and proposing <strong>social media post ideas</strong>. However, algorithms and human readers both value genuine personality. Review every draft to inject personal anecdotes, adjust terminology to match your brand vocabulary, verify product facts, and refine the call to action before publishing.
                </p>
              </div>
            </div>
          </div>

          {/* How to use the ToolFlow generator */}
          <div className="p-5 rounded-xl bg-white border border-slate-200/70">
            <h4 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              How to Use ToolFlow's Social Caption Generator (4 Easy Steps)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">1. Enter Your Topic</span>
                <span className="text-slate-500">Describe your post theme, key lesson, or product update.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">2. Choose Platform</span>
                <span className="text-slate-500">Select Instagram, LinkedIn, TikTok, Twitter/X, or YouTube.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">3. Select Tone</span>
                <span className="text-slate-500">Pick from Educational, Casual, Professional, or Engaging.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">4. Generate & Personalize</span>
                <span className="text-slate-500">Review multiple options, copy your favorite, and customize.</span>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="p-2 rounded-xl bg-pink-50 text-pink-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Frequently Asked Questions
              </h3>
              <p className="text-xs sm:text-sm text-slate-500">
                Common questions about writing social media captions, using AI generators, and optimizing post engagement.
              </p>
            </div>
          </div>

          <div className="mt-6 divide-y divide-slate-100">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={index} className="py-4 first:pt-0 last:pb-0">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between text-left gap-4 group cursor-pointer focus:outline-none"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-pink-600 transition-colors">
                      {item.question}
                    </span>
                    <span className="p-1 rounded-md text-slate-400 group-hover:text-pink-600 shrink-0">
                      {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="mt-2.5 pr-8 text-xs sm:text-sm text-slate-600 leading-relaxed font-sans animate-in fade-in duration-200">
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Internal Links Directory */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80">
          <div className="mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Explore More Tools
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              E-Commerce & Freelance Productivity Suite
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Explore our full collection of free business utilities to optimize listing discovery, advertising, proposals, and pricing:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Amazon Keyword Generator */}
            <a
              href="/tools/amazon-keyword-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-keyword-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-emerald-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                  <Search className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                Amazon Keyword Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Generate high-search-intent keywords, backend search terms, and PPC target queries to scale marketplace listing traffic.
              </p>
            </a>

            {/* Amazon Profit Calculator */}
            <a
              href="/tools/amazon-profit-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-profit-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-amber-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
                  <DollarSign className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-amber-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                Amazon Profit Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Calculate net profit margins, Amazon FBA fulfillment fees, product COGS, and return on investment for inventory batches.
              </p>
            </a>

            {/* Amazon PPC Calculator */}
            <a
              href="/tools/amazon-ppc-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-ppc-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-blue-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
                  <TrendingUp className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                Amazon PPC Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Determine target ACoS, break-even ad spend, and optimal cost-per-click bids for your sponsored product ad campaigns.
              </p>
            </a>

            {/* Proposal Generator */}
            <a
              href="/tools/proposal-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/proposal-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                  <FileText className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                AI Proposal Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Draft tailored, high-converting client proposals and consulting pitches for Upwork, Fiverr, and agency contracts.
              </p>
            </a>

            {/* Freelancer Rate Calculator */}
            <a
              href="/tools/freelancer-rate-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/freelancer-rate-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-emerald-400 hover:shadow-xs transition-all group block sm:col-span-2 lg:col-span-1"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                  <Clock className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                Freelancer Rate Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Determine your minimum billable hourly rate accounting for business overhead, self-employment taxes, and take-home goals.
              </p>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
