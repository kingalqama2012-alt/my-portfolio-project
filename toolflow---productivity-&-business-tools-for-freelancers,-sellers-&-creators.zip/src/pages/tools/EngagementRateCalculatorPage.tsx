import React, { useState, useMemo } from 'react';
import { EngagementFormData } from '../../types';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Card } from '../../components/common/Card';
import { StatCard } from '../../components/common/StatCard';
import { Badge } from '../../components/common/Badge';
import { usePageSEO } from '../../utils/usePageSEO';
import {
  Share2,
  Bookmark,
  ArrowLeft,
  Check,
  TrendingUp,
  Heart,
  MessageCircle,
  Bookmark as BookmarkIcon,
  Send,
  Users,
  Info,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  HelpCircle,
} from 'lucide-react';

interface EngagementRateCalculatorPageProps {
  onNavigate: (path: string) => void;
}

export const EngagementRateCalculatorPage: React.FC<EngagementRateCalculatorPageProps> = ({
  onNavigate,
}) => {
  usePageSEO({
    title: 'Engagement Rate Calculator – Calculate Social Media Engagement | ToolFlow',
    description:
      'Calculate social media engagement rate across Instagram, TikTok, YouTube, and LinkedIn. Benchmark likes, comments, shares, and saves per follower with ToolFlow.',
    canonicalPath: '/tools/engagement-calculator',
    robots: 'index, follow',
  });

  const { saveResult } = useApp();

  const [formData, setFormData] = useState<EngagementFormData>({
    likes: 1250,
    comments: 184,
    shares: 95,
    saves: 310,
    followers: 42000,
  });

  const [saved, setSaved] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'What is a good social media engagement rate?',
      answer:
        'Across Instagram, TikTok, and YouTube, average public engagement rates typically range between 1.5% and 3.5%. Micro-influencers (10,000 to 50,000 followers) frequently see higher rates (3% to 6%), while accounts with hundreds of thousands of followers typically experience rates between 1% and 2% due to algorithmic saturation.',
    },
    {
      question: 'How is engagement rate calculated?',
      answer:
        'The standard follower-based engagement rate formula is: ((Total Likes + Comments + Shares + Saves) ÷ Total Followers) × 100. This metric calculates the proportion of your follower base that actively interacts with your published posts.',
    },
    {
      question: 'Why do saves and shares have high algorithm value?',
      answer:
        'Major social media recommendation algorithms (such as Instagram Reels and TikTok For You) view saves and shares as high-intent quality signals. A save indicates reference or educational value, while a share brings new prospective viewers into the platform, prompting algorithms to expand organic distribution.',
    },
    {
      question: 'Should I calculate engagement rate by followers or by impressions/reach?',
      answer:
        'Follower-based engagement rate is the universal standard used for public influencer benchmarking and brand sponsorships. However, for internal content auditing, reach-based engagement rate (interactions ÷ unique accounts reached) often provides a clearer picture of individual creative performance.',
    },
    {
      question: 'Does ToolFlow store or access my social media credentials?',
      answer:
        'No. ToolFlow’s engagement rate calculator operates entirely client-side in your browser. No social logins, private API tokens, or personal account handles are stored or transmitted.',
    },
  ];

  const calculations = useMemo(() => {
    const likes = Number(formData.likes) || 0;
    const comments = Number(formData.comments) || 0;
    const shares = Number(formData.shares) || 0;
    const saves = Number(formData.saves) || 0;
    const followers = Number(formData.followers) || 1;

    const totalEngagement = likes + comments + shares + saves;
    const engagementRate = followers > 0 ? (totalEngagement / followers) * 100 : 0;
    const per1k = followers > 0 ? (totalEngagement / followers) * 1000 : 0;

    // Rating benchmark
    let rating: 'Needs Work' | 'Average' | 'Good' | 'Excellent / Viral' = 'Average';
    let ratingColor = 'text-indigo-700 bg-indigo-50 border-indigo-200';

    if (engagementRate < 1.5) {
      rating = 'Needs Work';
      ratingColor = 'text-rose-700 bg-rose-50 border-rose-200';
    } else if (engagementRate <= 3.5) {
      rating = 'Average';
      ratingColor = 'text-slate-700 bg-slate-100 border-slate-200';
    } else if (engagementRate <= 6.0) {
      rating = 'Good';
      ratingColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
    } else {
      rating = 'Excellent / Viral';
      ratingColor = 'text-purple-700 bg-purple-50 border-purple-200';
    }

    return {
      totalEngagement,
      engagementRate: Math.round(engagementRate * 100) / 100,
      engagementPer1kFollowers: Math.round(per1k * 10) / 10,
      rating,
      ratingColor,
    };
  }, [formData]);

  const handleSave = () => {
    saveResult({
      toolId: 'engagement-calculator',
      toolName: 'Engagement Rate Calculator',
      category: 'creator',
      title: `Engagement Rate: ${calculations.engagementRate}% (${calculations.rating})`,
      preview: `Followers: ${formData.followers.toLocaleString()} | Interactions: ${calculations.totalEngagement.toLocaleString()} | Status: ${calculations.rating}`,
      content: `Followers: ${formData.followers.toLocaleString()}\nLikes: ${formData.likes.toLocaleString()}\nComments: ${formData.comments.toLocaleString()}\nShares: ${formData.shares.toLocaleString()}\nSaves: ${formData.saves.toLocaleString()}\n\nTotal Engagement: ${calculations.totalEngagement.toLocaleString()}\nEngagement Rate: ${calculations.engagementRate}%\nEngagement per 1,000 Followers: ${calculations.engagementPer1kFollowers}\nBenchmark Rating: ${calculations.rating}`,
      data: {
        ...formData,
        ...calculations,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="mb-6">
        <a
          href="/tools"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors mb-3 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Tools Directory
        </a>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="rose">Creator Tools</Badge>
              <Badge variant="emerald">Analytics</Badge>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Engagement Rate Calculator
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Calculate your true post engagement percentage across likes, comments, shares, and saves.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSave}
            leftIcon={saved ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
          >
            {saved ? 'Metrics Saved' : 'Save Metric'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs */}
        <div className="lg:col-span-5">
          <Card className="p-5 sm:p-6 bg-white shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-5 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Share2 className="h-4 w-4 text-indigo-600" />
              Content Interaction Counts
            </h2>

            <div className="space-y-4">
              <Input
                label="Total Followers / Audience"
                type="number"
                min="1"
                step="500"
                leftPrefix={<Users className="h-4 w-4 text-slate-400" />}
                value={formData.followers}
                onChange={(e) => setFormData({ ...formData, followers: parseInt(e.target.value) || 1 })}
                helperText="Account follower size at the time of posting."
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Likes"
                  type="number"
                  min="0"
                  step="50"
                  leftPrefix={<Heart className="h-4 w-4 text-rose-400" />}
                  value={formData.likes}
                  onChange={(e) => setFormData({ ...formData, likes: parseInt(e.target.value) || 0 })}
                />

                <Input
                  label="Comments"
                  type="number"
                  min="0"
                  step="10"
                  leftPrefix={<MessageCircle className="h-4 w-4 text-indigo-400" />}
                  value={formData.comments}
                  onChange={(e) => setFormData({ ...formData, comments: parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Shares / Reposts"
                  type="number"
                  min="0"
                  step="10"
                  leftPrefix={<Send className="h-4 w-4 text-amber-400" />}
                  value={formData.shares}
                  onChange={(e) => setFormData({ ...formData, shares: parseInt(e.target.value) || 0 })}
                />

                <Input
                  label="Saves / Bookmarks"
                  type="number"
                  min="0"
                  step="10"
                  leftPrefix={<BookmarkIcon className="h-4 w-4 text-purple-400" />}
                  value={formData.saves}
                  onChange={(e) => setFormData({ ...formData, saves: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>

            <div className="mt-5 p-3 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-500">
              Saves and Shares carry the highest algorithm weight on modern recommendation feeds.
            </div>
          </Card>
        </div>

        {/* Results & Explanation */}
        <div className="lg:col-span-7 space-y-6">
          {/* Main Stat Card */}
          <div className="rounded-xl border border-indigo-200 bg-gradient-to-br from-indigo-50/80 via-white to-indigo-50/30 p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className={`text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${calculations.ratingColor}`}>
                  {calculations.rating} Benchmark
                </span>
                <p className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2 font-mono">
                  {calculations.engagementRate}%
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  Total of {calculations.totalEngagement.toLocaleString()} interactions on {formData.followers.toLocaleString()} followers
                </p>
              </div>

              <div className="text-left sm:text-right">
                <span className="text-xs text-slate-500">Per 1,000 Followers</span>
                <p className="text-2xl font-bold text-slate-900 font-mono">
                  {calculations.engagementPer1kFollowers}
                </p>
                <span className="text-[11px] text-slate-400">actions / 1k</span>
              </div>
            </div>
          </div>

          {/* Breakdown by Interaction Type */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Card className="p-3.5 bg-white text-center">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">Likes</span>
              <p className="text-base font-bold text-slate-900 font-mono mt-0.5">{formData.likes.toLocaleString()}</p>
              <span className="text-[10px] text-slate-400">
                {((formData.likes / (calculations.totalEngagement || 1)) * 100).toFixed(0)}% of total
              </span>
            </Card>

            <Card className="p-3.5 bg-white text-center">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">Comments</span>
              <p className="text-base font-bold text-slate-900 font-mono mt-0.5">{formData.comments.toLocaleString()}</p>
              <span className="text-[10px] text-slate-400">
                {((formData.comments / (calculations.totalEngagement || 1)) * 100).toFixed(0)}% of total
              </span>
            </Card>

            <Card className="p-3.5 bg-white text-center">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">Shares</span>
              <p className="text-base font-bold text-slate-900 font-mono mt-0.5">{formData.shares.toLocaleString()}</p>
              <span className="text-[10px] text-slate-400">
                {((formData.shares / (calculations.totalEngagement || 1)) * 100).toFixed(0)}% of total
              </span>
            </Card>

            <Card className="p-3.5 bg-white text-center">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">Saves</span>
              <p className="text-base font-bold text-slate-900 font-mono mt-0.5">{formData.saves.toLocaleString()}</p>
              <span className="text-[10px] text-slate-400">
                {((formData.saves / (calculations.totalEngagement || 1)) * 100).toFixed(0)}% of total
              </span>
            </Card>
          </div>

          {/* Formula & Explanation */}
          <Card className="p-6 bg-white space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <Info className="h-4 w-4 text-indigo-600" />
              Formula & Industry Reference
            </h3>

            <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg font-mono text-xs text-slate-800">
              Engagement Rate (%) = ((Likes + Comments + Shares + Saves) ÷ Followers) × 100
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Standard brand sponsorship platforms and influencer marketing agencies benchmark public accounts:
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
              <div className="p-2.5 rounded bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block">&lt; 1.5%</span>
                <span className="text-slate-500 text-[11px]">Below Average</span>
              </div>
              <div className="p-2.5 rounded bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block">1.5% - 3.5%</span>
                <span className="text-slate-500 text-[11px]">Healthy Average</span>
              </div>
              <div className="p-2.5 rounded bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block">3.5% - 6.0%</span>
                <span className="text-slate-500 text-[11px]">High Engagement</span>
              </div>
              <div className="p-2.5 rounded bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block">&gt; 6.0%</span>
                <span className="text-slate-500 text-[11px]">Viral / Core Audience</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Frequently Asked Questions Section */}
      <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-6">
        <div className="max-w-3xl">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 flex items-center gap-1.5 mb-1">
            <HelpCircle className="h-4 w-4" />
            Social Media Analytics FAQ
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Frequently Asked Questions About Engagement Rate
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Understand how engagement rates are calculated, benchmarked, and evaluated by sponsorship managers.
          </p>
        </div>

        <div className="divide-y divide-slate-200/80">
          {faqItems.map((item, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div key={idx} className="py-4">
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  className="w-full flex items-center justify-between text-left gap-4 font-semibold text-sm sm:text-base text-slate-900 hover:text-indigo-600 transition-colors cursor-pointer"
                  aria-expanded={isOpen}
                >
                  <span>{item.question}</span>
                  {isOpen ? (
                    <ChevronUp className="h-4 w-4 text-slate-500 shrink-0" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-slate-500 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <p className="mt-2.5 text-xs sm:text-sm text-slate-600 leading-relaxed max-w-3xl">
                    {item.answer}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Related Creator Tools */}
      <div className="mt-12">
        <h3 className="text-base font-bold text-slate-900 mb-4">
          Related Content Growth Tools
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <a
            href="/tools/social-caption-generator"
            onClick={(e) => {
              if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                e.preventDefault();
                onNavigate('/tools/social-caption-generator');
              }
            }}
            className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-xs transition-all group block"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                <TrendingUp className="h-4 w-4" />
              </span>
              <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
              Social Caption Generator
            </h4>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Generate viral hooks, structured body copy, and hashtags for Instagram, TikTok, and YouTube.
            </p>
          </a>

          <a
            href="/tools/creator/trend-radar"
            onClick={(e) => {
              if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                e.preventDefault();
                onNavigate('/tools/creator/trend-radar');
              }
            }}
            className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-xs transition-all group block"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-1.5 rounded-lg bg-rose-50 text-rose-600">
                <TrendingUp className="h-4 w-4" />
              </span>
              <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
              Trend Radar
            </h4>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Scan high-velocity topics and predict emerging demand signals across video platforms.
            </p>
          </a>

          <a
            href="/tools/creator/hook-doctor"
            onClick={(e) => {
              if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                e.preventDefault();
                onNavigate('/tools/creator/hook-doctor');
              }
            }}
            className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-xs transition-all group block"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                <TrendingUp className="h-4 w-4" />
              </span>
              <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
              Hook Doctor
            </h4>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Diagnose opening script retention bottlenecks and generate high-impact hook variations.
            </p>
          </a>
        </div>
      </div>
    </div>
  );
};
