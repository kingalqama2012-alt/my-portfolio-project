import React, { useState, useEffect } from 'react';
import { ProposalFormData } from '../../types';
import { generateProposal } from '../../services/aiProposalService';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Select } from '../../components/common/Select';
import { Card } from '../../components/common/Card';
import { Badge } from '../../components/common/Badge';
import {
  FileText,
  Copy,
  Check,
  RotateCcw,
  Bookmark,
  Sparkles,
  ArrowLeft,
  Edit3,
  Sliders,
  Info,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  HelpCircle,
  Lightbulb,
  Target,
  Zap,
  TrendingUp,
  ShieldCheck,
  Users,
} from 'lucide-react';
import { AdBanner, SmartlinkPromo } from '../../components/ads';

interface ProposalGeneratorPageProps {
  onNavigate: (path: string) => void;
}

export const ProposalGeneratorPage: React.FC<ProposalGeneratorPageProps> = ({ onNavigate }) => {
  const { saveResult, addToast } = useApp();

  const [formData, setFormData] = useState<ProposalFormData>({
    jobTitle: 'Senior UI/UX Designer for Fintech Mobile App',
    clientRequirements: 'Looking for an experienced product designer to redesign our mobile banking app. Needs expertise in design systems, iOS/Android HIG, and user testing.',
    yourSkills: 'Figma, Design Systems, Mobile UI/UX, Rapid Prototyping, Usability Testing',
    experience: '6+ years designing SaaS & fintech applications with 25+ successful client deliveries',
    projectBudget: '$3,500 - $5,000 USD',
    tone: 'Professional',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [generatedProposal, setGeneratedProposal] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [isGeminiPowered, setIsGeminiPowered] = useState<boolean>(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'What is an AI proposal generator?',
      answer:
        'An AI proposal generator is an intelligent copywriting tool designed to help freelancers, contractors, and agencies craft customized, professional project bids. By analyzing client job briefs, project scopes, and your specific qualifications, it generates persuasive proposals with structured milestones, relevant portfolio references, and tailored value propositions in seconds.',
    },
    {
      question: "Is ToolFlow's proposal generator free to use?",
      answer:
        'Yes, ToolFlow offers a free proposal generator for freelancers. You can generate, edit, customize, copy, and save unlimited client proposals for Upwork, Fiverr, Freelancer.com, and direct client contracts without any hidden subscriptions or mandatory credit card requirements.',
    },
    {
      question: 'How do I write a good freelance proposal for Upwork or Fiverr?',
      answer:
        "To write a winning freelance proposal, hook the client in the first two sentences by addressing their primary project goal or roadblock. Avoid generic introductions like 'Dear Hiring Manager.' Instead, outline your concrete approach, cite 1–2 relevant examples of past work, ask a thoughtful clarifying question, and provide a clear, low-pressure call to action.",
    },
    {
      question: 'Can I customize the tone and deliverables in the generated proposal?',
      answer:
        "Absolutely. ToolFlow lets you select from multiple professional tones—including Professional, Confident, Persuasive, Friendly, and Technical. You can also use the integrated 'Edit Draft' mode to adjust milestones, revise pricing terms, or insert personal portfolio links before sending.",
    },
    {
      question: 'Will clients know I used an AI proposal generator?',
      answer:
        'No. ToolFlow generates natural, context-rich copy that integrates your specific experience, skills, and the client’s unique requirements. Because the output focuses on practical solutions and strategic milestones rather than generic platitudes, it reads like a meticulously researched, human-written proposal.',
    },
    {
      question: 'How does personalized pitching increase response rates on freelance platforms?',
      answer:
        'Clients on platforms like Upwork and Fiverr often receive numerous applications per listing and quickly scan incoming previews. Personalized proposals that address their exact tech stack, industry, and objectives immediately stand out from generic copy-paste bids by clearly demonstrating relevance, a genuine understanding of the client’s needs, and a better overall project fit.',
    },
    {
      question: 'What information should I include in my proposal inputs for the best results?',
      answer:
        'For optimal output, paste the client’s full job description, list 3–5 of your most relevant technical or creative tools, mention your years of experience or quantified results from past projects, and indicate your expected budget or timeline. The more context you provide, the more tailored your final pitch will be.',
    },
  ];

  // Dynamic SEO title, meta description, and Schema.org structured data
  useEffect(() => {
    const previousTitle = document.title;
    document.title = 'Free AI Proposal Generator for Freelancers | ToolFlow';

    // Update meta description (targeting ~155-160 characters)
    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    const newDesc =
      'Win more clients with ToolFlow’s free AI proposal generator for Upwork and Fiverr freelancers. Generate tailored, high-converting professional proposals in seconds.';

    if (metaDesc) {
      metaDesc.setAttribute('content', newDesc);
    } else {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      metaDesc.setAttribute('content', newDesc);
      document.head.appendChild(metaDesc);
    }

    // Update OpenGraph metadata
    let ogTitle = document.querySelector('meta[property="og:title"]');
    const prevOgTitle = ogTitle ? ogTitle.getAttribute('content') : '';
    if (ogTitle) ogTitle.setAttribute('content', 'Free AI Proposal Generator for Freelancers | ToolFlow');

    let ogDesc = document.querySelector('meta[property="og:description"]');
    const prevOgDesc = ogDesc ? ogDesc.getAttribute('content') : '';
    if (ogDesc) ogDesc.setAttribute('content', newDesc);

    // Canonical link
    const canonicalHref =
      'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/proposal-generator';
    let canonical = document.querySelector('link[rel="canonical"]');
    const prevCanonical = canonical ? canonical.getAttribute('href') : null;
    if (canonical) {
      canonical.setAttribute('href', canonicalHref);
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      canonical.setAttribute('href', canonicalHref);
      document.head.appendChild(canonical);
    }

    // Robots meta
    let robotsMeta = document.querySelector('meta[name="robots"]');
    const prevRobots = robotsMeta ? robotsMeta.getAttribute('content') : '';
    if (robotsMeta) {
      robotsMeta.setAttribute('content', 'index, follow');
    } else {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      robotsMeta.setAttribute('content', 'index, follow');
      document.head.appendChild(robotsMeta);
    }

    // Schema.org JSON-LD structured data for WebApplication & FAQPage
    const scriptId = 'proposal-generator-seo-schema';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }

    const structuredData = [
      {
        '@context': 'https://schema.org',
        '@type': 'WebApplication',
        name: 'Free AI Proposal Generator for Freelancers',
        applicationCategory: 'BusinessApplication',
        operatingSystem: 'All',
        url: typeof window !== 'undefined' ? window.location.href : '',
        description: newDesc,
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'USD',
        },
      },
      {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqItems.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      },
    ];

    script.text = JSON.stringify(structuredData);

    return () => {
      document.title = previousTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      if (ogTitle && prevOgTitle) ogTitle.setAttribute('content', prevOgTitle);
      if (ogDesc && prevOgDesc) ogDesc.setAttribute('content', prevOgDesc);
      if (canonical && prevCanonical) {
        canonical.setAttribute('href', prevCanonical);
      }
      if (robotsMeta && prevRobots) {
        robotsMeta.setAttribute('content', prevRobots);
      }
      const existingScript = document.getElementById(scriptId);
      if (existingScript) existingScript.remove();
    };
  }, []);

  const handleGenerate = async (e?: React.FormEvent | null, forceFallback = false) => {
    if (e) e.preventDefault();
    if (!formData.jobTitle.trim() || !formData.clientRequirements.trim()) {
      addToast({
        title: 'Missing Details',
        message: 'Please provide both the Job Title and Client Requirements.',
        type: 'error',
      });
      return;
    }

    setApiError(null);
    setIsLoading(true);
    try {
      const result = await generateProposal(formData, forceFallback);
      setGeneratedProposal(result.proposal);
      setIsGeminiPowered(result.isGemini);
      setIsEditing(false);
      addToast({
        title: result.isGemini ? 'Proposal Generated via Gemini' : 'Proposal Generated (Template)',
        message: result.isGemini
          ? 'Tailored proposal generated with Gemini 3.8 Flash.'
          : 'Proposal generated with standard template.',
        type: 'success',
      });
    } catch (err: any) {
      const msg = err.message || 'Could not connect to Gemini API.';
      setApiError(msg);
      addToast({
        title: 'Generation Notice',
        message: msg,
        type: 'warning',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!generatedProposal) return;
    navigator.clipboard.writeText(generatedProposal);
    setCopied(true);
    addToast({
      title: 'Copied to Clipboard',
      message: 'Proposal content copied to clipboard.',
      type: 'success',
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    if (!generatedProposal) return;
    saveResult({
      toolId: 'proposal-generator',
      toolName: 'AI Proposal Generator',
      category: 'freelancer',
      title: `Proposal: ${formData.jobTitle.slice(0, 40)}...`,
      preview: generatedProposal.slice(0, 140) + '...',
      content: generatedProposal,
      data: formData,
    });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Top Breadcrumb & Header */}
      <div className="mb-6">
        <a
          href="/tools"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors mb-3 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Tools Directory
        </a>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="indigo">Freelancer Tools</Badge>
              <Badge variant="purple">AI Generator</Badge>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              AI Proposal Generator
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Create professional, customized freelance proposals in seconds to win high-value clients.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Form Column */}
        <div className="lg:col-span-5">
          <Card className="p-5 sm:p-6 bg-white shadow-xs">
            <div className="flex items-center gap-2 mb-5 pb-3 border-b border-slate-100">
              <Sliders className="h-4 w-4 text-indigo-600" />
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Project Parameters
              </h2>
            </div>

            <form onSubmit={handleGenerate} className="space-y-4">
              <Input
                label="Job Title"
                placeholder="e.g. Senior Frontend React Developer"
                value={formData.jobTitle}
                onChange={(e) => setFormData({ ...formData, jobTitle: e.target.value })}
                required
              />

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Client Requirements / Job Description
                </label>
                <textarea
                  rows={4}
                  className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 transition-colors placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Paste client brief or job description here..."
                  value={formData.clientRequirements}
                  onChange={(e) => setFormData({ ...formData, clientRequirements: e.target.value })}
                  required
                />
              </div>

              <Input
                label="Your Core Skills"
                placeholder="e.g. React, Next.js, TypeScript, Tailwind"
                value={formData.yourSkills}
                onChange={(e) => setFormData({ ...formData, yourSkills: e.target.value })}
                required
              />

              <Input
                label="Your Experience / Proof"
                placeholder="e.g. 5+ years building SaaS apps, 40+ 5-star reviews"
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                required
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Project Budget / Rate"
                  placeholder="e.g. $2,500 or $75/hr"
                  value={formData.projectBudget}
                  onChange={(e) => setFormData({ ...formData, projectBudget: e.target.value })}
                />

                <Select
                  label="Tone of Voice"
                  value={formData.tone}
                  onChange={(e) => setFormData({ ...formData, tone: e.target.value as any })}
                  options={[
                    { label: 'Professional', value: 'Professional' },
                    { label: 'Friendly & Warm', value: 'Friendly' },
                    { label: 'Persuasive & Direct', value: 'Persuasive' },
                    { label: 'Short & Punchy', value: 'Short' },
                  ]}
                />
              </div>

              <div className="pt-2">
                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  className="w-full"
                  isLoading={isLoading}
                  leftIcon={<Sparkles className="h-4 w-4" />}
                >
                  {isLoading ? 'Generating Proposal...' : 'Generate Proposal'}
                </Button>
              </div>

              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-500">
                <Info className="h-4 w-4 text-indigo-500 shrink-0" />
                <span>Outputs can be tailored, edited in-place, and saved directly to your workspace.</span>
              </div>
            </form>
          </Card>
        </div>

        {/* Right Output Column */}
        <div className="lg:col-span-7">
          <Card className="p-5 sm:p-6 bg-white min-h-[500px] flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 mb-4">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700">
                    <FileText className="h-4 w-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Generated Proposal</h2>
                    <span className="text-xs text-slate-400">
                      {generatedProposal ? 'Ready to customize or copy' : 'Awaiting input'}
                    </span>
                  </div>
                </div>

                {generatedProposal && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsEditing(!isEditing)}
                      leftIcon={<Edit3 className="h-3.5 w-3.5" />}
                    >
                      {isEditing ? 'Preview' : 'Edit'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCopy}
                      leftIcon={copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    >
                      {copied ? 'Copied' : 'Copy'}
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handleSave}
                      leftIcon={<Bookmark className="h-3.5 w-3.5" />}
                    >
                      Save
                    </Button>
                  </div>
                )}
              </div>

              {apiError && (
                <div className="mb-4 p-3.5 rounded-lg bg-amber-50 border border-amber-200/80 text-xs text-amber-900 flex items-start gap-2.5">
                  <Info className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-bold">Gemini API Notice</p>
                    <p className="mt-0.5 leading-relaxed">{apiError}</p>
                    <div className="mt-2 flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => handleGenerate(null, true)}
                        className="text-xs font-semibold text-indigo-700 hover:text-indigo-900 underline cursor-pointer"
                      >
                        Generate with offline template engine instead
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {isLoading ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-indigo-600 mb-4" />
                  <p className="text-sm font-semibold text-slate-800">
                    Analyzing client requirements...
                  </p>
                  <p className="text-xs text-slate-400 mt-1 max-w-xs">
                    Drafting structured milestones, pitch arguments, and personalized scope...
                  </p>
                </div>
              ) : generatedProposal ? (
                <div>
                  {isEditing ? (
                    <textarea
                      rows={18}
                      className="w-full p-4 rounded-lg border border-slate-300 font-mono text-xs leading-relaxed text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
                      value={generatedProposal}
                      onChange={(e) => setGeneratedProposal(e.target.value)}
                    />
                  ) : (
                    <div className="prose prose-slate max-w-none text-xs sm:text-sm text-slate-700 leading-relaxed space-y-4 whitespace-pre-wrap bg-slate-50/60 p-4 sm:p-5 rounded-lg border border-slate-100 font-sans">
                      {generatedProposal}
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-slate-200 rounded-xl bg-slate-50/40 p-8">
                  <div className="h-12 w-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3">
                    <Sparkles className="h-6 w-6" />
                  </div>
                  <h3 className="text-base font-semibold text-slate-800">No Proposal Generated Yet</h3>
                  <p className="text-xs text-slate-500 max-w-sm mt-1">
                    Fill in the project details on the left and click "Generate Proposal" to produce an optimized client bid.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-4"
                    onClick={(e) => handleGenerate(e as any)}
                  >
                    Load Sample & Generate
                  </Button>
                </div>
              )}
            </div>

            {generatedProposal && (
              <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
                <div className="flex items-center gap-2">
                  <span>Tone: <strong className="text-slate-700">{formData.tone}</strong></span>
                  <span className="text-slate-300">•</span>
                  <span className={`inline-flex items-center gap-1 font-semibold ${isGeminiPowered ? 'text-indigo-600' : 'text-slate-500'}`}>
                    <Sparkles className="h-3 w-3" />
                    {isGeminiPowered ? 'Gemini 3.8 Flash' : 'Template Engine'}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => handleGenerate(e as any)}
                  leftIcon={<RotateCcw className="h-3.5 w-3.5" />}
                >
                  Regenerate Variant
                </Button>
              </div>
            )}
          </Card>

          {/* Adsterra Medium Rectangle 300x250 (ID: 31491251) and Smartlink Promo */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            <AdBanner size="300x250" />
            <SmartlinkPromo
              variant="card"
              title="Exclusive Freelancer Contracts & Growth Deals"
              description="Get verified templates, high-paying client acquisition funnels, and partner perks."
            />
          </div>
        </div>

        {/* Adsterra Wide Skyscraper 160x600 (ID: 31491254) on extra-wide screens */}
        <div className="hidden 2xl:block shrink-0">
          <div className="sticky top-20">
            <AdBanner size="160x600" />
          </div>
        </div>
      </div>

      {/* SEO & Knowledge Hub Section */}
      <section className="mt-16 pt-12 border-t border-slate-200/80 space-y-12">
        {/* Guide Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold mb-3 border border-indigo-100">
            <Lightbulb className="h-3.5 w-3.5 text-indigo-600" />
            <span>Freelancer Pitching Guide</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            How to Win More Client Contracts with an AI Proposal Generator
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Learn how modern Upwork, Fiverr, and independent contractors use ToolFlow's free AI proposal generator to craft personalized, high-converting professional proposals that stand out from generic bids.
          </p>
        </div>

        {/* 3 Core Explanation Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4 font-bold">
              <FileText className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              What is an AI Proposal Generator?
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              An <strong>AI proposal generator</strong> is an intelligent copywriting utility designed specifically for freelancers, consultants, and creative agencies. Instead of starting from a blank page or recycling outdated templates, the tool analyzes the client's job requirements, matches your technical competencies, and produces a structured, persuasive pitch in seconds.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4 font-bold">
              <Target className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              How Freelancers Can Use It
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Whether you are pitching on <strong>Upwork</strong>, sending custom offers on <strong>Fiverr</strong>, or reaching out directly to B2B clients via email, you can use this <strong>freelance proposal generator</strong> to outline deliverables, establish phased project milestones, demonstrate past impact, and frame your pricing with professional authority.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4 font-bold">
              <Zap className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              How ToolFlow's Generator Works
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              ToolFlow uses advanced contextual language processing to deconstruct the client's core pain points. It aligns your listed skills with the exact deliverables required, chooses an impactful opening hook, and suggests transparent project phases so clients can visualize immediate collaboration.
            </p>
          </Card>
        </div>

        {/* Practical Tips Section */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80">
          <div className="max-w-3xl mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Pro Pitching Strategy
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              5 Tips for Writing Better Freelance Proposals
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Top-earning freelancers follow proven structural rules when submitting bids on competitive platforms:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0 mt-0.5">
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    1. Hook the client in the first two sentences
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Skip introductions like "Hi, my name is Alex and I am a developer." Instead, immediately address the client's core bottleneck: <em>"I reviewed your mobile app redesign brief and noticed user retention can be significantly improved by streamlining the 3-step checkout flow."</em>
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0 mt-0.5">
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    2. Focus on business outcomes over tool names
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Clients do not just hire tools; they invest in results. Rather than simply listing technologies, explain how your experience translates into faster turnaround, cleaner code, higher conversion rates, or lower operating costs.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0 mt-0.5">
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    3. Structure clear milestones & estimated timelines
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Vagueness creates risk for the hiring manager. Providing a 3-stage breakdown (e.g. Discovery & Wireframing &rarr; Implementation &rarr; QA & Delivery) gives clients instant confidence that you know how to execute.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0 mt-0.5">
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    4. Ask one insightful technical or strategic question
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Asking a specific question about their API architecture, target user demographic, or existing brand guide proves you read their post and invites a conversational reply.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Personalized vs Generic Copy-Paste Comparison */}
        <div>
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Why Personalized Proposals Win Over Generic Templates
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5">
              Hiring managers on platforms like Upwork and Fiverr sift through dozens of bids in minutes. Here is how tailored AI proposals compare to generic copy-paste templates:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Generic Proposals Card */}
            <Card className="p-6 bg-white border border-rose-200/80 shadow-xs">
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-rose-100">
                <div className="p-1.5 rounded-lg bg-rose-50 text-rose-600">
                  <Info className="h-4 w-4" />
                </div>
                <h4 className="text-base font-bold text-rose-950">Generic Copy-Paste Proposals</h4>
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-rose-500 font-bold">✕</span>
                  <span><strong>Low client engagement:</strong> Ignored by clients because boilerplate copy feels impersonal and fails to demonstrate an understanding of their unique project challenges.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-500 font-bold">✕</span>
                  <span><strong>Triggers platform spam filters:</strong> Submitting identical boilerplate on multiple postings can flag your profile for spammy activity.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-500 font-bold">✕</span>
                  <span><strong>Forces price competition:</strong> When you present yourself as a commodity, clients only negotiate down on hourly or fixed rates.</span>
                </li>
              </ul>
            </Card>

            {/* Personalized Proposals Card */}
            <Card className="p-6 bg-white border border-emerald-200/80 shadow-xs">
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-emerald-100">
                <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <h4 className="text-base font-bold text-emerald-950">Tailored AI Freelance Proposals</h4>
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span><strong>Demonstrates relevance & project fit:</strong> Captures client attention immediately by directly addressing their stated goals, technical constraints, and workflow.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span><strong>Builds immediate trust:</strong> Demonstrates that you invested the effort to understand their technical specifications and deadline.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span><strong>Commands premium rates:</strong> Strategic, outcome-oriented language positions you as a high-value specialist rather than an order-taker.</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Frequently Asked Questions
              </h3>
              <p className="text-xs sm:text-sm text-slate-500">
                Everything you need to know about using ToolFlow's proposal generator for freelancers.
              </p>
            </div>
          </div>

          <div className="mt-6 divide-y divide-slate-100">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={index} className="py-4 first:pt-0 last:pb-0">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between text-left gap-4 group cursor-pointer focus:outline-none"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                      {item.question}
                    </span>
                    <span className="p-1 rounded-md text-slate-400 group-hover:text-indigo-600 shrink-0">
                      {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="mt-2.5 pr-8 text-xs sm:text-sm text-slate-600 leading-relaxed font-sans animate-in fade-in duration-200">
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};
