import React, { useState, useMemo, useEffect } from 'react';
import { AmazonProfitFormData } from '../../types';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Card } from '../../components/common/Card';
import { StatCard } from '../../components/common/StatCard';
import { Badge } from '../../components/common/Badge';
import {
  TrendingUp,
  DollarSign,
  Bookmark,
  ArrowLeft,
  Check,
  AlertCircle,
  HelpCircle,
  PieChart,
  Calculator,
  Package,
  Truck,
  Layers,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
  Percent,
  FileText,
  Clock,
  Sparkles,
  Target,
} from 'lucide-react';
import { AdBanner, SmartlinkPromo } from '../../components/ads';

interface AmazonProfitCalculatorPageProps {
  onNavigate: (path: string) => void;
}

export const AmazonProfitCalculatorPage: React.FC<AmazonProfitCalculatorPageProps> = ({
  onNavigate,
}) => {
  const { currency, saveResult } = useApp();

  const [formData, setFormData] = useState<AmazonProfitFormData>({
    sellingPrice: 34.99,
    productCost: 7.50,
    shippingCost: 1.80,
    referralFeePercent: 15,
    fbaFee: 5.60,
    adCostPerUnit: 4.20,
    otherCosts: 0.50,
    unitsSold: 300,
  });

  const [saved, setSaved] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'How do I calculate Amazon FBA profit?',
      answer:
        'To calculate Amazon FBA profit per unit, subtract all direct and marketplace costs from your retail selling price: Net Profit = Selling Price - (Product Manufacturing Cost + Sourcing Freight + Amazon Referral Fee + Amazon FBA Fulfillment Fee + PPC Advertising Spend + Other Costs). ToolFlow’s Amazon FBA profit calculator computes this multi-variable equation in real time for single units and full batches.',
    },
    {
      question: 'What costs should I include when calculating Amazon profit?',
      answer:
        'Accurate profit calculation requires accounting for your unit manufacturing cost (COGS), freight shipping and customs, Amazon referral fees (typically 8% to 15%), FBA pick-and-pack fulfillment fees, monthly storage, PPC ad spend per unit, packaging materials, and customer return allowances.',
    },
    {
      question: 'What is the difference between revenue and profit?',
      answer:
        'Revenue is the total top-line gross dollar amount collected from customer purchases on Amazon (Selling Price × Units Sold). Profit is the actual bottom-line cash remaining after subtracting product manufacturing, international shipping, Amazon marketplace fees, advertising, and operating expenses. High sales revenue does not guarantee financial success if margins are thin.',
    },
    {
      question: 'How do Amazon FBA fees affect profit?',
      answer:
        'Amazon charges two primary seller fees: a referral fee (a category-based percentage of the retail price) and an FBA fulfillment fee based on package weight, dimensions, and tier. Together, these fees frequently represent 25% to 40% of an item’s selling price, making rigorous fee analysis vital to preserving profit margins.',
    },
    {
      question: 'How do I calculate Amazon profit margin?',
      answer:
        'To calculate your Amazon net profit margin percentage, divide your net profit per unit by the retail selling price and multiply by 100: (Net Profit / Selling Price) × 100. For example, earning $8.75 net profit on a $35 item equals a 25% net profit margin. Healthy private-label Amazon products typically aim for a 20% to 30% net margin.',
    },
    {
      question: 'Should advertising costs be included in Amazon profit?',
      answer:
        'Yes, advertising costs (Amazon PPC Sponsored Products, Brands, and Display) must be factored in. Advertising directly impacts your true net margin. Dividing your total monthly ad spend by the units sold gives your ad cost per unit, which reveals whether your paid campaigns are generating profitable or loss-making sales.',
    },
    {
      question: 'Can beginners use an Amazon profit calculator?',
      answer:
        'Yes, beginner e-commerce sellers should always evaluate product ideas with an Amazon seller profit calculator before placing supplier orders or investing capital. It helps beginners avoid launching oversized or low-priced items where fulfillment fees and referral costs erode all potential profit.',
    },
  ];

  // Technical SEO & Structured Data
  useEffect(() => {
    const previousTitle = document.title;
    document.title = 'Amazon Profit Calculator – Calculate Amazon FBA Profit & Margin | ToolFlow';

    // Unique Meta Description (160 characters targeting primary keywords)
    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    const newDesc =
      "Use our free Amazon profit calculator and Amazon FBA profit calculator to calculate Amazon FBA profit, seller fees, and your exact Amazon profit margin easily.";

    if (metaDesc) {
      metaDesc.setAttribute('content', newDesc);
    } else {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      metaDesc.setAttribute('content', newDesc);
      document.head.appendChild(metaDesc);
    }

    // Canonical URL pointing to published URL
    const canonicalHref =
      'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/amazon-profit-calculator';
    let canonical = document.querySelector('link[rel="canonical"]');
    const prevCanonical = canonical ? canonical.getAttribute('href') : null;
    if (canonical) {
      canonical.setAttribute('href', canonicalHref);
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      canonical.setAttribute('href', canonicalHref);
      document.head.appendChild(canonical);
    }

    // OpenGraph & Twitter tags
    let ogTitle = document.querySelector('meta[property="og:title"]');
    const prevOgTitle = ogTitle ? ogTitle.getAttribute('content') : '';
    if (ogTitle)
      ogTitle.setAttribute('content', 'Amazon Profit Calculator – Calculate Amazon FBA Profit & Margin | ToolFlow');

    let ogDesc = document.querySelector('meta[property="og:description"]');
    const prevOgDesc = ogDesc ? ogDesc.getAttribute('content') : '';
    if (ogDesc) ogDesc.setAttribute('content', newDesc);

    // Robots meta tag to ensure normal indexing
    let robotsMeta = document.querySelector('meta[name="robots"]');
    const prevRobots = robotsMeta ? robotsMeta.getAttribute('content') : '';
    if (robotsMeta) {
      robotsMeta.setAttribute('content', 'index, follow');
    } else {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      robotsMeta.setAttribute('content', 'index, follow');
      document.head.appendChild(robotsMeta);
    }

    // Schema.org JSON-LD Structured Data
    const scriptId = 'amazon-profit-calculator-schema';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }

    const structuredData = [
      {
        '@context': 'https://schema.org',
        '@type': 'WebApplication',
        name: 'Amazon Profit Calculator',
        applicationCategory: 'BusinessApplication',
        operatingSystem: 'All',
        url: canonicalHref,
        description: newDesc,
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'USD',
        },
      },
      {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqItems.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      },
    ];

    script.text = JSON.stringify(structuredData);

    return () => {
      document.title = previousTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      if (ogTitle && prevOgTitle) ogTitle.setAttribute('content', prevOgTitle);
      if (ogDesc && prevOgDesc) ogDesc.setAttribute('content', prevOgDesc);
      if (canonical && prevCanonical) {
        canonical.setAttribute('href', prevCanonical);
      } else if (canonical && !prevCanonical) {
        canonical.remove();
      }
      if (robotsMeta && prevRobots) {
        robotsMeta.setAttribute('content', prevRobots);
      } else if (robotsMeta && !prevRobots) {
        robotsMeta.remove();
      }
      const existingScript = document.getElementById(scriptId);
      if (existingScript) existingScript.remove();
    };
  }, []);

  const calculations = useMemo(() => {
    const price = Number(formData.sellingPrice) || 0;
    const cogs = Number(formData.productCost) || 0;
    const shipping = Number(formData.shippingCost) || 0;
    const refPercent = (Number(formData.referralFeePercent) || 0) / 100;
    const fba = Number(formData.fbaFee) || 0;
    const adCost = Number(formData.adCostPerUnit) || 0;
    const other = Number(formData.otherCosts) || 0;
    const units = Number(formData.unitsSold) || 1;

    // Per unit
    const referralFeePerUnit = price * refPercent;
    const amazonFeesPerUnit = referralFeePerUnit + fba;
    const productCostPerUnit = cogs + shipping;
    const totalCostPerUnit = productCostPerUnit + amazonFeesPerUnit + adCost + other;
    const profitPerUnit = price - totalCostPerUnit;

    // Totals for batch
    const revenue = price * units;
    const referralFeeTotal = referralFeePerUnit * units;
    const fbaFeeTotal = fba * units;
    const amazonFeesTotal = amazonFeesPerUnit * units;
    const productCostsTotal = productCostPerUnit * units;
    const shippingCostsTotal = shipping * units;
    const advertisingCostsTotal = adCost * units;
    const otherCostsTotal = other * units;
    const totalCosts = totalCostPerUnit * units;
    const netProfit = profitPerUnit * units;

    // Margins
    const profitMarginPercent = price > 0 ? (profitPerUnit / price) * 100 : 0;
    const directInvestment = (cogs + shipping + adCost + other) * units;
    const roiPercent = directInvestment > 0 ? (netProfit / directInvestment) * 100 : 0;

    return {
      revenue,
      referralFeePerUnit,
      referralFeeTotal,
      fbaFeeTotal,
      amazonFeesTotal,
      productCostsTotal,
      shippingCostsTotal,
      advertisingCostsTotal,
      otherCostsTotal,
      totalCosts,
      profitPerUnit,
      netProfit,
      profitMarginPercent,
      roiPercent,
    };
  }, [formData]);

  const handleSave = () => {
    saveResult({
      toolId: 'amazon-profit-calculator',
      toolName: 'Amazon Profit Calculator',
      category: 'amazon',
      title: `Amazon Unit Profit: ${currency}${calculations.profitPerUnit.toFixed(2)} (${calculations.profitMarginPercent.toFixed(1)}%)`,
      preview: `Price: ${currency}${formData.sellingPrice} | Units: ${formData.unitsSold} | Batch Profit: ${currency}${calculations.netProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} | ROI: ${calculations.roiPercent.toFixed(1)}%`,
      content: `Selling Price: ${currency}${formData.sellingPrice}\nCost of Goods: ${currency}${formData.productCost}\nShipping: ${currency}${formData.shippingCost}\nAmazon Referral (${formData.referralFeePercent}%): ${currency}${calculations.referralFeePerUnit.toFixed(2)}\nFBA Fee: ${currency}${formData.fbaFee}\nAd Cost / Unit: ${currency}${formData.adCostPerUnit}\nTotal Units: ${formData.unitsSold}\n\nTotal Revenue: ${currency}${calculations.revenue.toFixed(2)}\nTotal Amazon Fees: ${currency}${calculations.amazonFeesTotal.toFixed(2)}\nTotal Sourcing/Shipping: ${currency}${calculations.productCostsTotal.toFixed(2)}\nTotal Ad Spend: ${currency}${calculations.advertisingCostsTotal.toFixed(2)}\n\nNet Batch Profit: ${currency}${calculations.netProfit.toFixed(2)}\nNet Margin: ${calculations.profitMarginPercent.toFixed(1)}%\nROI: ${calculations.roiPercent.toFixed(1)}%`,
      data: {
        ...formData,
        ...calculations,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const isProfitable = calculations.profitPerUnit > 0;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="mb-6">
        <a
          href="/tools"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors mb-3 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Tools Directory
        </a>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="amber">Amazon Seller Tools</Badge>
              <Badge variant="emerald">FBA Profitability</Badge>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Amazon Profit Calculator
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Analyze product viability, estimate FBA fees, compute net margin, and forecast batch profits.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSave}
            leftIcon={saved ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
          >
            {saved ? 'Calculation Saved' : 'Save Calculation'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs */}
        <div className="lg:col-span-5">
          <Card className="p-5 sm:p-6 bg-white shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-5 pb-3 border-b border-slate-100 flex items-center justify-between">
              <span>Unit Economics</span>
              <span className="text-[11px] font-normal text-slate-400">All fields customizable</span>
            </h2>

            <div className="space-y-4">
              <Input
                label="Selling Price (List Price)"
                type="number"
                min="0"
                step="0.01"
                leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                value={formData.sellingPrice}
                onChange={(e) => setFormData({ ...formData, sellingPrice: parseFloat(e.target.value) || 0 })}
                helperText="Customer buy box price."
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Product Cost (COGS)"
                  type="number"
                  min="0"
                  step="0.01"
                  leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                  value={formData.productCost}
                  onChange={(e) => setFormData({ ...formData, productCost: parseFloat(e.target.value) || 0 })}
                  helperText="Supplier unit cost."
                />

                <Input
                  label="Shipping to FBA"
                  type="number"
                  min="0"
                  step="0.01"
                  leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                  value={formData.shippingCost}
                  onChange={(e) => setFormData({ ...formData, shippingCost: parseFloat(e.target.value) || 0 })}
                  helperText="Freight / unit."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Amazon Referral Fee (%)"
                  type="number"
                  min="0"
                  max="45"
                  step="0.5"
                  rightSuffix="%"
                  value={formData.referralFeePercent}
                  onChange={(e) => setFormData({ ...formData, referralFeePercent: parseFloat(e.target.value) || 0 })}
                  helperText="Standard category fee is 15%."
                />

                <Input
                  label="Amazon FBA Fee"
                  type="number"
                  min="0"
                  step="0.01"
                  leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                  value={formData.fbaFee}
                  onChange={(e) => setFormData({ ...formData, fbaFee: parseFloat(e.target.value) || 0 })}
                  helperText="Pick, pack & weight fee."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Ad Spend / Unit Sold"
                  type="number"
                  min="0"
                  step="0.01"
                  leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                  value={formData.adCostPerUnit}
                  onChange={(e) => setFormData({ ...formData, adCostPerUnit: parseFloat(e.target.value) || 0 })}
                  helperText="Blended PPC allowance."
                />

                <Input
                  label="Other Costs / Packaging"
                  type="number"
                  min="0"
                  step="0.01"
                  leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                  value={formData.otherCosts}
                  onChange={(e) => setFormData({ ...formData, otherCosts: parseFloat(e.target.value) || 0 })}
                  helperText="Labels, prep, returns."
                />
              </div>

              <Input
                label="Units Sold (Forecasted Batch)"
                type="number"
                min="1"
                step="10"
                value={formData.unitsSold}
                onChange={(e) => setFormData({ ...formData, unitsSold: parseInt(e.target.value) || 1 })}
                helperText="Simulate monthly inventory volume."
              />
            </div>

            <div className="mt-4 p-3 bg-amber-50/60 border border-amber-200/50 rounded-lg text-xs text-amber-900 leading-relaxed flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                Note: Fee structures vary by product tier and dimension. Enter your estimated or seller central quote values for exact calculations.
              </span>
            </div>
          </Card>
        </div>

        {/* Results & Breakdown */}
        <div className="lg:col-span-7 space-y-6">
          {/* Main Profit Card */}
          <div
            className={`rounded-xl border p-6 shadow-xs ${
              isProfitable
                ? 'border-emerald-200 bg-gradient-to-br from-emerald-50/70 via-white to-emerald-50/30'
                : 'border-rose-200 bg-gradient-to-br from-rose-50/70 via-white to-rose-50/30'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span
                  className={`text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    isProfitable
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {isProfitable ? 'Net Profit Per Unit' : 'Net Loss Per Unit'}
                </span>
                <p className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2 font-mono">
                  {currency}{calculations.profitPerUnit.toFixed(2)}
                  <span className="text-base font-normal text-slate-500"> / unit</span>
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  Margin: <strong className="font-semibold">{calculations.profitMarginPercent.toFixed(1)}%</strong> | ROI: <strong className="font-semibold">{calculations.roiPercent.toFixed(1)}%</strong>
                </p>
              </div>

              <div className="text-left sm:text-right">
                <span className="text-xs text-slate-500">Batch Net Profit ({formData.unitsSold} units)</span>
                <p
                  className={`text-2xl font-bold font-mono ${
                    isProfitable ? 'text-emerald-700' : 'text-rose-700'
                  }`}
                >
                  {currency}{calculations.netProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </div>

          {/* Grid of Key Calculations */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Card className="p-3.5 bg-white">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Revenue</span>
              <p className="text-lg font-bold text-slate-900 mt-1 font-mono">{currency}{calculations.revenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            </Card>

            <Card className="p-3.5 bg-white">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Amazon Fees</span>
              <p className="text-lg font-bold text-amber-700 mt-1 font-mono">{currency}{calculations.amazonFeesTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            </Card>

            <Card className="p-3.5 bg-white">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Product Costs</span>
              <p className="text-lg font-bold text-slate-700 mt-1 font-mono">{currency}{calculations.productCostsTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            </Card>

            <Card className="p-3.5 bg-white">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Ad Spend</span>
              <p className="text-lg font-bold text-indigo-700 mt-1 font-mono">{currency}{calculations.advertisingCostsTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            </Card>
          </div>

          {/* Visual Breakdown Bar */}
          <Card className="p-6 bg-white">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Revenue & Cost Allocation Breakdown
              </h3>
              <span className="text-xs text-slate-500">Per $100 Generated</span>
            </div>

            <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex mb-4">
              <div
                style={{ width: `${Math.max(0, Math.min(100, (calculations.productCostsTotal / (calculations.revenue || 1)) * 100))}%` }}
                className="bg-slate-500 h-full"
                title="Product Costs"
              />
              <div
                style={{ width: `${Math.max(0, Math.min(100, (calculations.amazonFeesTotal / (calculations.revenue || 1)) * 100))}%` }}
                className="bg-amber-400 h-full"
                title="Amazon Fees"
              />
              <div
                style={{ width: `${Math.max(0, Math.min(100, (calculations.advertisingCostsTotal / (calculations.revenue || 1)) * 100))}%` }}
                className="bg-indigo-400 h-full"
                title="Advertising"
              />
              {isProfitable && (
                <div
                  style={{ width: `${Math.max(0, Math.min(100, (calculations.netProfit / (calculations.revenue || 1)) * 100))}%` }}
                  className="bg-emerald-500 h-full"
                  title="Net Profit"
                />
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-sm bg-slate-500 shrink-0" />
                <div>
                  <span className="text-slate-500">Sourcing:</span>{' '}
                  <strong className="text-slate-800 font-mono">{currency}{calculations.productCostsTotal.toFixed(0)}</strong>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-sm bg-amber-400 shrink-0" />
                <div>
                  <span className="text-slate-500">Amazon Fees:</span>{' '}
                  <strong className="text-slate-800 font-mono">{currency}{calculations.amazonFeesTotal.toFixed(0)}</strong>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-sm bg-indigo-400 shrink-0" />
                <div>
                  <span className="text-slate-500">PPC Ads:</span>{' '}
                  <strong className="text-slate-800 font-mono">{currency}{calculations.advertisingCostsTotal.toFixed(0)}</strong>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-sm bg-emerald-500 shrink-0" />
                <div>
                  <span className="text-slate-500">Net Profit:</span>{' '}
                  <strong className="text-emerald-700 font-mono">{currency}{calculations.netProfit.toFixed(0)}</strong>
                </div>
              </div>
            </div>
          </Card>

          {/* Adsterra Medium Rectangle 300x250 (ID: 31491251) & Smartlink Promo */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            <AdBanner size="300x250" />
            <SmartlinkPromo
              variant="card"
              title="Amazon FBA Sourcing & Software Deals"
              description="Discover verified supplier directories, product research software discounts, and seller optimization tools."
            />
          </div>
        </div>
      </div>

      {/* SEO & Educational Guide Section */}
      <section className="mt-16 pt-12 border-t border-slate-200/80 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-700 text-xs font-semibold mb-3 border border-amber-100">
            <Lightbulb className="h-3.5 w-3.5 text-amber-600" />
            <span>Amazon FBA Seller Guide</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            How to Calculate Amazon FBA Profit & Net Margins Accurately
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Master the mathematics of marketplace selling. Learn how to use an Amazon profit calculator to analyze product sourcing, FBA fulfillment fees, advertising spend, and true net margins before launching inventory.
          </p>
        </div>

        {/* 3 Core Conceptual Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4 font-bold">
              <Calculator className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              What an Amazon Profit Calculator Does
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              An <strong>Amazon profit calculator</strong> is a vital financial analysis tool that determines your exact unit profit and return on investment (ROI). Instead of guessing retail margins, an <strong>Amazon FBA calculator</strong> combines unit sourcing, freight logistics, marketplace commissions, and PPC ad spend into an accurate bottom-line metric.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4 font-bold">
              <Percent className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              Why Revenue Differs from Actual Profit
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Top-line sales revenue (selling price multiplied by units sold) can be deceptive. A product generating $50,000 in monthly revenue might only yield $5,000 in actual cash profit after deducting manufacturing, shipping, and advertising costs. Tracking net profit ensures your e-commerce business remains genuinely cash-flow positive.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 font-bold">
              <Layers className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              How Amazon Fees Affect Margins
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Amazon charges a category referral fee (typically 8% to 15%) alongside FBA fulfillment fees dictated by product weight and dimensions. Together with monthly inventory storage and returns, marketplace fees can absorb 30% or more of your retail price, making precise calculation critical before ordering stock.
            </p>
          </Card>
        </div>

        {/* Detailed Breakdown: Cost Elements & Margin Strategy */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80 space-y-6">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
              E-Commerce Economics
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              Key Cost Elements in Amazon FBA Profitability
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Every profitable private-label and wholesale seller tracks these distinct cost categories to maintain healthy margins:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-slate-50 text-slate-600 shrink-0 mt-0.5">
                  <Package className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    Cost of Goods Sold (COGS) & Freight
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    COGS includes factory manufacturing, custom packaging, product inserts, and barcode labeling. Freight encompasses ocean or air shipping from your supplier to Amazon fulfillment centers, along with customs tariffs, port handling, and domestic drayage.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600 shrink-0 mt-0.5">
                  <Truck className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    FBA Pick, Pack & Weight Fees
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Amazon calculates FBA fulfillment fees based on packaged dimensions and shipping weight. Small packaging reductions can shift your product into a lower size tier, saving dollars per unit across thousands of sales.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0 mt-0.5">
                  <TrendingUp className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    PPC Advertising Costs per Unit
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    In competitive categories, paid ads (Sponsored Products and Brands) are required to secure listing visibility. Factoring your target ad cost per unit into your profit formula prevents advertising from turning a profitable product into a losing venture.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 shrink-0 mt-0.5">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    Understanding Healthy Profit Margins
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Your net profit margin percentage equals <code>(Net Profit / Selling Price) × 100</code>. While high-volume wholesale sellers may operate on 10% to 15% margins, private-label brand owners generally aim for 20% to 30% net margin to absorb promotional coupons and return fees.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* How to use the calculator */}
          <div className="p-5 rounded-xl bg-white border border-slate-200/70 mt-4">
            <h4 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              How to Use the ToolFlow Amazon Profit Calculator (Step-by-Step)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">1. Retail Selling Price</span>
                <span className="text-slate-500">Enter your target listing price on Amazon.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">2. Sourcing & Shipping</span>
                <span className="text-slate-500">Input unit manufacturing cost plus international freight.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">3. Amazon Fees</span>
                <span className="text-slate-500">Specify your referral fee percentage and FBA fee per unit.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">4. Advertising & Other</span>
                <span className="text-slate-500">Include your estimated PPC ad spend and packaging overhead.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">5. Units & Batch ROI</span>
                <span className="text-slate-500">Set total units to review batch profit, net margin, and ROI.</span>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Frequently Asked Questions
              </h3>
              <p className="text-xs sm:text-sm text-slate-500">
                Everything you need to know about calculating Amazon FBA profits, margins, and seller fees.
              </p>
            </div>
          </div>

          <div className="mt-6 divide-y divide-slate-100">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={index} className="py-4 first:pt-0 last:pb-0">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between text-left gap-4 group cursor-pointer focus:outline-none"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                      {item.question}
                    </span>
                    <span className="p-1 rounded-md text-slate-400 group-hover:text-amber-600 shrink-0">
                      {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="mt-2.5 pr-8 text-xs sm:text-sm text-slate-600 leading-relaxed font-sans animate-in fade-in duration-200">
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Internal Links Directory */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80">
          <div className="mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Explore More Tools
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              E-Commerce & Freelance Productivity Suite
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Optimize advertising campaigns, product listings, client proposals, and business pricing with our complete utility toolkit:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Amazon PPC Calculator */}
            <a
              href="/tools/amazon-ppc-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-ppc-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-blue-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
                  <TrendingUp className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                Amazon PPC Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Determine target ACoS, break-even ad spend, and optimal cost-per-click bids for your sponsored product campaigns.
              </p>
            </a>

            {/* Amazon Keyword Generator */}
            <a
              href="/tools/amazon-keyword-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-keyword-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-emerald-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                  <Target className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                Amazon Keyword Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Generate high-search-intent keywords, backend search terms, and PPC target queries to scale marketplace listing traffic.
              </p>
            </a>

            {/* Proposal Generator */}
            <a
              href="/tools/proposal-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/proposal-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                  <FileText className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                AI Proposal Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Draft tailored, high-converting client proposals and consulting pitches for Upwork, Fiverr, and agency contracts.
              </p>
            </a>

            {/* Freelancer Rate Calculator */}
            <a
              href="/tools/freelancer-rate-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/freelancer-rate-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-emerald-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                  <Clock className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                Freelancer Rate Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Determine your minimum billable hourly rate accounting for business overhead, self-employment taxes, and take-home goals.
              </p>
            </a>

            {/* Social Caption Generator */}
            <a
              href="/tools/social-caption-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/social-caption-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-pink-400 hover:shadow-xs transition-all group block sm:col-span-2 lg:col-span-1"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-pink-50 text-pink-600">
                  <Sparkles className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-pink-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-pink-600 transition-colors">
                Social Caption Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Create engaging social media copy, viral product hooks, and hashtag recommendations for client campaigns and e-commerce brands.
              </p>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
