import React, { useState, useMemo } from 'react';
import { AmazonPpcFormData } from '../../types';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Card } from '../../components/common/Card';
import { StatCard } from '../../components/common/StatCard';
import { Badge } from '../../components/common/Badge';
import { usePageSEO } from '../../utils/usePageSEO';
import { PRODUCTION_ORIGIN } from '../../utils/canonicalUrl';
import {
  BarChart3,
  Bookmark,
  ArrowLeft,
  ArrowRight,
  Check,
  Info,
  HelpCircle,
  TrendingUp,
  Percent,
  Calculator,
  Layers,
  Lightbulb,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Target,
  DollarSign,
  Scale,
  Sparkles,
} from 'lucide-react';
import { AdBanner, SmartlinkPromo } from '../../components/ads';

interface AmazonPpcCalculatorPageProps {
  onNavigate: (path: string) => void;
}

export const AmazonPpcCalculatorPage: React.FC<AmazonPpcCalculatorPageProps> = ({
  onNavigate,
}) => {
  const { currency, saveResult } = useApp();

  const [formData, setFormData] = useState<AmazonPpcFormData>({
    adSpend: 2400,
    adSales: 8000,
    totalSales: 22000,
  });

  const [saved, setSaved] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const calculations = useMemo(() => {
    const spend = Number(formData.adSpend) || 0;
    const adSales = Number(formData.adSales) || 0;
    const totalSales = Number(formData.totalSales) || 0;

    const acos = adSales > 0 ? (spend / adSales) * 100 : 0;
    const tacos = totalSales > 0 ? (spend / totalSales) * 100 : 0;
    const roas = spend > 0 ? adSales / spend : 0;
    const adSalesPercentage = totalSales > 0 ? (adSales / totalSales) * 100 : 0;
    const organicSales = Math.max(0, totalSales - adSales);
    const organicPercentage = totalSales > 0 ? (organicSales / totalSales) * 100 : 0;

    return {
      acos: Math.round(acos * 10) / 10,
      tacos: Math.round(tacos * 10) / 10,
      roas: Math.round(roas * 100) / 100,
      adSalesPercentage: Math.round(adSalesPercentage * 10) / 10,
      organicSales,
      organicPercentage: Math.round(organicPercentage * 10) / 10,
    };
  }, [formData]);

  const handleSave = () => {
    saveResult({
      toolId: 'amazon-ppc-calculator',
      toolName: 'Amazon PPC / ACOS Calculator',
      category: 'amazon',
      title: `PPC Audit: ACOS ${calculations.acos}% | TACOS ${calculations.tacos}% | ROAS ${calculations.roas}x`,
      preview: `Spend: ${currency}${formData.adSpend} | Ad Sales: ${currency}${formData.adSales} | Total: ${currency}${formData.totalSales} | Organic Share: ${calculations.organicPercentage}%`,
      content: `Ad Spend: ${currency}${formData.adSpend}\nAd Sales: ${currency}${formData.adSales}\nTotal Sales: ${currency}${formData.totalSales}\n\nACOS: ${calculations.acos}%\nTACOS: ${calculations.tacos}%\nROAS: ${calculations.roas}x\nAd Sales % of Total: ${calculations.adSalesPercentage}%\nEstimated Organic Sales: ${currency}${calculations.organicSales} (${calculations.organicPercentage}%)`,
      data: {
        ...formData,
        ...calculations,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  // Status badges based on standard Amazon PPC thresholds
  const getAcosStatus = (acos: number) => {
    if (acos <= 20) return { label: 'Excellent (High Profit)', color: 'text-emerald-700 bg-emerald-50 border-emerald-200' };
    if (acos <= 35) return { label: 'Target / Healthy', color: 'text-indigo-700 bg-indigo-50 border-indigo-200' };
    if (acos <= 50) return { label: 'Acceptable for Launch', color: 'text-amber-700 bg-amber-50 border-amber-200' };
    return { label: 'High / Needs Optimization', color: 'text-rose-700 bg-rose-50 border-rose-200' };
  };

  const getTacosStatus = (tacos: number) => {
    if (tacos <= 10) return { label: 'Very Healthy (Strong Organic)', color: 'text-emerald-700 bg-emerald-50 border-emerald-200' };
    if (tacos <= 15) return { label: 'Healthy Baseline', color: 'text-indigo-700 bg-indigo-50 border-indigo-200' };
    return { label: 'Ad-Reliant Account', color: 'text-amber-700 bg-amber-50 border-amber-200' };
  };

  const acosStatus = getAcosStatus(calculations.acos);
  const tacosStatus = getTacosStatus(calculations.tacos);

  // FAQ Items for education and structured data
  const faqItems = [
    {
      question: 'What is ACOS and how is it calculated?',
      answer:
        'ACOS (Advertising Cost of Sales) is the percentage of direct ad revenue spent on advertising clicks. It is calculated with the formula: ACOS = (Total Ad Spend / Attributed Ad Sales) × 100. For example, if you spend $250 on Amazon Sponsored Products and generate $1,000 in direct ad sales, your ACOS is 25%. A lower ACOS indicates higher direct campaign efficiency.',
    },
    {
      question: 'What is TACOS and why is it often more important than ACOS?',
      answer:
        'TACOS (Total Advertising Cost of Sales) measures advertising spend relative to your total gross revenue (both organic and paid sales combined): TACOS = (Total Ad Spend / Total Catalog Sales) × 100. TACOS reveals your catalog’s true dependence on advertising. A healthy TACOS (typically 8% to 15%) means PPC campaigns are driving organic keyword ranking momentum, leading to lucrative non-paid sales.',
    },
    {
      question: 'What is a good ACOS benchmark for Amazon sellers?',
      answer:
        'A "good" ACOS depends on your product life cycle and profit margins. For brand-new product launches, an ACOS of 40% to 70% is common to establish initial sales velocity and indexing. For mature products, a target ACOS of 20% to 30% allows sellers to capture consistent net profit. Always compare your ACOS against your pre-advertising gross profit margin to ensure profitability.',
    },
    {
      question: 'How do I calculate Break-Even ACOS?',
      answer:
        'Your Break-Even ACOS is exactly equal to your profit margin before advertising costs: Break-Even ACOS = (Selling Price - COGS - Amazon Referral Fees - FBA Fees - Other Expenses) / Selling Price × 100. If your product sells for $40 and you retain $12 before advertising (a 30% profit margin), your break-even ACOS is 30%. At 30% ACOS you break even; below 30% you earn net profit.',
    },
    {
      question: 'What is ROAS and how does it relate to ACOS?',
      answer:
        'ROAS (Return on Ad Spend) is the mathematical inverse of ACOS: ROAS = Attributed Ad Sales / Total Ad Spend, or ROAS = 100 / ACOS. For example, an ACOS of 25% corresponds to a 4.0x ROAS (generating $4.00 of revenue for every $1.00 spent on advertising). High ROAS indicates higher gross return per ad dollar invested.',
    },
    {
      question: 'Why is my TACOS increasing even if my ACOS is stable?',
      answer:
        'If your TACOS is increasing while your ACOS remains steady, your organic sales velocity is declining. This signals that your products may be losing organic search keyword rankings, suffering from customer review attrition, or experiencing increased competition on organic listings, forcing you to rely more heavily on paid ad clicks to maintain revenue.',
    },
    {
      question: 'How can I lower my Amazon ACOS without hurting my organic sales rank?',
      answer:
        'To lower ACOS without damaging organic rankings: (1) Add non-converting customer search terms as negative exact and negative phrase keywords; (2) Decrease bids on high-cost, low-conversion keywords rather than pausing them completely; (3) Reallocate ad budget to high-intent long-tail keywords; and (4) Optimize listing title, images, and bullet points to lift conversion rate (CVR), which lowers effective acquisition costs.',
    },
  ];

  // Structured Data Schema (WebApplication + FAQPage)
  const canonicalHref = `${PRODUCTION_ORIGIN}/tools/amazon-ppc-calculator`;
  const seoTitle = 'Amazon PPC Calculator – Calculate ACOS, TACOS & ROAS | ToolFlow';
  const seoDescription =
    'Free Amazon PPC calculator to audit ACOS, TACOS, and ROAS. Calculate break-even advertising targets, organic vs. paid sales split, and ad efficiency with ToolFlow.';

  const structuredData = [
    {
      '@context': 'https://schema.org',
      '@type': 'WebApplication',
      name: 'Amazon PPC / ACOS Calculator',
      applicationCategory: 'BusinessApplication',
      operatingSystem: 'All',
      url: canonicalHref,
      description: seoDescription,
    },
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: faqItems.map((item) => ({
        '@type': 'Question',
        name: item.question,
        acceptedAnswer: {
          '@type': 'Answer',
          text: item.answer,
        },
      })),
    },
  ];

  // Hook handles title, meta description, canonical, robots, OG tags, and JSON-LD cleanup
  usePageSEO({
    title: seoTitle,
    description: seoDescription,
    canonicalPath: '/tools/amazon-ppc-calculator',
    robots: 'index, follow',
    ogType: 'website',
    jsonLdId: 'amazon-ppc-calculator-schema',
    jsonLd: structuredData,
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="mb-6">
        <a
          href="/tools"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors mb-3 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Tools Directory
        </a>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="amber">Amazon Seller Tools</Badge>
              <Badge variant="indigo">PPC Advertising</Badge>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Amazon PPC / ACOS Calculator
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Audit campaign efficiency, compare ACOS vs. TACOS, and measure advertising impact on overall brand velocity.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSave}
            leftIcon={saved ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
          >
            {saved ? 'Audit Saved' : 'Save PPC Audit'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs */}
        <div className="lg:col-span-5">
          <Card className="p-5 sm:p-6 bg-white shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-5 pb-3 border-b border-slate-100 flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-indigo-600" />
              Campaign Advertising Data
            </h2>

            <div className="space-y-4">
              <Input
                label="Total Ad Spend"
                type="number"
                min="0"
                step="50"
                leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                value={formData.adSpend}
                onChange={(e) => setFormData({ ...formData, adSpend: parseFloat(e.target.value) || 0 })}
                helperText="Total advertising cost across Sponsored Products, Brands & Display."
              />

              <Input
                label="Direct Ad Sales (Attributed PPC Revenue)"
                type="number"
                min="0"
                step="100"
                leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                value={formData.adSales}
                onChange={(e) => setFormData({ ...formData, adSales: parseFloat(e.target.value) || 0 })}
                helperText="Sales directly attributed to PPC clicks in Seller Central."
              />

              <Input
                label="Total Sales (Organic + Ad Sales)"
                type="number"
                min="0"
                step="100"
                leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                value={formData.totalSales}
                onChange={(e) => setFormData({ ...formData, totalSales: parseFloat(e.target.value) || 0 })}
                helperText="Gross sales across all channels / ASINs for the reporting period."
              />
            </div>

            <div className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2 text-xs text-slate-600">
              <div className="flex justify-between items-center">
                <span>Calculated Organic Sales:</span>
                <strong className="text-slate-900 font-mono">{currency}{calculations.organicSales.toLocaleString()}</strong>
              </div>
              <div className="flex justify-between items-center">
                <span>Organic Share of Account:</span>
                <strong className="text-emerald-700 font-mono">{calculations.organicPercentage}%</strong>
              </div>
            </div>
          </Card>
        </div>

        {/* Results & Educational Explanations */}
        <div className="lg:col-span-7 space-y-6">
          {/* Main Metric Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="p-5 bg-white border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">ACOS</span>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${acosStatus.color}`}>
                  {acosStatus.label}
                </span>
              </div>
              <p className="text-3xl font-extrabold text-slate-900 font-mono">
                {calculations.acos}%
              </p>
              <p className="text-xs text-slate-500 mt-2">
                Advertising Cost of Sales: (Ad Spend / Ad Sales) × 100
              </p>
            </Card>

            <Card className="p-5 bg-white border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">TACOS</span>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${tacosStatus.color}`}>
                  {tacosStatus.label}
                </span>
              </div>
              <p className="text-3xl font-extrabold text-slate-900 font-mono">
                {calculations.tacos}%
              </p>
              <p className="text-xs text-slate-500 mt-2">
                Total ACOS: (Ad Spend / Total Sales) × 100
              </p>
            </Card>

            <StatCard
              label="ROAS (Return on Ad Spend)"
              value={`${calculations.roas}x`}
              subtext={`Every $1 spent returns $${calculations.roas.toFixed(2)} in ad revenue`}
              icon={<TrendingUp className="h-5 w-5" />}
              variant="highlight"
            />

            <StatCard
              label="Ad Sales % of Total"
              value={`${calculations.adSalesPercentage}%`}
              subtext={`Remaining ${calculations.organicPercentage}% generated organically`}
              icon={<Percent className="h-5 w-5" />}
            />
          </div>

          {/* Quick Metric Guidelines Card */}
          <Card className="p-6 bg-white space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 pb-2 border-b border-slate-100 flex items-center gap-2">
              <Info className="h-4 w-4 text-indigo-600" />
              Campaign Performance Guidelines
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600">
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-100">
                <h4 className="font-bold text-slate-900 mb-1">What is ACOS?</h4>
                <p className="leading-relaxed">
                  Measures the direct efficiency of your ad campaigns. If your profit margin before advertising is 30%, your break-even ACOS is exactly 30%. Anything lower generates net profit.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-100">
                <h4 className="font-bold text-slate-900 mb-1">What is TACOS?</h4>
                <p className="leading-relaxed">
                  Measures advertising spend against your whole catalog revenue. Healthy mature brands target a TACOS between 8% to 15%, showing organic ranking momentum.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-100">
                <h4 className="font-bold text-slate-900 mb-1">What is ROAS?</h4>
                <p className="leading-relaxed">
                  The mathematical inverse of ACOS (1 / ACOS). A 25% ACOS equals a 4.0x ROAS. Higher ROAS means more revenue generated per ad dollar deployed.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-100">
                <h4 className="font-bold text-slate-900 mb-1">PPC Optimization Strategy</h4>
                <p className="leading-relaxed">
                  During product launch, higher ACOS is expected to earn organic keyword rank. Once top-of-search rank is secured, taper bids down to defend target TACOS.
                </p>
              </div>
            </div>
          </Card>

          {/* Adsterra Half Skyscraper 160x300 (ID: 31491253) and Medium Rectangle 300x250 (ID: 31491251) */}
          <div className="flex flex-wrap items-center justify-center gap-6 pt-2">
            <AdBanner size="160x300" />
            <AdBanner size="300x250" />
          </div>
        </div>
      </div>

      {/* SEO & Educational Guide Section */}
      <section className="mt-16 pt-12 border-t border-slate-200/80 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold mb-3 border border-indigo-100">
            <Lightbulb className="h-3.5 w-3.5 text-indigo-600" />
            <span>Amazon PPC Optimization Guide</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            How to Calculate Amazon ACOS, TACOS & ROAS Accurately
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Master the vital mathematical formulas behind Amazon Sponsored Products, Sponsored Brands, and Sponsored Display campaigns. Learn how to calculate break-even targets, monitor total catalog health, and scale profitable advertising.
          </p>
        </div>

        {/* 4 Core Mathematical Formula Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          <Card className="p-5 bg-white border border-slate-200 shadow-xs">
            <div className="h-9 w-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3">
              <Percent className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">ACOS Formula</h3>
            <div className="p-2.5 rounded bg-slate-50 border border-slate-100 my-2 font-mono text-xs font-semibold text-slate-800">
              (Ad Spend / Ad Sales) × 100
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Calculates the direct ad cost percentage required to produce one dollar of paid sales. Lower ACOS indicates more efficient direct clicks.
            </p>
          </Card>

          <Card className="p-5 bg-white border border-slate-200 shadow-xs">
            <div className="h-9 w-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3">
              <Layers className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">TACOS Formula</h3>
            <div className="p-2.5 rounded bg-slate-50 border border-slate-100 my-2 font-mono text-xs font-semibold text-slate-800">
              (Ad Spend / Total Sales) × 100
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Measures total advertising spend against all gross catalog sales (organic + PPC). Reveals true reliance on paid advertising.
            </p>
          </Card>

          <Card className="p-5 bg-white border border-slate-200 shadow-xs">
            <div className="h-9 w-9 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center mb-3">
              <TrendingUp className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">ROAS Formula</h3>
            <div className="p-2.5 rounded bg-slate-50 border border-slate-100 my-2 font-mono text-xs font-semibold text-slate-800">
              Ad Sales / Ad Spend
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              The return multiple on your advertising dollars. A 4.0x ROAS means every $1 spent produces $4.00 in direct attributed ad revenue.
            </p>
          </Card>

          <Card className="p-5 bg-white border border-slate-200 shadow-xs">
            <div className="h-9 w-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center mb-3">
              <Scale className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">Break-Even ACOS</h3>
            <div className="p-2.5 rounded bg-slate-50 border border-slate-100 my-2 font-mono text-xs font-semibold text-slate-800">
              Pre-Ad Profit Margin %
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              The exact ACOS threshold where your ad spend consumes all gross margin without incurring a cash loss.
            </p>
          </Card>
        </div>

        {/* Step-by-Step Calculator Walkthrough */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-6">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Practical Walkthrough
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              How to Use the ToolFlow Amazon PPC Calculator in 5 Steps
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Follow this step-by-step workflow using standard reporting figures from your Amazon Advertising Console.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 text-xs text-slate-600">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
              <div className="h-7 w-7 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                1
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Select Your Reporting Window</h4>
              <p className="leading-relaxed">
                Log into Amazon Seller Central or Amazon Advertising Console. Choose a representative reporting period (typically the last 14, 30, or 60 days) to smooth out attribution delays.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
              <div className="h-7 w-7 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                2
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Enter Total Ad Spend</h4>
              <p className="leading-relaxed">
                Enter your total advertising expenditure across all active campaigns (Sponsored Products, Sponsored Brands, and Sponsored Display) in the <strong>Total Ad Spend</strong> field.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
              <div className="h-7 w-7 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                3
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Input Attributed PPC Sales</h4>
              <p className="leading-relaxed">
                Enter the direct revenue generated by advertising clicks in the <strong>Direct Ad Sales</strong> input. This calculates your direct campaign ACOS and ROAS in real time.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
              <div className="h-7 w-7 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                4
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Input Gross Catalog Revenue</h4>
              <p className="leading-relaxed">
                Enter your total gross sales across the entire account or specific ASIN from your Business Reports. The calculator automatically deduces organic sales and calculates TACOS.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
              <div className="h-7 w-7 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                5
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Analyze Organic vs. Paid Ratio</h4>
              <p className="leading-relaxed">
                Review your organic share percentage. If organic sales represent over 60% of total revenue, your advertising is effectively supporting organic keyword ranking momentum.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
              <div className="h-7 w-7 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                6
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Save & Track Your Benchmark</h4>
              <p className="leading-relaxed">
                Click <strong>Save PPC Audit</strong> to store your audit record in your local ToolFlow workspace for bi-weekly comparison as you test bids, placements, and negative keywords.
              </p>
            </div>
          </div>
        </div>

        {/* Campaign Lifecycle Target Benchmarks */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-6">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
              Strategic Benchmarks
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              Target ACOS & TACOS by Product Lifecycle Stage
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Setting realistic advertising targets depends on whether your product is newly launched, scaling, or dominating its category.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="p-5 bg-white border border-slate-200">
              <div className="inline-block px-2.5 py-1 rounded bg-amber-50 text-amber-800 text-[11px] font-bold uppercase tracking-wider mb-3">
                1. Product Launch Phase
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">Aggressive Rank Building</h4>
              <div className="space-y-1.5 text-xs text-slate-600 mb-4">
                <p><strong>Target ACOS:</strong> 45% – 75%</p>
                <p><strong>Target TACOS:</strong> 20% – 30%</p>
                <p><strong>Primary Goal:</strong> Keyword indexing & initial sales velocity</p>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                During the honeymoon period, your goal is to trigger Amazon’s A10 ranking algorithm. Bidding aggressively on primary search terms earns early sales that establish permanent organic placement.
              </p>
            </Card>

            <Card className="p-5 bg-white border border-slate-200">
              <div className="inline-block px-2.5 py-1 rounded bg-indigo-50 text-indigo-800 text-[11px] font-bold uppercase tracking-wider mb-3">
                2. Scaling & Growth Phase
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">Efficiency & Expansion</h4>
              <div className="space-y-1.5 text-xs text-slate-600 mb-4">
                <p><strong>Target ACOS:</strong> 25% – 35%</p>
                <p><strong>Target TACOS:</strong> 10% – 15%</p>
                <p><strong>Primary Goal:</strong> Profitable scale & negative keyword harvesting</p>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                As organic ranking takes hold, negative keyword pruning and bid adjustments trim wasted spend while maintaining top-of-search presence for your most lucrative converted search terms.
              </p>
            </Card>

            <Card className="p-5 bg-white border border-slate-200">
              <div className="inline-block px-2.5 py-1 rounded bg-emerald-50 text-emerald-800 text-[11px] font-bold uppercase tracking-wider mb-3">
                3. Mature / Harvesting Phase
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2">Maximum Cash Flow</h4>
              <div className="space-y-1.5 text-xs text-slate-600 mb-4">
                <p><strong>Target ACOS:</strong> 15% – 25%</p>
                <p><strong>Target TACOS:</strong> 6% – 10%</p>
                <p><strong>Primary Goal:</strong> Net profit extraction & brand defense</p>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Organic sales account for 70%+ of catalog revenue. PPC bids focus defensively on your own branded keywords and highly converting exact-match search terms, maximizing free cash flow.
              </p>
            </Card>
          </div>
        </div>

        {/* Related ToolFlow Amazon Tools Cross-Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="p-6 bg-white border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3">
                <Calculator className="h-5 w-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1">
                Amazon FBA Profit & Margin Calculator
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                Need to know your exact pre-advertising profit margins and break-even ACOS? Calculate referral fees, FBA pick-and-pack rates, and net profits per unit with our dedicated profit calculator.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              href="/tools/amazon-profit-calculator"
              onNavigate={onNavigate}
              rightIcon={<ArrowRight className="h-3.5 w-3.5" />}
            >
              Open Amazon Profit Calculator
            </Button>
          </Card>

          <Card className="p-6 bg-white border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3">
                <Target className="h-5 w-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1">
                Amazon Keyword & Search Term Generator
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                Lower your CPC bids and discover high-intent long-tail search terms with low competition. Generate targeted keywords for your Sponsored Products manual campaigns.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              href="/tools/amazon-keyword-generator"
              onNavigate={onNavigate}
              rightIcon={<ArrowRight className="h-3.5 w-3.5" />}
            >
              Open Amazon Keyword Generator
            </Button>
          </Card>
        </div>

        {/* Interactive FAQ Section */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-6">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Frequently Asked Questions
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              Frequently Asked Questions About Amazon PPC & ACOS
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Clear, practical answers on campaign bidding, TACOS ratios, ROAS benchmarks, and Amazon advertising optimization.
            </p>
          </div>

          <div className="space-y-3">
            {faqItems.map((faq, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-slate-200/80 bg-slate-50/50 overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full px-5 py-4 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-100/60 transition-colors"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm font-bold text-slate-900 flex items-center gap-2.5">
                      <HelpCircle className="h-4 w-4 text-indigo-600 shrink-0" />
                      {faq.question}
                    </span>
                    <span className="text-slate-400 shrink-0">
                      {isOpen ? (
                        <ChevronUp className="h-4 w-4 text-indigo-600" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-white">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};
