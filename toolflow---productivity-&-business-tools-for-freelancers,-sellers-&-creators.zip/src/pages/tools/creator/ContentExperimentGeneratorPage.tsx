import React, { useState } from 'react';
import { ContentExperimentFormData, ContentExperimentResult } from '../../../types';
import { fetchContentExperiment } from '../../../services/creatorToolsService';
import { useApp } from '../../../context/AppContext';
import { Button } from '../../../components/common/Button';
import { Input } from '../../../components/common/Input';
import { Select } from '../../../components/common/Select';
import { Card } from '../../../components/common/Card';
import { Badge } from '../../../components/common/Badge';
import { AdBanner, SmartlinkPromo } from '../../../components/ads';
import {
  FlaskConical,
  ArrowLeft,
  Sparkles,
  Check,
  Copy,
  Bookmark,
  RotateCcw,
  Zap,
  Info,
  BookOpen,
  MessageSquare,
  Flame,
  Layers,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Lightbulb,
  CheckCircle2,
  ArrowRight,
  Compass,
  TrendingUp,
} from 'lucide-react';
import { usePageSEO } from '../../../utils/usePageSEO';

interface ContentExperimentGeneratorPageProps {
  onNavigate: (path: string) => void;
}

export const ContentExperimentGeneratorPage: React.FC<ContentExperimentGeneratorPageProps> = ({
  onNavigate,
}) => {
  usePageSEO({
    title: 'Content Experiment Generator – Test Ideas to Improve Content | ToolFlow',
    description:
      'Generate content testing ideas for creators and create experiments to improve social media content. Formulate structured A/B/C tests for titles and angles.',
    canonicalPath: '/tools/creator/content-experiment-generator',
    robots: 'index, follow',
  });

  const { saveResult, addToast } = useApp();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'How do you create experiments to improve social media content?',
      answer:
        'To create content experiments, take a single validated topic and develop three distinct creative angles: Pattern-Interrupt Curiosity (challenging common assumptions), Actionable Framework (step-by-step tutorial), and Personal Case Study (relatable storytelling). Test them across separate uploads while keeping core subject matter constant.',
    },
    {
      question: 'How long should creators run a content experiment before drawing conclusions?',
      answer:
        'Allow 48 to 72 hours for recommendation algorithms to test your video across initial viewer cohorts. Evaluate completion rates, like-to-view ratios, and shares rather than raw view counts, as initial views can fluctuate based on time of day.',
    },
    {
      question: 'What is the difference between Curiosity, Framework, and Story angles?',
      answer:
        'Curiosity angles lead with a counter-intuitive warning or mistake to provoke immediate intrigue. Framework angles present a structured, repeatable system (e.g. 3-step checklist). Story angles anchor the advice in personal narrative, highlighting relatable struggles and tangible transformations.',
    },
    {
      question: 'Which metrics indicate an experiment variant is the winner?',
      answer:
        'The winning variant is typically determined by Average Percentage Viewed (APV) and Share-to-View ratio. While curiosity hooks might generate higher initial clicks, the winning angle is the one that retains viewers through to the final call to action.',
    },
    {
      question: 'Can you test multiple creative variables at the same time?',
      answer:
        'No. Effective split testing requires changing only one variable at a time (such as the opening hook angle, the pacing, or the thumbnail). Changing the hook, topic, and format simultaneously makes it impossible to identify which factor drove performance changes.',
    },
  ];

  const [formData, setFormData] = useState<ContentExperimentFormData>({
    originalIdea: 'How to organize client feedback without endless revision loops',
    platform: 'YouTube Shorts & TikTok',
    audience: 'Freelance designers and developers',
    contentFormat: 'Short-form Video (45-60s)',
    goal: 'High Shares & Bookmarks',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ContentExperimentResult | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [savedKey, setSavedKey] = useState<string | null>(null);

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!formData.originalIdea.trim()) {
      addToast({
        title: 'Original idea is required',
        message: 'Please describe the core content idea you want to test.',
        type: 'error',
      });
      return;
    }

    setIsLoading(true);
    try {
      const data = await fetchContentExperiment(formData);
      setResult(data);
      addToast({
        title: '3 Content Experiments Ready',
        message: 'Generated curiosity, educational, and narrative testing variations.',
        type: 'success',
      });
    } catch (err: any) {
      addToast({
        title: 'Generation Failed',
        message: err.message || 'Unable to build content experiments.',
        type: 'error',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyExperiment = (key: 'A' | 'B' | 'C') => {
    if (!result) return;
    const exp = key === 'A' ? result.experimentA : key === 'B' ? result.experimentB : result.experimentC;
    const text = `EXPERIMENT ${key}: ${exp.name}
TITLE: ${exp.title}
HOOK: "${exp.hook}"
CONTENT ANGLE: ${exp.contentAngle}
CALL TO ACTION: ${exp.cta}
HYPOTHESIS: ${exp.hypothesis}`;

    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
    addToast({
      title: `Experiment ${key} Copied`,
      message: 'Full experiment script and parameters copied to clipboard.',
      type: 'info',
    });
  };

  const handleSaveExperiment = (key: 'A' | 'B' | 'C') => {
    if (!result) return;
    const exp = key === 'A' ? result.experimentA : key === 'B' ? result.experimentB : result.experimentC;
    saveResult({
      toolId: 'content-experiment-generator',
      toolName: 'Content Experiment Generator',
      category: 'creator',
      title: `Experiment ${key}: ${exp.title}`,
      preview: `"${exp.hook}"`,
      content: `${exp.contentAngle}\n\nCTA: ${exp.cta}\n\nHypothesis: ${exp.hypothesis}`,
      data: {
        experiment: exp,
        originalIdea: formData.originalIdea,
        platform: formData.platform,
      },
    });
    setSavedKey(key);
    setTimeout(() => setSavedKey(null), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Breadcrumb */}
      <div className="mb-6 flex items-center justify-between">
        <a
          href="/tools?category=creator"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools?category=creator');
            }
          }}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Creator Tools
        </a>

        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
          A/B Split-Testing
        </span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-xs">
            <FlaskConical className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Content Experiment Generator
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Transform 1 core idea into 3 distinct, testable narrative formats: Curiosity, Education, and Storytelling.
            </p>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-3 p-3 rounded-lg bg-slate-100/80 border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-600">
          <Info className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong className="font-semibold text-slate-700">Notice on Split-Testing:</strong> These structured experiments provide methodical variations in hook framing, pacing, and calls-to-action. Performance will naturally vary by audience taste, timing, and platform delivery.
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form */}
        <div className="lg:col-span-4">
          <Card className="p-6 bg-white shadow-xs sticky top-20">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-4 flex items-center gap-2">
              <FlaskConical className="h-4 w-4 text-purple-600" />
              Experiment Blueprint
            </h2>

            <form onSubmit={handleGenerate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Core Content Idea or Lesson
                </label>
                <textarea
                  rows={3}
                  className="w-full p-3 rounded-lg border border-slate-300 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white leading-relaxed"
                  placeholder="e.g. How to organize client feedback without endless revision loops..."
                  value={formData.originalIdea}
                  onChange={(e) => setFormData({ ...formData, originalIdea: e.target.value })}
                  required
                />
              </div>

              <Select
                label="Target Platform"
                value={formData.platform}
                onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                options={[
                  { value: 'YouTube Shorts & TikTok', label: 'YouTube Shorts & TikTok' },
                  { value: 'YouTube Long-form', label: 'YouTube Long-form' },
                  { value: 'Instagram Reels', label: 'Instagram Reels' },
                  { value: 'LinkedIn Video & Posts', label: 'LinkedIn' },
                ]}
              />

              <Input
                label="Target Audience"
                placeholder="e.g. Freelancers, agency owners"
                value={formData.audience}
                onChange={(e) => setFormData({ ...formData, audience: e.target.value })}
              />

              <Select
                label="Primary Objective / Goal"
                value={formData.goal}
                onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
                options={[
                  { value: 'High Shares & Bookmarks', label: 'High Shares & Bookmarks (Saves)' },
                  { value: 'Viewer Retention & Watch Time', label: 'Maximum Watch Time & Hold Rate' },
                  { value: 'Comments & Community Debate', label: 'Comments & Community Debate' },
                  { value: 'Subscriber & Follower Conversion', label: 'Follower / Subscriber Conversion' },
                ]}
              />

              <Button
                type="submit"
                variant="primary"
                className="w-full mt-4 font-semibold"
                isLoading={isLoading}
                leftIcon={<FlaskConical className="h-4 w-4" />}
              >
                {isLoading ? 'Generating Experiments...' : 'Build 3 Experiments'}
              </Button>
            </form>
          </Card>
        </div>

        {/* Right Output */}
        <div className="lg:col-span-8 space-y-6">
          {isLoading ? (
            <Card className="p-16 text-center bg-white">
              <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-purple-600 mx-auto mb-4" />
              <p className="text-sm font-semibold text-slate-800">
                Formulating 3 distinct psychological approaches...
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Synthesizing curiosity pattern interrupts, educational frameworks, and vulnerable narratives...
              </p>
            </Card>
          ) : result ? (
            <div className="space-y-6">
              {/* Header Card */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <FlaskConical className="h-4 w-4 text-purple-600" />
                    3 Calibrated Content Experiments
                  </h3>
                  <p className="text-xs text-slate-500">
                    Test these distinct packaging variations across different weeks.
                  </p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerate()}
                  leftIcon={<RotateCcw className="h-3.5 w-3.5" />}
                >
                  Regenerate Variations
                </Button>
              </div>

              {/* Experiments A, B, C */}
              <div className="space-y-6">
                {/* Experiment A: Curiosity */}
                <Card className="p-5 sm:p-6 bg-white border border-indigo-200/80 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100 mb-3">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 inline-block mb-1">
                        Experiment A • Curiosity & Pattern Interrupt
                      </span>
                      <h4 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                        {result.experimentA.title}
                      </h4>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-start">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCopyExperiment('A')}
                        leftIcon={copiedKey === 'A' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                      >
                        {copiedKey === 'A' ? 'Copied' : 'Copy'}
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => handleSaveExperiment('A')}
                        leftIcon={savedKey === 'A' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
                      >
                        {savedKey === 'A' ? 'Saved' : 'Save'}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div className="p-3.5 rounded-lg bg-indigo-50/60 border border-indigo-100 text-indigo-950">
                      <strong className="font-semibold text-indigo-900 block mb-0.5">Opening Hook:</strong>
                      <span className="text-sm font-bold text-indigo-800">"{result.experimentA.hook}"</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-600">
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <strong className="font-semibold text-slate-800 block mb-0.5">Content Angle:</strong>
                        <p className="leading-relaxed">{result.experimentA.contentAngle}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <strong className="font-semibold text-slate-800 block mb-0.5">Call to Action (CTA):</strong>
                        <p className="leading-relaxed">{result.experimentA.cta}</p>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-500 italic pt-1">
                      <strong>Testing Hypothesis:</strong> {result.experimentA.hypothesis}
                    </p>
                  </div>
                </Card>

                {/* Experiment B: Education */}
                <Card className="p-5 sm:p-6 bg-white border border-emerald-200/80 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100 mb-3">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 inline-block mb-1">
                        Experiment B • Educational Blueprint & Checklist
                      </span>
                      <h4 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                        {result.experimentB.title}
                      </h4>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-start">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCopyExperiment('B')}
                        leftIcon={copiedKey === 'B' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                      >
                        {copiedKey === 'B' ? 'Copied' : 'Copy'}
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => handleSaveExperiment('B')}
                        leftIcon={savedKey === 'B' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
                      >
                        {savedKey === 'B' ? 'Saved' : 'Save'}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div className="p-3.5 rounded-lg bg-emerald-50/60 border border-emerald-100 text-emerald-950">
                      <strong className="font-semibold text-emerald-900 block mb-0.5">Opening Hook:</strong>
                      <span className="text-sm font-bold text-emerald-800">"{result.experimentB.hook}"</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-600">
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <strong className="font-semibold text-slate-800 block mb-0.5">Content Angle:</strong>
                        <p className="leading-relaxed">{result.experimentB.contentAngle}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <strong className="font-semibold text-slate-800 block mb-0.5">Call to Action (CTA):</strong>
                        <p className="leading-relaxed">{result.experimentB.cta}</p>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-500 italic pt-1">
                      <strong>Testing Hypothesis:</strong> {result.experimentB.hypothesis}
                    </p>
                  </div>
                </Card>

                {/* Experiment C: Storytelling */}
                <Card className="p-5 sm:p-6 bg-white border border-rose-200/80 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100 mb-3">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200 inline-block mb-1">
                        Experiment C • Storytelling & Vulnerable Proof
                      </span>
                      <h4 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                        {result.experimentC.title}
                      </h4>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-start">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCopyExperiment('C')}
                        leftIcon={copiedKey === 'C' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                      >
                        {copiedKey === 'C' ? 'Copied' : 'Copy'}
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => handleSaveExperiment('C')}
                        leftIcon={savedKey === 'C' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
                      >
                        {savedKey === 'C' ? 'Saved' : 'Save'}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div className="p-3.5 rounded-lg bg-rose-50/60 border border-rose-100 text-rose-950">
                      <strong className="font-semibold text-rose-900 block mb-0.5">Opening Hook:</strong>
                      <span className="text-sm font-bold text-rose-800">"{result.experimentC.hook}"</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-600">
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <strong className="font-semibold text-slate-800 block mb-0.5">Content Angle:</strong>
                        <p className="leading-relaxed">{result.experimentC.contentAngle}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <strong className="font-semibold text-slate-800 block mb-0.5">Call to Action (CTA):</strong>
                        <p className="leading-relaxed">{result.experimentC.cta}</p>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-500 italic pt-1">
                      <strong>Testing Hypothesis:</strong> {result.experimentC.hypothesis}
                    </p>
                  </div>
                </Card>
              </div>

              {/* Testing Guidelines */}
              <Card className="p-5 bg-slate-50 border border-slate-200/80 shadow-xs">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-800 block mb-2">
                  Scientific A/B/C Testing Protocol:
                </span>
                <ul className="space-y-1.5 text-xs text-slate-600">
                  {result.testingGuidelines.map((g, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-purple-600 font-bold">•</span>
                      <span>{g}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              {/* Banner ad */}
              <div className="pt-4 flex justify-center">
                <AdBanner size="728x90" />
              </div>
            </div>
          ) : (
            <Card className="p-12 text-center bg-white border-dashed">
              <div className="h-12 w-12 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mx-auto mb-3">
                <FlaskConical className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No Experiments Generated Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-5">
                Input your content idea on the left to spin up 3 structured A/B/C testing blueprints.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleGenerate()}
                leftIcon={<Sparkles className="h-3.5 w-3.5" />}
              >
                Generate Default Experiments
              </Button>
            </Card>
          )}

          {/* Smartlink promo */}
          <SmartlinkPromo
            variant="card"
            title="Video Editing & Multi-Variant Tools"
            description="Explore software discounts for batch video formatting, auto-resizing, and multi-platform publishing."
          />
        </div>
      </div>

      {/* Comprehensive Editorial & Strategy Guide */}
      <div className="mt-16 space-y-12">
        {/* The 3-Variant Creative Testing Framework */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <Compass className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              The 3-Variant Creative Testing Framework for Social Content
            </h2>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed mb-6">
            Content creators often guess why a video flopped. Testing structured variations of the same core subject matter reveals whether your audience prefers high-stakes curiosity, actionable step-by-step systems, or relatable narrative empathy.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Variant A</span>
                <span className="text-xs px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-semibold">Curiosity Interrupt</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Challenge Conventional Wisdom</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Leads with a contrarian statement or a costly mistake the viewer is making right now. Captures high initial click-through and immediate attention.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Variant B</span>
                <span className="text-xs px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold">Actionable Framework</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Step-by-Step Tactical System</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Breaks the solution into numbered rules, templates, or checklists. Drives exceptionally high bookmark/save ratios from viewers who want to implement it later.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Variant C</span>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">Story / Case Study</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Personal Transformation</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Narrates a personal hurdle, client disaster, or unexpected breakthrough. Fosters high emotional connection, comment debates, and subscriber trust.
              </p>
            </div>
          </div>
        </section>

        {/* Real-World Experiment Scenario */}
        <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <TrendingUp className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">
              Real-World Experiment Testing Scenario
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
            Topic: "How to organize client feedback without endless revision loops."
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-2">
              <span className="text-rose-400 font-bold uppercase tracking-wider block">Variant A (Curiosity)</span>
              <p className="text-white font-medium">"Why taking freelance client feedback over email is costing you $10k/year."</p>
              <p className="text-slate-400">Hypothesis: Curiosity-driven loss aversion will achieve the lowest 3-second swipe rate.</p>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-2">
              <span className="text-indigo-400 font-bold uppercase tracking-wider block">Variant B (Framework)</span>
              <p className="text-white font-medium">"The 3-rule feedback portal framework that stops revision scope creep permanently."</p>
              <p className="text-slate-400">Hypothesis: Structured checklist format will achieve the highest bookmark-to-view ratio.</p>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 space-y-2">
              <span className="text-emerald-400 font-bold uppercase tracking-wider block">Variant C (Story)</span>
              <p className="text-white font-medium">"How I fired my pickiest freelance client, rebuilt my intake portal, and cut revisions by 70%."</p>
              <p className="text-slate-400">Hypothesis: Relatable storytelling will generate the highest comment-to-view discussion ratio.</p>
            </div>
          </div>
        </section>

        {/* Operational Limitations */}
        <section className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-6 sm:p-8 text-amber-950">
          <div className="flex items-center gap-2.5 mb-3">
            <Lightbulb className="h-5 w-5 text-amber-600 shrink-0" />
            <h2 className="text-lg sm:text-xl font-bold text-amber-900">
              Operational Limitations &amp; Testing Methodology
            </h2>
          </div>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90 mb-3">
            <strong>Suggested Hypotheses (No Fabricated Metrics):</strong> The testing angles, hooks, and hypotheses generated are strategic suggestions grounded in cognitive copywriting principles. ToolFlow does not generate fabricated test confidence intervals, p-values, or fake audience sample sizes.
          </p>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90">
            <strong>Isolate One Variable at a Time:</strong> When deploying A/B/C tests, keep your video production quality, audio settings, and general upload time consistent so that variations in viewer retention reflect creative angle differences rather than technical delivery.
          </p>
        </section>

        {/* FAQ Accordion */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-6">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                Frequently Asked Questions
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Answers to common questions about social media A/B testing, hypothesis formulation, and creative variation.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-slate-200/80 overflow-hidden transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(index)}
                    className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-semibold text-slate-900">
                      {item.question}
                    </span>
                    <span className="text-slate-400 shrink-0">
                      {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="p-4 sm:p-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed bg-white border-t border-slate-100">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Related Creator Growth Utilities */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Layers className="h-4 w-4 text-indigo-600" />
            Related Creator Workflow Tools
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a
              href="/tools/creator/hook-doctor"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/hook-doctor');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-rose-600 transition-colors">
                  Hook Doctor
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-rose-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Generate high-retention opening hooks for each of your test variants.
              </p>
            </a>

            <a
              href="/tools/creator/video-performance-doctor"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/video-performance-doctor');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors">
                  Video Performance Doctor
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Audit like-to-view and share ratios to objectively determine experiment winners.
              </p>
            </a>

            <a
              href="/tools/creator/content-gap-finder"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/content-gap-finder');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-emerald-600 transition-colors">
                  Content Gap Finder
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Find underserved competitor voids to feed into your experiment generator.
              </p>
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};
