import React, { useState } from 'react';
import { HashtagMixerFormData, HashtagMixerResult } from '../../../types';
import { fetchHashtagMixer } from '../../../services/creatorToolsService';
import { useApp } from '../../../context/AppContext';
import { Button } from '../../../components/common/Button';
import { Input } from '../../../components/common/Input';
import { Select } from '../../../components/common/Select';
import { Card } from '../../../components/common/Card';
import { Badge } from '../../../components/common/Badge';
import { AdBanner, SmartlinkPromo } from '../../../components/ads';
import {
  Hash,
  ArrowLeft,
  Sparkles,
  Check,
  Copy,
  Bookmark,
  RotateCcw,
  Search,
  Shuffle,
  FileText,
  Info,
  Layers,
  Tag,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Lightbulb,
  CheckCircle2,
  ArrowRight,
  Compass,
} from 'lucide-react';
import { usePageSEO } from '../../../utils/usePageSEO';

interface HashtagKeywordMixerPageProps {
  onNavigate: (path: string) => void;
}

export const HashtagKeywordMixerPage: React.FC<HashtagKeywordMixerPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Hashtag & Keyword Mixer – Combine Tags for Social Media Posts | ToolFlow',
    description:
      'Generate relevant hashtags and keywords for a content niche. Combine hashtags and keywords for social media posts across Instagram, TikTok, and YouTube.',
    canonicalPath: '/tools/creator/hashtag-keyword-mixer',
    robots: 'index, follow',
  });

  const { saveResult, addToast } = useApp();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'How do you generate relevant hashtags and keywords for a content niche?',
      answer:
        'To generate relevant tags, structure your mix into three distinct tiers: broad category tags (defining your umbrella domain), mid-tier niche tags (focused on active subcultures), and hyper-specific long-tail terms (describing the exact tutorial or product featured). Pair these tags with natural language search queries embedded inside your post caption.',
    },
    {
      question: 'Why should creators combine hashtags with caption keywords?',
      answer:
        'Modern recommendation algorithms on TikTok, Instagram, and YouTube utilize advanced Natural Language Processing (NLP) to index post captions alongside hashtags. Incorporating high-intent search terms seamlessly into spoken audio and written sentences ensures your content ranks in search results and algorithm explore feeds.',
    },
    {
      question: 'How does the 3-tier hashtag strategy work?',
      answer:
        'Tier 1 (Broad Tags, 2-3 items) establishes general industry relevance. Tier 2 (Niche Tags, 4-5 items) targets committed enthusiasts and competitive search feeds. Tier 3 (Specific Tags, 3-4 items) directly matches the exact problem solved, ensuring hyper-targeted viewer matching.',
    },
    {
      question: 'How many hashtags should you use on Instagram vs TikTok?',
      answer:
        'On Instagram, 5 to 8 well-targeted hashtags typically perform best without triggering spam filters. On TikTok, 3 to 5 targeted tags (including niche keywords and search phrases) combined with a descriptive caption allow the recommendation engine to categorize your video accurately.',
    },
    {
      question: 'Do hashtags still matter for social media algorithm discovery?',
      answer:
        'Yes, but their role has shifted from pure reach hacks to semantic categorization labels. Algorithms treat hashtags as metadata signals that confirm the contextual topic of the video, reinforcing what the computer vision and automated transcript analysis have already detected.',
    },
  ];

  const [formData, setFormData] = useState<HashtagMixerFormData>({
    platform: 'Instagram',
    topic: 'Remote Freelance UI/UX Design Workflow',
    niche: 'Freelancing & Design',
    targetCountry: 'United States',
    targetLanguage: 'English',
    audience: 'Junior & mid-level product designers',
    contentType: 'Carousel Tutorial / Reel',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<HashtagMixerResult | null>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const handleMix = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!formData.topic.trim() || !formData.niche.trim()) {
      addToast({
        title: 'Missing Required Inputs',
        message: 'Please provide both your topic and niche.',
        type: 'error',
      });
      return;
    }

    setIsLoading(true);
    try {
      const data = await fetchHashtagMixer(formData);
      setResult(data);
      addToast({
        title: 'Hashtags & Keywords Mixed',
        message: 'Generated multi-tier hashtags, search queries, and in-caption SEO terms.',
        type: 'success',
      });
    } catch (err: any) {
      addToast({
        title: 'Mixing Failed',
        message: err.message || 'Unable to generate tags and keywords.',
        type: 'error',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(label);
    setTimeout(() => setCopiedSection(null), 2000);
    addToast({
      title: 'Copied',
      message: `${label} copied to clipboard.`,
      type: 'info',
    });
  };

  const handleSaveResult = () => {
    if (!result) return;
    saveResult({
      toolId: 'hashtag-keyword-mixer',
      toolName: 'Smart Hashtag & Keyword Mixer',
      category: 'creator',
      title: `Tags: ${formData.topic}`,
      preview: result.suggestedCombinations[0]?.readyText || result.broadHashtags.join(' '),
      content: `BROAD:\n${result.broadHashtags.join(' ')}\n\nNICHE:\n${result.nicheHashtags.join(' ')}\n\nSPECIFIC:\n${result.specificHashtags.join(' ')}\n\nSEARCH TERMS:\n${result.searchKeywords.join('\n')}`,
      data: {
        formData,
        result,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Breadcrumb */}
      <div className="mb-6 flex items-center justify-between">
        <a
          href="/tools?category=creator"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools?category=creator');
            }
          }}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Creator Tools
        </a>

        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
          SEO & Discoverability
        </span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-xs">
            <Hash className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Smart Hashtag & Keyword Mixer
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Generate structured multi-tier hashtags, search query intent, and natural in-caption SEO terms instead of random tags.
            </p>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-3 p-3 rounded-lg bg-slate-100/80 border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-600">
          <Info className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong className="font-semibold text-slate-700">Notice on Metrics:</strong> These hashtag groupings and search keywords are contextual recommendations based on semantic relevance and audience queries. Exact search volumes or competition scores are not implied without direct platform API connections.
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form */}
        <div className="lg:col-span-4">
          <Card className="p-6 bg-white shadow-xs sticky top-20">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-4 flex items-center gap-2">
              <Shuffle className="h-4 w-4 text-amber-600" />
              Content Parameters
            </h2>

            <form onSubmit={handleMix} className="space-y-4">
              <Select
                label="Target Platform"
                value={formData.platform}
                onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                options={[
                  { value: 'Instagram', label: 'Instagram (Reels & Feed)' },
                  { value: 'TikTok', label: 'TikTok' },
                  { value: 'YouTube', label: 'YouTube (Shorts & Long-form)' },
                  { value: 'LinkedIn', label: 'LinkedIn' },
                  { value: 'X / Twitter', label: 'X / Twitter' },
                ]}
              />

              <Input
                label="Content Topic"
                placeholder="e.g. Figma auto-layout tips for beginners"
                value={formData.topic}
                onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                required
              />

              <Input
                label="Niche or Industry"
                placeholder="e.g. UI/UX Design, Tech"
                value={formData.niche}
                onChange={(e) => setFormData({ ...formData, niche: e.target.value })}
                required
              />

              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Target Country"
                  placeholder="e.g. United States"
                  value={formData.targetCountry}
                  onChange={(e) => setFormData({ ...formData, targetCountry: e.target.value })}
                />
                <Input
                  label="Target Language"
                  placeholder="e.g. English"
                  value={formData.targetLanguage}
                  onChange={(e) => setFormData({ ...formData, targetLanguage: e.target.value })}
                />
              </div>

              <Input
                label="Target Audience"
                placeholder="e.g. Junior freelancers, agency designers"
                value={formData.audience}
                onChange={(e) => setFormData({ ...formData, audience: e.target.value })}
              />

              <Select
                label="Content Type"
                value={formData.contentType}
                onChange={(e) => setFormData({ ...formData, contentType: e.target.value })}
                options={[
                  { value: 'Tutorial / How-To', label: 'Tutorial / How-To' },
                  { value: 'Case Study / Breakdown', label: 'Case Study / Breakdown' },
                  { value: 'Opinion / Commentary', label: 'Opinion / Commentary' },
                  { value: 'Tool Review / Comparison', label: 'Tool Review / Comparison' },
                  { value: 'Entertainment / Skit', label: 'Entertainment / Skit' },
                ]}
              />

              <Button
                type="submit"
                variant="primary"
                className="w-full mt-4 font-semibold"
                isLoading={isLoading}
                leftIcon={<Hash className="h-4 w-4" />}
              >
                {isLoading ? 'Mixing Tags & Keywords...' : 'Mix Hashtags & Keywords'}
              </Button>
            </form>
          </Card>
        </div>

        {/* Right Output */}
        <div className="lg:col-span-8 space-y-6">
          {isLoading ? (
            <Card className="p-16 text-center bg-white">
              <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-amber-600 mx-auto mb-4" />
              <p className="text-sm font-semibold text-slate-800">
                Generating multi-tier hashtag cocktails and SEO keywords...
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Categorizing broad reach, niche community, and specific topic clusters...
              </p>
            </Card>
          ) : result ? (
            <div className="space-y-6">
              {/* Ready-to-Paste Bundles */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Shuffle className="h-4 w-4 text-amber-600" />
                    Recommended Copy-Paste Combinations
                  </h3>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={handleSaveResult}
                    leftIcon={saved ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
                  >
                    {saved ? 'Saved' : 'Save Entire Mix'}
                  </Button>
                </div>

                <div className="space-y-3">
                  {result.suggestedCombinations.map((combo, idx) => (
                    <Card key={idx} className="p-4 sm:p-5 bg-white border border-slate-200 shadow-xs">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100 mb-2">
                        <div>
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                            {combo.title}
                          </h4>
                          <p className="text-[11px] text-slate-500">{combo.description}</p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyText(combo.readyText, `combo_${idx}`)}
                          leftIcon={copiedSection === `combo_${idx}` ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                        >
                          {copiedSection === `combo_${idx}` ? 'Copied' : 'Copy Bundle'}
                        </Button>
                      </div>

                      <p className="p-3 rounded-lg bg-slate-50 border border-slate-100 font-mono text-xs text-slate-800 leading-relaxed break-words select-all">
                        {combo.readyText}
                      </p>
                    </Card>
                  ))}
                </div>
              </div>

              {/* 3-Tier Categorized Hashtags */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Broad */}
                <Card className="p-4 bg-white border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full">
                      Broad Discovery (High Reach)
                    </span>
                    <button
                      onClick={() => copyText(result.broadHashtags.join(' '), 'broad')}
                      className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                      title="Copy Broad Tags"
                    >
                      {copiedSection === 'broad' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {result.broadHashtags.map((tag, i) => (
                      <span key={i} className="text-xs font-mono text-indigo-600 bg-indigo-50/50 px-2 py-0.5 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                </Card>

                {/* Niche */}
                <Card className="p-4 bg-white border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
                      Niche Community (Targeted)
                    </span>
                    <button
                      onClick={() => copyText(result.nicheHashtags.join(' '), 'niche')}
                      className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                      title="Copy Niche Tags"
                    >
                      {copiedSection === 'niche' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {result.nicheHashtags.map((tag, i) => (
                      <span key={i} className="text-xs font-mono text-amber-700 bg-amber-50/50 px-2 py-0.5 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                </Card>

                {/* Specific */}
                <Card className="p-4 bg-white border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                      Specific Sub-Topic (Exact)
                    </span>
                    <button
                      onClick={() => copyText(result.specificHashtags.join(' '), 'specific')}
                      className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                      title="Copy Specific Tags"
                    >
                      {copiedSection === 'specific' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {result.specificHashtags.map((tag, i) => (
                      <span key={i} className="text-xs font-mono text-emerald-700 bg-emerald-50/50 px-2 py-0.5 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                </Card>
              </div>

              {/* Search Keywords & In-Caption SEO Keywords */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Search Queries */}
                <Card className="p-5 bg-white border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                      <Search className="h-3.5 w-3.5 text-indigo-600" /> Search Bar Query Intent
                    </h4>
                    <button
                      onClick={() => copyText(result.searchKeywords.join('\n'), 'search')}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 cursor-pointer flex items-center gap-1"
                    >
                      {copiedSection === 'search' ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                      <span>Copy All</span>
                    </button>
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-700">
                    {result.searchKeywords.map((kw, i) => (
                      <li key={i} className="flex items-center gap-2 p-1.5 rounded bg-slate-50 border border-slate-100 font-mono text-[11px]">
                        <Search className="h-3 w-3 text-slate-400" />
                        <span>{kw}</span>
                      </li>
                    ))}
                  </ul>
                </Card>

                {/* In-Caption Semantic SEO Words */}
                <Card className="p-5 bg-white border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                      <FileText className="h-3.5 w-3.5 text-emerald-600" /> Caption SEO Keywords
                    </h4>
                    <span className="text-[10px] text-slate-400">Natural index terms</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mb-2.5">
                    Weave these exact terms into your caption sentences to trigger platform search indexing:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {result.captionKeywords.map((w, i) => (
                      <span key={i} className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-800 text-xs font-medium">
                        {w}
                      </span>
                    ))}
                  </div>

                  {result.longTailKeywords?.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                        Long-Tail Phrasing Ideas:
                      </span>
                      <ul className="space-y-1 text-[11px] text-slate-600 italic">
                        {result.longTailKeywords.map((lt, i) => (
                          <li key={i}>• "{lt}"</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </Card>
              </div>

              {/* Banner ad */}
              <div className="pt-4 flex justify-center">
                <AdBanner size="728x90" />
              </div>
            </div>
          ) : (
            <Card className="p-12 text-center bg-white border-dashed">
              <div className="h-12 w-12 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3">
                <Hash className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No Keywords Mixed Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-5">
                Input your content topic on the left to generate structured hashtags, search intent queries, and in-caption terms.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleMix()}
                leftIcon={<Sparkles className="h-3.5 w-3.5" />}
              >
                Mix Default Sample Tags
              </Button>
            </Card>
          )}

          {/* Smartlink promo */}
          <SmartlinkPromo
            variant="card"
            title="SEO & Keyword Research Software Deals"
            description="Access verified partner discounts on multi-platform social media schedulers and SEO toolkits."
          />
        </div>
      </div>

      {/* Comprehensive Editorial & Strategy Guide */}
      <div className="mt-16 space-y-12">
        {/* The 3-Tier Hashtag Optimization Strategy */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
              <Compass className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              The 3-Tier Hashtag &amp; Search Keyword Optimization Strategy
            </h2>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed mb-6">
            Relying solely on viral mega-tags (like #fyp or #viral) yields zero ranking benefit because millions of posts drown them out per hour. Instead, balance your tags across three structured volume tiers.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Tier 1</span>
                <span className="text-xs px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold">2 - 3 Tags</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Broad Umbrella Tags</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                High-volume industry tags (e.g. #freelance, #design) that signal your overall topic silo to recommendation algorithms.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Tier 2</span>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">4 - 5 Tags</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Niche Sub-Topic Tags</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Focused community tags (e.g. #uidesignworkflow, #figmatips) where active users browse and where you can rank on top hashtag feeds.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Tier 3</span>
                <span className="text-xs px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold">3 - 4 Tags</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Hyper-Specific Long-Tail</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Exact problem/solution tags matching the precise deliverable in your video (e.g. #figmaclientsystem, #freelanceinvoicetemplate).
              </p>
            </div>
          </div>
        </section>

        {/* Real-World Worked Case Study */}
        <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
              <Shuffle className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">
              Real-World Case Study: Remote UI/UX Freelance Workflow
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
            See how combining structured hashtags with in-caption NLP keywords optimizes discovery across Instagram Reels and TikTok search.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm">
            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <h4 className="font-bold text-amber-400 uppercase tracking-wider text-xs">Balanced Hashtag Bundle</h4>
              <div>
                <span className="text-slate-400 block text-xs">Tier 1 Broad:</span>
                <span className="text-white font-mono text-xs">#productdesign #freelancing</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Tier 2 Niche:</span>
                <span className="text-white font-mono text-xs">#figmatips #uidesignsystems #freelancedesigner</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Tier 3 Long-Tail:</span>
                <span className="text-white font-mono text-xs">#figmafeedbacksystem #designclientportal</span>
              </div>
            </div>

            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <h4 className="font-bold text-indigo-400 uppercase tracking-wider text-xs">In-Caption Natural Search Integration</h4>
              <div>
                <span className="text-slate-400 block text-xs">Integrated Search Phrases:</span>
                <p className="text-slate-300 text-xs">"freelance Figma design system setup", "client feedback portal tutorial", "how to organize UI design files"</p>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Resulting Discoverability:</span>
                <p className="text-emerald-400 text-xs font-semibold">Video ranks for users actively searching "how to organize Figma client feedback" rather than just passive algorithmic feed views.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Operational Limitations */}
        <section className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-6 sm:p-8 text-amber-950">
          <div className="flex items-center gap-2.5 mb-3">
            <Lightbulb className="h-5 w-5 text-amber-600 shrink-0" />
            <h2 className="text-lg sm:text-xl font-bold text-amber-900">
              Operational Limitations &amp; Notice on Suggested Tags
            </h2>
          </div>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90 mb-3">
            <strong>Suggested Keywords (No Fabricated Search Volumes):</strong> The hashtags, tiers, and search query recommendations generated by this mixer represent qualitative topical grouping and algorithmic indexing best practices. ToolFlow does not fabricate unverified keyword volumes, difficulty scores, or traffic forecasts.
          </p>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90">
            <strong>Avoid Tag Stuffing:</strong> Adding 30 unrelated hashtags will dilute semantic clarity and can trigger spam filtering. Stick to 5 to 8 focused, highly relevant tags per post.
          </p>
        </section>

        {/* FAQ Accordion */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-6">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                Frequently Asked Questions
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Answers to common questions about social media hashtags, search keywords, and algorithm categorization.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-slate-200/80 overflow-hidden transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(index)}
                    className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-semibold text-slate-900">
                      {item.question}
                    </span>
                    <span className="text-slate-400 shrink-0">
                      {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="p-4 sm:p-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed bg-white border-t border-slate-100">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Related Creator Growth Utilities */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Layers className="h-4 w-4 text-amber-600" />
            Related Creator Workflow Tools
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a
              href="/tools/social-caption-generator"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/social-caption-generator');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-rose-600 transition-colors">
                  Social Caption Generator
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-rose-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Generate high-converting post copy using the Hook-Value-CTA framework.
              </p>
            </a>

            <a
              href="/tools/creator/trend-radar"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/trend-radar');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors">
                  Trend Radar
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Scan emerging niche keywords and topic momentum before competition saturates.
              </p>
            </a>

            <a
              href="/tools/amazon-keyword-generator"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/amazon-keyword-generator');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-emerald-600 transition-colors">
                  Amazon Keyword Generator
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Discover high-converting e-commerce search keywords for listings and PPC.
              </p>
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};
