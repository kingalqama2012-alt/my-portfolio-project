import React, { useState } from 'react';
import { HookDoctorFormData, HookDoctorResult } from '../../../types';
import { fetchHookDoctor } from '../../../services/creatorToolsService';
import { useApp } from '../../../context/AppContext';
import { Button } from '../../../components/common/Button';
import { Input } from '../../../components/common/Input';
import { Select } from '../../../components/common/Select';
import { Card } from '../../../components/common/Card';
import { Badge } from '../../../components/common/Badge';
import { AdBanner, SmartlinkPromo } from '../../../components/ads';
import {
  Stethoscope,
  ArrowLeft,
  Sparkles,
  Check,
  Copy,
  Bookmark,
  RotateCcw,
  AlertCircle,
  Eye,
  Zap,
  Info,
  Play,
  Volume2,
  FileText,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Lightbulb,
  CheckCircle2,
  ArrowRight,
  Layers,
  Compass,
} from 'lucide-react';
import { usePageSEO } from '../../../utils/usePageSEO';

interface HookDoctorPageProps {
  onNavigate: (path: string) => void;
}

export const HookDoctorPage: React.FC<HookDoctorPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Hook Doctor – Improve the Hook for a Short-Form Video | ToolFlow',
    description:
      'Improve the hook for a short-form video with Hook Doctor. Generate stronger opening hooks for social media videos on TikTok, Instagram Reels, and YouTube Shorts.',
    canonicalPath: '/tools/creator/hook-doctor',
    robots: 'index, follow',
  });

  const { saveResult, addToast } = useApp();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'How do you improve the hook for a short-form video?',
      answer:
        'To improve the hook for a short-form video, immediately cut conversational throat-clearing (like "Hey guys, so today..."). Replace it with an opening frame pattern interrupt (movement, prop, or contrasting visual), a high-stakes spoken challenge or question, and a bold on-screen text banner that viewers can read in under 1.5 seconds.',
    },
    {
      question: 'Why are the first 3 seconds critical on TikTok and Shorts?',
      answer:
        'Recommendation algorithms on TikTok, Instagram Reels, and YouTube Shorts track 3-second view rates and swipe-away percentages. If more than 60% of viewers swipe away during the first 3 seconds, the algorithm concludes the content is unappealing and halts distribution to broader audiences.',
    },
    {
      question: 'What are the 3 essential components of an effective video hook?',
      answer:
        'The 3 essential components are: (1) Visual Action (movement or visual oddity in frame 1), (2) Spoken Audio Hook (a provocative statement or unexpected question), and (3) Synchronized Text Hook (concise caption confirming what the viewer will gain by continuing to watch).',
    },
    {
      question: 'How do visual pattern interrupts work in opening frames?',
      answer:
        'Pattern interrupts disrupt the viewer\'s passive scrolling trance. Examples include walking toward the camera, holding an intriguing physical object close to the lens, displaying an unexpected screen recording graph, or changing camera angles rapidly within the first 2 seconds.',
    },
    {
      question: 'Can a great hook save a weak video script?',
      answer:
        'A great hook will capture initial attention and reduce the opening 3-second swipe rate, but it cannot fix mid-video drop-offs if the body script fails to deliver on the hook\'s promise. Creators must ensure the core content delivers the payoff quickly without unnecessary filler.',
    },
  ];

  const [formData, setFormData] = useState<HookDoctorFormData>({
    platform: 'YouTube Shorts',
    videoTopic: 'Why most people fail at saving money in their 20s',
    currentHook: 'Hey everyone, today in this video I want to talk about how you can save money in your twenties.',
    videoFormat: 'Short-form (Reels/TikTok/Shorts)',
    targetAudience: 'Young adults 18-28 trying to build wealth',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<HookDoctorResult | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [savedIndex, setSavedIndex] = useState<number | null>(null);

  const handleDiagnose = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!formData.videoTopic.trim()) {
      addToast({
        title: 'Video topic is required',
        message: 'Please provide the topic of your video.',
        type: 'error',
      });
      return;
    }

    setIsLoading(true);
    try {
      const data = await fetchHookDoctor(formData);
      setResult(data);
      addToast({
        title: 'Hook Diagnosis Complete',
        message: 'Generated 5 calibrated opening hooks and 3-second visual cues.',
        type: 'success',
      });
    } catch (err: any) {
      addToast({
        title: 'Diagnosis Failed',
        message: err.message || 'Unable to diagnose hook at this time.',
        type: 'error',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyHook = (index: number) => {
    if (!result) return;
    const item = result.improvedHooks[index];
    const text = `HOOK TYPE: ${item.type}\n\nHOOK:\n"${item.hookText}"\n\nWHY IT WORKS:\n${item.whyItWorks}\n\nPACING:\n${item.suggestedPacing || 'Normal'}`;

    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    addToast({
      title: 'Hook Copied',
      message: 'Hook text copied to clipboard.',
      type: 'info',
    });
  };

  const handleSaveHook = (index: number) => {
    if (!result) return;
    const item = result.improvedHooks[index];
    saveResult({
      toolId: 'hook-doctor',
      toolName: 'Hook Doctor',
      category: 'creator',
      title: `Hook: ${item.type}`,
      preview: `"${item.hookText}"`,
      content: `${item.whyItWorks}\n\n3-Second Visual Cue: ${result.firstThreeSecondsCue.visualAction}`,
      data: {
        hook: item,
        firstThreeSecondsCue: result.firstThreeSecondsCue,
      },
    });
    setSavedIndex(index);
    setTimeout(() => setSavedIndex(null), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Breadcrumb */}
      <div className="mb-6 flex items-center justify-between">
        <a
          href="/tools?category=creator"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools?category=creator');
            }
          }}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Creator Tools
        </a>

        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200">
          Retention Optimization
        </span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center text-white shadow-xs">
            <Stethoscope className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Hook Doctor
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Audit opening retention drop-offs, eliminate filler intros, and craft 5 high-converting opening hooks.
            </p>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-3 p-3 rounded-lg bg-slate-100/80 border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-600">
          <Info className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong className="font-semibold text-slate-700">Notice on Retention:</strong> These hook suggestions are crafted based on storytelling principles, pacing psychology, and platform best practices. Viewer behavior depends on multiple variables; no tool can guarantee exact retention rates or view counts.
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form */}
        <div className="lg:col-span-4">
          <Card className="p-6 bg-white shadow-xs sticky top-20">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-4 flex items-center gap-2">
              <Stethoscope className="h-4 w-4 text-rose-600" />
              Patient (Current Hook)
            </h2>

            <form onSubmit={handleDiagnose} className="space-y-4">
              <Select
                label="Target Platform"
                value={formData.platform || 'YouTube Shorts'}
                onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                options={[
                  { value: 'YouTube Shorts', label: 'YouTube Shorts' },
                  { value: 'TikTok', label: 'TikTok' },
                  { value: 'Instagram Reels', label: 'Instagram Reels' },
                  { value: 'YouTube Long-form', label: 'YouTube Long-form' },
                  { value: 'LinkedIn Video', label: 'LinkedIn Video' },
                ]}
              />

              <Input
                label="Video Topic"
                placeholder="e.g. How to get your first freelance client"
                value={formData.videoTopic}
                onChange={(e) => setFormData({ ...formData, videoTopic: e.target.value })}
                required
              />

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Current Hook or Draft First Sentence
                </label>
                <textarea
                  rows={4}
                  className="w-full p-3 rounded-lg border border-slate-300 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-500 bg-white leading-relaxed"
                  placeholder="Paste the first 1-2 sentences of your script or video recording..."
                  value={formData.currentHook}
                  onChange={(e) => setFormData({ ...formData, currentHook: e.target.value })}
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Include any intro greeting, filler phrases, or teaser words.
                </span>
              </div>

              <Select
                label="Video Format"
                value={formData.videoFormat}
                onChange={(e) => setFormData({ ...formData, videoFormat: e.target.value })}
                options={[
                  { value: 'Short-form (Reels/TikTok/Shorts)', label: 'Short-form (Reels / TikTok / Shorts)' },
                  { value: 'Long-form YouTube (8-20 min)', label: 'Long-form YouTube (8-20 min)' },
                  { value: 'Talking Head & Commentary', label: 'Talking Head & Commentary' },
                  { value: 'Tutorial & Screencast', label: 'Tutorial & Screencast' },
                  { value: 'Story & Vlog', label: 'Story & Vlog' },
                ]}
              />

              <Input
                label="Target Audience"
                placeholder="e.g. Beginners, creators, developers"
                value={formData.targetAudience}
                onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value })}
              />

              <Button
                type="submit"
                variant="primary"
                className="w-full mt-4 font-semibold"
                isLoading={isLoading}
                leftIcon={<Zap className="h-4 w-4" />}
              >
                {isLoading ? 'Diagnosing Opening...' : 'Diagnose & Improve Hook'}
              </Button>
            </form>
          </Card>
        </div>

        {/* Right Output */}
        <div className="lg:col-span-8 space-y-6">
          {isLoading ? (
            <Card className="p-16 text-center bg-white">
              <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-rose-600 mx-auto mb-4" />
              <p className="text-sm font-semibold text-slate-800">
                Diagnosing hook friction points and listener psychology...
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Calibrating curiosity, educational stakes, and visual pattern interrupts...
              </p>
            </Card>
          ) : result ? (
            <div className="space-y-6">
              {/* Diagnosis Box: Strengths & Weaknesses */}
              <Card className="p-5 sm:p-6 bg-white border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-amber-600" />
                    Hook Clinical Diagnosis
                  </h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDiagnose()}
                    leftIcon={<RotateCcw className="h-3.5 w-3.5" />}
                  >
                    Re-Diagnose
                  </Button>
                </div>

                <div className="space-y-3 text-xs leading-relaxed">
                  <div className="p-3 rounded-lg bg-emerald-50/60 border border-emerald-100 text-emerald-950">
                    <strong className="text-emerald-900 font-semibold block mb-0.5">Topic Resonance:</strong>
                    {result.analysis.strengths}
                  </div>

                  <div className="p-3 rounded-lg bg-rose-50/60 border border-rose-100 text-rose-950">
                    <strong className="text-rose-900 font-semibold block mb-0.5">Identified Friction / Weakness:</strong>
                    {result.analysis.weaknesses}
                  </div>

                  {result.analysis.retentionRiskFactors?.length > 0 && (
                    <div className="pt-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-1.5">
                        Specific Drop-off Hazards Detected:
                      </span>
                      <ul className="space-y-1 text-slate-600">
                        {result.analysis.retentionRiskFactors.map((factor, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-rose-500 font-bold">•</span>
                            <span>{factor}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </Card>

              {/* The "First 3 Seconds" Execution Blueprint */}
              <Card className="p-5 sm:p-6 bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-xl shadow-xs">
                <div className="flex items-center gap-2 mb-3">
                  <Eye className="h-4 w-4 text-rose-400" />
                  <h3 className="text-sm font-bold tracking-tight uppercase tracking-wider text-rose-300">
                    Recommended First 3 Seconds Protocol
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 rounded-lg bg-white/10 backdrop-blur-xs border border-white/10">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300 block mb-1 flex items-center gap-1.5">
                      <Play className="h-3 w-3 text-amber-400" /> Visual Cue (Action)
                    </span>
                    <p className="text-slate-100 leading-snug">{result.firstThreeSecondsCue.visualAction}</p>
                  </div>

                  <div className="p-3 rounded-lg bg-white/10 backdrop-blur-xs border border-white/10">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300 block mb-1 flex items-center gap-1.5">
                      <Volume2 className="h-3 w-3 text-emerald-400" /> Audio Cue (Delivery)
                    </span>
                    <p className="text-slate-100 leading-snug">{result.firstThreeSecondsCue.audioSpokenCue}</p>
                  </div>

                  <div className="p-3 rounded-lg bg-white/10 backdrop-blur-xs border border-white/10">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300 block mb-1 flex items-center gap-1.5">
                      <FileText className="h-3 w-3 text-indigo-400" /> Text On Screen
                    </span>
                    <p className="text-slate-100 font-bold leading-snug">{result.firstThreeSecondsCue.textOnScreen}</p>
                  </div>
                </div>
              </Card>

              {/* 5 Improved Hooks */}
              <div className="space-y-4">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-rose-600" />
                  5 Calibrated Hook Prescriptions
                </h3>

                {result.improvedHooks.map((hookItem, idx) => (
                  <Card key={idx} className="p-5 sm:p-6 bg-white border border-slate-200/90 shadow-xs hover:border-slate-300 transition-colors">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100">
                      <div>
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-800 border border-slate-200 inline-block mb-1.5">
                          {hookItem.type}
                        </span>
                        <p className="text-base sm:text-lg font-bold text-slate-900 tracking-tight leading-snug">
                          "{hookItem.hookText}"
                        </p>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-start">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCopyHook(idx)}
                          leftIcon={copiedIndex === idx ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                        >
                          {copiedIndex === idx ? 'Copied' : 'Copy'}
                        </Button>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => handleSaveHook(idx)}
                          leftIcon={savedIndex === idx ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
                        >
                          {savedIndex === idx ? 'Saved' : 'Save'}
                        </Button>
                      </div>
                    </div>

                    <div className="pt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-600">
                      <div>
                        <strong className="text-slate-800 font-semibold block mb-0.5">Why This Works:</strong>
                        <p className="leading-relaxed">{hookItem.whyItWorks}</p>
                      </div>
                      {hookItem.suggestedPacing && (
                        <div>
                          <strong className="text-slate-800 font-semibold block mb-0.5">Recommended Vocal Pacing:</strong>
                          <p className="leading-relaxed font-mono text-[11px] text-slate-700">{hookItem.suggestedPacing}</p>
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
              </div>

              {/* Banner ad */}
              <div className="pt-4 flex justify-center">
                <AdBanner size="728x90" />
              </div>
            </div>
          ) : (
            <Card className="p-12 text-center bg-white border-dashed">
              <div className="h-12 w-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3">
                <Stethoscope className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No Hook Prescriptions Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-5">
                Paste your opening sentence on the left to audit retention leaks and generate 5 psychological variations.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleDiagnose()}
                leftIcon={<Sparkles className="h-3.5 w-3.5" />}
              >
                Diagnose Sample Hook
              </Button>
            </Card>
          )}

          {/* Smartlink promo */}
          <SmartlinkPromo
            variant="card"
            title="Teleprompter & Script Writing Software"
            description="Explore software deals for automated subtitle generation and visual pattern interrupts."
          />
        </div>
      </div>

      {/* Comprehensive Editorial & Strategy Guide */}
      <div className="mt-16 space-y-12">
        {/* Step-by-Step Methodology: 3-Part Hook Triad */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <Compass className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              The 3-Part Hook Triad for Short-Form Video Retention
            </h2>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed mb-6">
            To stop users from swiping in the first 2.5 seconds, top creators synchronize three distinct psychological triggers simultaneously.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-rose-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                1
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Visual Action Trigger</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Start with immediate physical motion: an object moving toward the lens, cutting a piece of paper, walking toward camera, or dynamic screen capture zoom. Never start on a frozen face.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-indigo-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                2
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Spoken Audio Challenge</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Speak a provocative question or controversial reality without pause. Eliminate introductory greeting fillers ("Hey everyone") so the spoken hook begins at millisecond 0.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-emerald-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                3
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">On-Screen Text Hook</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Over 60% of vertical viewers watch without sound initially. Display high-contrast text that restates the core curiosity gap in 6 words or less, readable in under 1.5 seconds.
              </p>
            </div>
          </div>
        </section>

        {/* Real-World Before & After Case Study */}
        <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-rose-500/20 text-rose-400">
              <Zap className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">
              Before &amp; After Optimization Case Study
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
            See how transforming a slow conversational intro into a pattern interrupt drastically boosts watch completion.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm">
            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-rose-400 uppercase tracking-wider text-xs">Weak Original Hook (High Swipe Rate)</h4>
                <span className="text-[11px] px-2 py-0.5 rounded bg-rose-950 text-rose-400 border border-rose-800">Swipe-away: 68%</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Opening Script:</span>
                <p className="text-slate-300 italic mt-1">"Hey guys! Today I wanted to share a few tips on how you can organize client feedback without wasting time back and forth."</p>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Why It Fails:</span>
                <p className="text-slate-400 text-xs">Takes 6 seconds before reaching any value; no visual change; conversational tone signals low urgency to scrolling viewers.</p>
              </div>
            </div>

            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-emerald-400 uppercase tracking-wider text-xs">Hook Doctor Optimized (High Retention)</h4>
                <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">Swipe-away: 24%</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Opening Script &amp; Visual:</span>
                <p className="text-white font-medium mt-1">"If you're still taking client feedback over email, you're losing 10 hours a week. Here is the 1-link portal top design agencies use instead."</p>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Visual Action &amp; Text:</span>
                <p className="text-emerald-400 text-xs font-semibold">Screen recording shows cursor dragging 50 messy email threads into trash. Banner: "Stop Email Revision Loops".</p>
              </div>
            </div>
          </div>
        </section>

        {/* Operational Limitations */}
        <section className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-6 sm:p-8 text-amber-950">
          <div className="flex items-center gap-2.5 mb-3">
            <Lightbulb className="h-5 w-5 text-amber-600 shrink-0" />
            <h2 className="text-lg sm:text-xl font-bold text-amber-900">
              Operational Limitations &amp; Retention Advice
            </h2>
          </div>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90 mb-3">
            <strong>Avoid Misleading Clickbait:</strong> While aggressive curiosity hooks stop thumb-scrolling, your video body must fulfill the opening premise immediately. If viewers discover the hook was an exaggeration, retention plunges at second 8, signaling clickbait to the algorithm.
          </p>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90">
            <strong>Hook Variations as Suggestions:</strong> Generated hook prescriptions and timing cues are AI-assisted creative suggestions. Test multiple variations to find the tone that aligns best with your creator persona.
          </p>
        </section>

        {/* FAQ Accordion */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-6">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                Frequently Asked Questions
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Answers to common questions about short-form video hooks, visual pattern interrupts, and viewer retention.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-slate-200/80 overflow-hidden transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(index)}
                    className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-semibold text-slate-900">
                      {item.question}
                    </span>
                    <span className="text-slate-400 shrink-0">
                      {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="p-4 sm:p-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed bg-white border-t border-slate-100">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Related Creator Growth Utilities */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Layers className="h-4 w-4 text-rose-600" />
            Related Creator Workflow Tools
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a
              href="/tools/creator/video-performance-doctor"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/video-performance-doctor');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-rose-600 transition-colors">
                  Video Performance Doctor
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-rose-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Audit like-to-view, comment, and share ratios to diagnose drop-offs.
              </p>
            </a>

            <a
              href="/tools/creator/content-experiment-generator"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/content-experiment-generator');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors">
                  Content Experiment Generator
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Turn your hook into 3 structured A/B/C testing variations.
              </p>
            </a>

            <a
              href="/tools/social-caption-generator"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/social-caption-generator');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-emerald-600 transition-colors">
                  Social Caption Generator
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Pair your video hook with high-converting social media captions.
              </p>
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};
