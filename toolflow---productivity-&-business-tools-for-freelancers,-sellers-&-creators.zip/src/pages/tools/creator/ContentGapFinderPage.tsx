import React, { useState } from 'react';
import { ContentGapFormData, ContentGapResult } from '../../../types';
import { fetchContentGap } from '../../../services/creatorToolsService';
import { useApp } from '../../../context/AppContext';
import { Button } from '../../../components/common/Button';
import { Input } from '../../../components/common/Input';
import { Select } from '../../../components/common/Select';
import { Card } from '../../../components/common/Card';
import { Badge } from '../../../components/common/Badge';
import { AdBanner, SmartlinkPromo } from '../../../components/ads';
import {
  Target,
  ArrowLeft,
  Sparkles,
  Check,
  Copy,
  Bookmark,
  RotateCcw,
  Info,
  HelpCircle,
  Lightbulb,
  CheckCircle2,
  TrendingUp,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  Layers,
  Compass,
  FileText,
} from 'lucide-react';
import { usePageSEO } from '../../../utils/usePageSEO';

interface ContentGapFinderPageProps {
  onNavigate: (path: string) => void;
}

export const ContentGapFinderPage: React.FC<ContentGapFinderPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Content Gap Finder – Find Missing Topics in a Content Strategy | ToolFlow',
    description:
      'Find missing topics in a content strategy with our free content gap analysis tool for creators. Uncover underserved niche questions and competitor content voids.',
    canonicalPath: '/tools/creator/content-gap-finder',
    robots: 'index, follow',
  });

  const { saveResult, addToast } = useApp();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'What is a content gap in a video content strategy?',
      answer:
        'A content gap is a high-intent topic, problem, or tactical question that your target audience actively searches for or laments in competitor comments, but which existing competitor videos only address superficially, outdatedly, or ignore altogether.',
    },
    {
      question: 'How do you find missing topics in a content strategy?',
      answer:
        'Specify your niche, main subject, and competitor examples. ToolFlow audits saturated clichés against audience vacuums to formulate underserved video concepts with estimated opportunity scores, hook suggestions, and practical execution outlines.',
    },
    {
      question: 'Why do competitor content voids improve viewer retention?',
      answer:
        'When viewers search for a specific solution and find 10 videos covering basic definitions but zero tutorials demonstrating the exact fix, finding an authoritative, focused video creates immediate relief and satisfaction. This translates directly to higher average percentage viewed (APV), bookmarks, and shares.',
    },
    {
      question: 'How can creators mine YouTube and TikTok comments for topic gaps?',
      answer:
        'Filter popular competitor videos by "Newest first" and search for phrases like "How do I", "What if", "Does this work when", or "I got stuck on". These unanswered viewer questions represent high-intent content gaps you can immediately turn into dedicated videos.',
    },
    {
      question: 'What are the operational limitations of automated gap analysis?',
      answer:
        'Content Gap Finder provides qualitative strategic synthesis and concept suggestions based on audience demand modeling. Opportunity scores (0-100) are comparative heuristic estimates, not verified third-party keyword search volumes or algorithmic guarantees. Always review suggestions against your channel expertise.',
    },
  ];

  const [formData, setFormData] = useState<ContentGapFormData>({
    niche: 'SaaS & Solopreneurship',
    mainTopic: 'Building micro-SaaS with no-code tools',
    platform: 'YouTube & TikTok',
    targetAudience: 'Non-technical founders and creators',
    competitorExamples: 'Top channels only show 1-day builds without discussing marketing or churn',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ContentGapResult | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [savedIndex, setSavedIndex] = useState<number | null>(null);

  const handleAnalyze = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!formData.niche.trim() || !formData.mainTopic.trim()) {
      addToast({
        title: 'Missing Required Fields',
        message: 'Please provide both your niche and main topic.',
        type: 'error',
      });
      return;
    }

    setIsLoading(true);
    try {
      const data = await fetchContentGap(formData);
      setResult(data);
      addToast({
        title: 'Content Gaps Identified',
        message: `Found ${data.underservedAngles.length} underserved content angles.`,
        type: 'success',
      });
    } catch (err: any) {
      addToast({
        title: 'Analysis Failed',
        message: err.message || 'Unable to analyze content gaps at this time.',
        type: 'error',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyGap = (index: number) => {
    if (!result) return;
    const item = result.underservedAngles[index];
    const text = `CONTENT GAP: ${item.angle}\n\nOPPORTUNITY SCORE (AI ESTIMATE): ${item.opportunityScore}/100\n${item.scoreReasoning}\n\nSUGGESTED TITLE / HOOK:\n${item.suggestedTitleHook}\n\nWHY IT'S USEFUL:\n${item.whyUseful}\n\nCONTENT IDEA / EXECUTION:\n${item.contentIdea}`;

    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    addToast({
      title: 'Copied',
      message: 'Gap analysis and hook copied to clipboard.',
      type: 'info',
    });
  };

  const handleSaveGap = (index: number) => {
    if (!result) return;
    const item = result.underservedAngles[index];
    saveResult({
      toolId: 'content-gap-finder',
      toolName: 'Content Gap Finder',
      category: 'creator',
      title: `Content Gap: ${item.angle}`,
      preview: item.suggestedTitleHook,
      content: `${item.whyUseful}\n\nIdea: ${item.contentIdea}\n\nScore: ${item.opportunityScore}/100 (AI Estimate)`,
      data: item,
    });
    setSavedIndex(index);
    setTimeout(() => setSavedIndex(null), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Breadcrumb */}
      <div className="mb-6 flex items-center justify-between">
        <a
          href="/tools?category=creator"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools?category=creator');
            }
          }}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Creator Tools
        </a>

        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
          Content Opportunity
        </span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-rose-500 flex items-center justify-center text-white shadow-xs">
            <Target className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Content Gap Finder
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Identify underserved audience questions, high-opportunity angles, and topics your competitors ignore.
            </p>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-3 p-3 rounded-lg bg-slate-100/80 border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-600">
          <Info className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong className="font-semibold text-slate-700">Notice on Opportunity Scores:</strong> Opportunity Scores (e.g. 92/100) are purely AI-modeled estimations evaluating topical saturation vs audience curiosity. They are calculated based on your text inputs and are not live platform API statistics.
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form */}
        <div className="lg:col-span-4">
          <Card className="p-6 bg-white shadow-xs sticky top-20">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-4 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-indigo-600" />
              Topic Details
            </h2>

            <form onSubmit={handleAnalyze} className="space-y-4">
              <Input
                label="Content Niche"
                placeholder="e.g. Fitness for Busy Dads"
                value={formData.niche}
                onChange={(e) => setFormData({ ...formData, niche: e.target.value })}
                required
              />

              <Input
                label="Core Topic"
                placeholder="e.g. High protein meal prep under 20 minutes"
                value={formData.mainTopic}
                onChange={(e) => setFormData({ ...formData, mainTopic: e.target.value })}
                required
              />

              <Select
                label="Target Platform"
                value={formData.platform}
                onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                options={[
                  { value: 'YouTube & TikTok', label: 'YouTube & TikTok (Video)' },
                  { value: 'YouTube Long-form', label: 'YouTube Long-form' },
                  { value: 'Instagram Reels', label: 'Instagram Reels' },
                  { value: 'LinkedIn Articles & Video', label: 'LinkedIn' },
                ]}
              />

              <Input
                label="Target Audience Profile"
                placeholder="e.g. Beginners with limited budget"
                value={formData.targetAudience}
                onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value })}
              />

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Optional Competitor / Example Nuance
                </label>
                <textarea
                  rows={3}
                  className="w-full p-3 rounded-lg border border-slate-300 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                  placeholder="e.g. What do most videos leave out? What frustrates viewers in comments?"
                  value={formData.competitorExamples || ''}
                  onChange={(e) => setFormData({ ...formData, competitorExamples: e.target.value })}
                />
              </div>

              <Button
                type="submit"
                variant="primary"
                className="w-full mt-4 font-semibold"
                isLoading={isLoading}
                leftIcon={<Target className="h-4 w-4" />}
              >
                {isLoading ? 'Detecting Gaps...' : 'Find Content Gaps'}
              </Button>
            </form>
          </Card>
        </div>

        {/* Right Output */}
        <div className="lg:col-span-8 space-y-6">
          {isLoading ? (
            <Card className="p-16 text-center bg-white">
              <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-indigo-600 mx-auto mb-4" />
              <p className="text-sm font-semibold text-slate-800">
                Auditing topic saturation and audience inquiries...
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Comparing saturated perspectives against high-demand audience questions...
              </p>
            </Card>
          ) : result ? (
            <div className="space-y-6">
              {/* Macro Analysis: Covered vs Unanswered */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Saturated / Covered */}
                <Card className="p-5 bg-white border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full inline-block mb-2">
                    Saturated Angles (Avoid Generic Repetition)
                  </span>
                  <ul className="space-y-2 text-xs text-slate-600">
                    {result.coveredAngles.map((angle, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-rose-400 font-bold shrink-0 mt-0.5">•</span>
                        <span>{angle}</span>
                      </li>
                    ))}
                  </ul>
                </Card>

                {/* Unanswered Audience Questions */}
                <Card className="p-5 bg-white border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full inline-block mb-2">
                    Unanswered Audience Questions (High Intent)
                  </span>
                  <ul className="space-y-2 text-xs text-slate-700 font-medium">
                    {result.unansweredQuestions.map((q, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <HelpCircle className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" />
                        <span>"{q}"</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>

              {/* Underserved Angles List */}
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Lightbulb className="h-4 w-4 text-indigo-600" />
                    High-Opportunity Content Vacuums ({result.underservedAngles.length})
                  </h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleAnalyze()}
                    leftIcon={<RotateCcw className="h-3.5 w-3.5" />}
                  >
                    Rerun Analysis
                  </Button>
                </div>

                {result.underservedAngles.map((item, idx) => (
                  <Card key={idx} className="p-5 sm:p-6 bg-white border border-slate-200/90 shadow-xs hover:border-slate-300 transition-colors">
                    {/* Header with Opportunity Score */}
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <span className="px-2.5 py-0.5 rounded-md text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs">
                            Opportunity Score: {item.opportunityScore}/100
                          </span>
                          <span className="text-[11px] text-slate-400 font-medium">AI Estimate</span>
                        </div>
                        <h4 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                          {item.angle}
                        </h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">{item.scoreReasoning}</p>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-start">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCopyGap(idx)}
                          leftIcon={copiedIndex === idx ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                        >
                          {copiedIndex === idx ? 'Copied' : 'Copy'}
                        </Button>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => handleSaveGap(idx)}
                          leftIcon={savedIndex === idx ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
                        >
                          {savedIndex === idx ? 'Saved' : 'Save'}
                        </Button>
                      </div>
                    </div>

                    {/* Suggested Hook / Title */}
                    <div className="my-3 p-3.5 rounded-lg bg-indigo-50/60 border border-indigo-100 text-xs text-indigo-950 leading-relaxed">
                      <strong className="text-indigo-900 font-semibold block mb-0.5">Suggested Hook / Title:</strong>
                      <span className="text-sm font-bold text-indigo-700 font-sans block mt-1">"{item.suggestedTitleHook}"</span>
                    </div>

                    {/* Why Useful & Content Idea */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-600">
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <strong className="font-semibold text-slate-800 block mb-0.5">Why This Gap Exists:</strong>
                        <p className="leading-relaxed">{item.whyUseful}</p>
                      </div>

                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <strong className="font-semibold text-slate-800 block mb-0.5">Video Execution Idea:</strong>
                        <p className="leading-relaxed">{item.contentIdea}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Banner ad */}
              <div className="pt-4 flex justify-center">
                <AdBanner size="728x90" />
              </div>
            </div>
          ) : (
            <Card className="p-12 text-center bg-white border-dashed">
              <div className="h-12 w-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3">
                <Target className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No Content Gaps Audited Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-5">
                Input your niche and topic to reveal underserved opportunities that viewers are searching for.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleAnalyze()}
                leftIcon={<Sparkles className="h-3.5 w-3.5" />}
              >
                Analyze Default Topic
              </Button>
            </Card>
          )}

          {/* Smartlink promo */}
          <SmartlinkPromo
            variant="card"
            title="Grow Your Audience With Creator Tools"
            description="Explore special partner discounts on video hosting, screen recorders, and asset libraries."
          />
        </div>
      </div>

      {/* Comprehensive Editorial & Strategy Guide */}
      <div className="mt-16 space-y-12">
        {/* Step-by-Step Methodology */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <Compass className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              The Content Whitespace Audit Framework (Step-by-Step)
            </h2>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed mb-6">
            Finding missing topics in your content strategy allows you to capture search demand that top channels take for granted. By addressing audience questions that competitors ignore, you create immediate loyalty.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-rose-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                1
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Identify Saturated Angles</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Observe the topics that top creators churn out repeatedly (e.g., "5 Best AI Tools" or "How to Start Dropshipping"). These saturated topics have massive creator competition and low incremental audience value.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-indigo-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                2
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Uncover the Audience Vacuum</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Mine the practical hurdles viewers face after watching the introductory video. Audience vacuums represent the operational details that beginner tutorials gloss over.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-emerald-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                3
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Position High-Opportunity Solutions</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Formulate an authoritative, focused video addressing that exact void. Deliver step-by-step clarity within the first 30 seconds to capture search traffic and build retention.
              </p>
            </div>
          </div>
        </section>

        {/* Real-World Strategy Case Study */}
        <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <TrendingUp className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">
              Real-World Strategy Case Study: Micro-SaaS &amp; No-Code
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
            Comparing saturated cliché topics against an underserved audience vacuum.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm">
            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <h4 className="font-bold text-rose-400 uppercase tracking-wider text-xs">Saturated Competitor Cliché</h4>
              <div>
                <span className="text-slate-400 block text-xs">Topic Angle:</span>
                <span className="font-semibold text-white">"How I built a SaaS in 24 hours without code"</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Audience Fatigue:</span>
                <span className="text-slate-300">Over 500 near-identical videos exist; viewers know it is clickbait and drop off within 45 seconds because operational realities like payments, authentication, and customer churn are omitted.</span>
              </div>
            </div>

            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <h4 className="font-bold text-emerald-400 uppercase tracking-wider text-xs">Underserved Content Gap Solution</h4>
              <div>
                <span className="text-slate-400 block text-xs">Untapped Angle:</span>
                <span className="font-semibold text-white">"Handling Stripe subscriptions, webhooks &amp; customer churn in no-code web apps"</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Retention Multiplier:</span>
                <span className="text-emerald-400 font-semibold">High search intent, low video supply, exceptional bookmark rate, and long-tail organic search discoverability.</span>
              </div>
            </div>
          </div>
        </section>

        {/* Operational Limitations */}
        <section className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-6 sm:p-8 text-amber-950">
          <div className="flex items-center gap-2.5 mb-3">
            <Lightbulb className="h-5 w-5 text-amber-600 shrink-0" />
            <h2 className="text-lg sm:text-xl font-bold text-amber-900">
              Operational Limitations &amp; Notice on Gap Modeling
            </h2>
          </div>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90 mb-3">
            <strong>Suggested Opportunities (Unverified Search Volumes):</strong> Opportunity scores and gap analyses represent qualitative heuristic assessments generated by AI prompt modeling. They help identify structural holes in competitor catalogs, but they are not verified Google/YouTube Keyword Planner API volumes.
          </p>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90">
            <strong>Audience Nuance:</strong> Always cross-reference suggested gaps with your specific audience tier. A gap suitable for intermediate builders may prove too complex for complete beginners.
          </p>
        </section>

        {/* FAQ Accordion */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-6">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                Frequently Asked Questions
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Common questions about content gap analysis, competitor voids, and missing topic discovery.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-slate-200/80 overflow-hidden transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(index)}
                    className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-semibold text-slate-900">
                      {item.question}
                    </span>
                    <span className="text-slate-400 shrink-0">
                      {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="p-4 sm:p-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed bg-white border-t border-slate-100">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Related Creator Growth Utilities */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Layers className="h-4 w-4 text-indigo-600" />
            Related Creator Workflow Tools
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a
              href="/tools/creator/trend-radar"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/trend-radar');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-rose-600 transition-colors">
                  Trend Radar
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-rose-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Discover rising topical vectors and search momentum across niches.
              </p>
            </a>

            <a
              href="/tools/creator/hook-doctor"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/hook-doctor');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors">
                  Hook Doctor
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Turn your identified content gap into a high-retention opening hook.
              </p>
            </a>

            <a
              href="/tools/creator/content-experiment-generator"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/content-experiment-generator');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-emerald-600 transition-colors">
                  Content Experiment Generator
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Formulate 3 distinct testing angles (Curiosity, Framework, Story) for your gap.
              </p>
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};
