import React, { useState } from 'react';
import { TrendRadarFormData, TrendRadarResult } from '../../../types';
import { fetchTrendRadar } from '../../../services/creatorToolsService';
import { useApp } from '../../../context/AppContext';
import { Button } from '../../../components/common/Button';
import { Input } from '../../../components/common/Input';
import { Select } from '../../../components/common/Select';
import { Card } from '../../../components/common/Card';
import { Badge } from '../../../components/common/Badge';
import { AdBanner, SmartlinkPromo } from '../../../components/ads';
import {
  Radar,
  ArrowLeft,
  Sparkles,
  TrendingUp,
  Compass,
  Copy,
  Check,
  Bookmark,
  RotateCcw,
  Search,
  Hash,
  Video,
  Info,
  Layers,
  Flame,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  Target,
  Clock,
  FileText,
} from 'lucide-react';
import { usePageSEO } from '../../../utils/usePageSEO';

interface TrendRadarPageProps {
  onNavigate: (path: string) => void;
}

export const TrendRadarPage: React.FC<TrendRadarPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Trend Radar – Content Trend Research Tool for Creators & Niches | ToolFlow',
    description:
      "Find content trends for a specific niche with ToolFlow's AI content trend research tool for creators. Discover rising video topic angles across YouTube and TikTok.",
    canonicalPath: '/tools/creator/trend-radar',
    robots: 'index, follow',
  });

  const { saveResult, addToast } = useApp();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'How do you find content trends for a specific niche?',
      answer:
        'To find content trends for a specific niche, specify your target platform (such as YouTube, TikTok, or Instagram Reels), define your core industry domain, and select your primary content format. ToolFlow scans emerging audience demand patterns, high-momentum search queries, and underserved topic angles to highlight concepts with high viewer interest before competition saturates.',
    },
    {
      question: 'What is the difference between velocity signals and competition saturation?',
      answer:
        'Velocity reflects how rapidly viewer search queries, hashtag interactions, and audience questions are multiplying. Competition saturation indicates how many top creators have already published comprehensive videos on that exact angle. The highest-converting creator opportunities occur when velocity is emerging or growing while saturation remains low.',
    },
    {
      question: 'Can Trend Radar guarantee video virality on YouTube or TikTok?',
      answer:
        'No tool or algorithm predictor can guarantee virality or algorithmic feed placement. Trend Radar highlights rising audience demand vectors and search queries, but video execution, hook retention in the opening 3 seconds, average watch percentage, and community interaction ultimately determine platform distribution.',
    },
    {
      question: 'How frequently should creators update their trend radar?',
      answer:
        'Content creators publishing weekly or bi-weekly should scan their trend radar at the start of each production sprint. This prevents recording content around topics that have already passed their peak search interest or shifted into hyper-saturated territory.',
    },
    {
      question: 'Which content formats work best for emerging trends?',
      answer:
        'Short-form vertical videos (30-60 seconds on TikTok, Reels, and Shorts) are ideal for rapid trend testing because algorithms distribute them to exploratory audiences quickly. If a short-form trend angle demonstrates high bookmark and share ratios, expand it into an authoritative long-form deep dive (8-15 minutes) on YouTube.',
    },
  ];

  const [formData, setFormData] = useState<TrendRadarFormData>({
    platform: 'YouTube',
    niche: 'AI & Digital Productivity',
    targetCountry: 'United States',
    targetLanguage: 'English',
    contentFormat: 'Long-form Video (8-15 min)',
    optionalTopic: 'Automating business workflows with modern tools',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<TrendRadarResult | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [savedIndex, setSavedIndex] = useState<number | null>(null);

  const handleAnalyze = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!formData.niche.trim()) {
      addToast({
        title: 'Niche is required',
        message: 'Please specify your target content niche or industry.',
        type: 'error',
      });
      return;
    }

    setIsLoading(true);
    try {
      const data = await fetchTrendRadar(formData);
      setResult(data);
      addToast({
        title: 'Trend Radar updated',
        message: `Identified ${data.trends.length} high-potential topic angles.`,
        type: 'success',
      });
    } catch (err: any) {
      addToast({
        title: 'Generation Failed',
        message: err.message || 'Unable to scan trends at this time.',
        type: 'error',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyTopic = (index: number) => {
    if (!result) return;
    const item = result.trends[index];
    const text = `TOPIC: ${item.topic} (${item.trendStatus})\n\nWHY RELEVANT:\n${item.whyRelevant}\n\nSUGGESTED VIDEO IDEA:\n${item.suggestedVideoIdea}\n\nCONTENT ANGLES:\n${item.contentAngles.map((a) => `- ${a}`).join('\n')}\n\nSEARCH TERMS:\n${item.searchTerms.join(', ')}\n\nHASHTAGS:\n${item.hashtags.join(' ')}`;

    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    addToast({
      title: 'Topic Copied',
      message: 'Full topic outline and angles copied to clipboard.',
      type: 'info',
    });
  };

  const handleSaveTopic = (index: number) => {
    if (!result) return;
    const item = result.trends[index];
    saveResult({
      toolId: 'trend-radar',
      toolName: 'Trend Radar',
      category: 'creator',
      title: `Trend: ${item.topic}`,
      preview: item.suggestedVideoIdea,
      content: `${item.whyRelevant}\n\nAngles:\n${item.contentAngles.join('\n')}\n\nTags:\n${item.hashtags.join(' ')}`,
      data: item,
    });
    setSavedIndex(index);
    setTimeout(() => setSavedIndex(null), 2500);
  };

  const getStatusBadge = (status: 'Emerging' | 'Growing' | 'Established') => {
    switch (status) {
      case 'Emerging':
        return <Badge variant="indigo" size="sm">⚡ Emerging</Badge>;
      case 'Growing':
        return <Badge variant="emerald" size="sm">📈 Growing Demand</Badge>;
      case 'Established':
        return <Badge variant="slate" size="sm">🏛️ Established Pillar</Badge>;
      default:
        return <Badge variant="slate" size="sm">{status}</Badge>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Breadcrumb & Navigation */}
      <div className="mb-6 flex items-center justify-between">
        <a
          href="/tools?category=creator"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools?category=creator');
            }
          }}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Creator Tools
        </a>

        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200">
          Creator Intelligence
        </span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-rose-500 to-indigo-600 flex items-center justify-center text-white shadow-xs">
            <Radar className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Trend Radar
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Discover rising topic opportunities, audience search intent, and fresh content angles for your niche.
            </p>
          </div>
        </div>

        {/* Disclaimer Banner */}
        <div className="mt-3 p-3 rounded-lg bg-slate-100/80 border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-600">
          <Info className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong className="font-semibold text-slate-700">Notice on Data:</strong> Topic opportunities are synthesized using predictive audience demand modeling and contextual query patterns. They reflect AI-assisted content analysis and do not guarantee live algorithmic virality or platform views.
          </p>
        </div>
      </div>

      {/* Main Grid: Form Left, Results Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form Column */}
        <div className="lg:col-span-4">
          <Card className="p-6 bg-white shadow-xs sticky top-20">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-4 flex items-center gap-2">
              <Compass className="h-4 w-4 text-indigo-600" />
              Radar Parameters
            </h2>

            <form onSubmit={handleAnalyze} className="space-y-4">
              <Select
                label="Target Platform"
                value={formData.platform}
                onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                options={[
                  { value: 'YouTube', label: 'YouTube (Long & Short-form)' },
                  { value: 'TikTok', label: 'TikTok' },
                  { value: 'Instagram Reels', label: 'Instagram Reels' },
                  { value: 'LinkedIn', label: 'LinkedIn Video & Posts' },
                  { value: 'X / Twitter', label: 'X / Twitter Threads & Video' },
                ]}
              />

              <Input
                label="Niche or Industry"
                placeholder="e.g. Personal Finance, Tech, Fitness"
                value={formData.niche}
                onChange={(e) => setFormData({ ...formData, niche: e.target.value })}
                required
              />

              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Target Country"
                  placeholder="e.g. United States"
                  value={formData.targetCountry}
                  onChange={(e) => setFormData({ ...formData, targetCountry: e.target.value })}
                />
                <Input
                  label="Language"
                  placeholder="e.g. English"
                  value={formData.targetLanguage}
                  onChange={(e) => setFormData({ ...formData, targetLanguage: e.target.value })}
                />
              </div>

              <Select
                label="Content Format"
                value={formData.contentFormat}
                onChange={(e) => setFormData({ ...formData, contentFormat: e.target.value })}
                options={[
                  { value: 'Short-form Video (30-60s)', label: 'Short-form (30-60s)' },
                  { value: 'Long-form Video (8-15 min)', label: 'Long-form Deep-Dive (8-15 min)' },
                  { value: 'Tutorial & Screencast', label: 'Hands-on Tutorial & Screencast' },
                  { value: 'Story & Vlog Style', label: 'Story & Vlog Style' },
                ]}
              />

              <Input
                label="Optional Sub-Theme"
                placeholder="e.g. Beginner automation tools"
                value={formData.optionalTopic || ''}
                onChange={(e) => setFormData({ ...formData, optionalTopic: e.target.value })}
                helperText="Narrow your radar to a specific angle or leave blank for broader ideas."
              />

              <Button
                type="submit"
                variant="primary"
                className="w-full mt-4 font-semibold"
                isLoading={isLoading}
                leftIcon={<Radar className="h-4 w-4" />}
              >
                {isLoading ? 'Scanning Topic Signals...' : 'Scan Trend Radar'}
              </Button>
            </form>
          </Card>
        </div>

        {/* Right Output Column */}
        <div className="lg:col-span-8 space-y-6">
          {isLoading ? (
            <Card className="p-16 text-center bg-white">
              <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-rose-600 mx-auto mb-4" />
              <p className="text-sm font-semibold text-slate-800">
                Scanning audience search patterns for {formData.niche}...
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Analyzing high-opportunity topic clusters, search queries, and content angles...
              </p>
            </Card>
          ) : result ? (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-emerald-600" />
                    Detected Topic Radar ({result.trends.length} Opportunities)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Targeting {formData.platform} • {formData.niche} • {formData.targetCountry}
                  </p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleAnalyze()}
                  leftIcon={<RotateCcw className="h-3.5 w-3.5" />}
                >
                  Refresh Radar
                </Button>
              </div>

              {/* Trend Cards */}
              <div className="space-y-5">
                {result.trends.map((item, idx) => (
                  <Card key={idx} className="p-5 sm:p-6 bg-white border border-slate-200/90 shadow-xs hover:border-slate-300 transition-colors">
                    {/* Top Row: Title, Status, and Actions */}
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2.5 mb-1.5">
                          {getStatusBadge(item.trendStatus)}
                          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                            Opportunity #{idx + 1}
                          </span>
                        </div>
                        <h4 className="text-lg font-bold text-slate-900 tracking-tight">
                          {item.topic}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-start">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCopyTopic(idx)}
                          leftIcon={copiedIndex === idx ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                        >
                          {copiedIndex === idx ? 'Copied' : 'Copy Package'}
                        </Button>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => handleSaveTopic(idx)}
                          leftIcon={savedIndex === idx ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
                        >
                          {savedIndex === idx ? 'Saved' : 'Save'}
                        </Button>
                      </div>
                    </div>

                    {/* Why Relevant */}
                    <div className="my-3 p-3 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-600 leading-relaxed">
                      <strong className="text-slate-800 font-semibold block mb-0.5">Why This Is Gaining Momentum:</strong>
                      {item.whyRelevant}
                    </div>

                    {/* Suggested Video Idea */}
                    <div className="mb-4 p-3 rounded-lg bg-rose-50/50 border border-rose-100 text-xs text-rose-950 leading-relaxed flex items-start gap-2.5">
                      <Video className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <strong className="font-semibold text-rose-900 block mb-0.5">Suggested Video Concept:</strong>
                        {item.suggestedVideoIdea}
                      </div>
                    </div>

                    {/* Content Angles */}
                    <div className="space-y-1.5 mb-4">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                        Angles You Can Test:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        {item.contentAngles.map((angle, aIdx) => (
                          <div key={aIdx} className="p-2.5 rounded-lg border border-slate-100 bg-white text-xs text-slate-700 leading-snug">
                            <span className="font-bold text-indigo-600 mr-1.5">#{aIdx + 1}</span>
                            {angle}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Search Terms & Tags */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-100 text-xs">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5 flex items-center gap-1">
                          <Search className="h-3 w-3 text-slate-400" /> Related Search Intent
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {item.searchTerms.map((term, tIdx) => (
                            <span key={tIdx} className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px]">
                              {term}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5 flex items-center gap-1">
                          <Hash className="h-3 w-3 text-slate-400" /> Suggested Tags
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {item.hashtags.map((tag, hIdx) => (
                            <span key={hIdx} className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 text-[11px] font-mono">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Sponsored Banner Component */}
              <div className="pt-4 flex justify-center">
                <AdBanner size="728x90" />
              </div>
            </div>
          ) : (
            <Card className="p-12 text-center bg-white border-dashed">
              <div className="h-12 w-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3">
                <Radar className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No Trends Scanned Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-5">
                Configure your platform and niche on the left to scan emerging topic vacuums and video concepts.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleAnalyze()}
                leftIcon={<Sparkles className="h-3.5 w-3.5" />}
              >
                Scan Default Scenario
              </Button>
            </Card>
          )}

          {/* Smartlink Partner Offer Card */}
          <SmartlinkPromo
            variant="card"
            title="Top Recommended Growth Tools for Video Creators"
            description="Access verified stock asset deals, AI editing software, and sound design libraries."
          />
        </div>
      </div>

      {/* Comprehensive Editorial & Strategy Guide */}
      <div className="mt-16 space-y-12">
        {/* Step-by-Step Methodology */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-rose-50 text-rose-600">
              <Compass className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              How to Find Content Trends for a Specific Niche (Step-by-Step)
            </h2>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed mb-6">
            Finding high-converting content trends is not about chasing ephemeral viral dances. It is about identifying high-velocity search queries and emerging audience questions before the market reaches peak saturation.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-rose-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                1
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Define Channel Domain &amp; Format</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Specify your primary platform (YouTube, TikTok, Instagram Reels) and intended format. Different algorithms prioritize different retention windows—Shorts favor 3-second visual hooks, while YouTube long-form prioritizes search intent and 8-minute average watch duration.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-indigo-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                2
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Scan Velocity vs. Saturation</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Evaluate whether a topic is Emerging (low creator supply, rapid question surge), Growing Demand (proven viewer interest, active audience discussions), or an Established Pillar (steady baseline, highly competitive). Target emerging queries for rapid organic growth.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="h-8 w-8 rounded-full bg-emerald-600 text-white font-bold text-sm flex items-center justify-center mb-3">
                3
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Develop Unique Content Angles</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Avoid regurgitating identical scripts. Take an identified trend and formulate 3 differentiated angles: a contrarian challenge, a step-by-step practical teardown, or a relatable real-world case study.
              </p>
            </div>
          </div>
        </section>

        {/* Real-World Worked Case Study */}
        <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-rose-500/20 text-rose-400">
              <TrendingUp className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">
              Real-World Niche Case Study: AI &amp; Digital Productivity
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
            Here is an example of how a creator in the digital productivity niche uses Trend Radar to formulate a high-converting video concept.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm">
            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <h4 className="font-bold text-rose-400 uppercase tracking-wider text-xs">Identified Trend Signals</h4>
              <div>
                <span className="text-slate-400 block text-xs">Targeted Niche:</span>
                <span className="font-semibold text-white">Freelance Operations &amp; Client Management</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Emerging Query:</span>
                <span className="font-semibold text-white">"Automating freelance client onboarding with no-code tools"</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Momentum Indicator:</span>
                <span className="text-emerald-400 font-semibold">⚡ Emerging Demand (Low competition, high bookmark intent)</span>
              </div>
            </div>

            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <h4 className="font-bold text-indigo-400 uppercase tracking-wider text-xs">Formulated Content Package</h4>
              <div>
                <span className="text-slate-400 block text-xs">Suggested Hook:</span>
                <span className="text-slate-200">"If you're still onboarding freelance clients over email, you're losing 5 hours a week. Here is the exact 1-link intake portal that saves 20 hours a month."</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Suggested Content Angles:</span>
                <ul className="list-disc list-inside text-slate-300 space-y-1 mt-1 text-xs">
                  <li>Angle 1: The 3 biggest onboarding mistakes that cause client churn</li>
                  <li>Angle 2: Free Notion + Google Forms automated template setup</li>
                  <li>Angle 3: How an automated intake questionnaire increased repeat client bookings by 30%</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Operational Limitations */}
        <section className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-6 sm:p-8 text-amber-950">
          <div className="flex items-center gap-2.5 mb-3">
            <Lightbulb className="h-5 w-5 text-amber-600 shrink-0" />
            <h2 className="text-lg sm:text-xl font-bold text-amber-900">
              Operational Limitations &amp; Notice on Suggested Trends
            </h2>
          </div>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90 mb-3">
            <strong>Unverified Search Volumes:</strong> The topics, velocity indicators, and suggested keywords generated by Trend Radar represent qualitative AI demand modeling and predictive contextual patterns. They are suggestions designed to inspire creative testing, not verified third-party search volume numbers or algorithmic guarantees.
          </p>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90">
            <strong>Platform Variables:</strong> Video performance depends heavily on audience retention, thumbnail click-through rates (CTR), spoken pacing, and community engagement. Always validate suggested topics against your personal creator voice and channel identity.
          </p>
        </section>

        {/* FAQ Accordion */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-6">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                Frequently Asked Questions
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Answers to common questions about finding niche content trends and researching topic ideas.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-slate-200/80 overflow-hidden transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(index)}
                    className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-semibold text-slate-900">
                      {item.question}
                    </span>
                    <span className="text-slate-400 shrink-0">
                      {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="p-4 sm:p-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed bg-white border-t border-slate-100">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Related Creator Growth Utilities */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Layers className="h-4 w-4 text-rose-600" />
            Related Creator Workflow Tools
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a
              href="/tools/creator/content-gap-finder"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/content-gap-finder');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-rose-600 transition-colors">
                  Content Gap Finder
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-rose-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Uncover missing topics and competitor whitespace in your niche.
              </p>
            </a>

            <a
              href="/tools/creator/hook-doctor"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/hook-doctor');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors">
                  Hook Doctor
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Diagnose and upgrade opening hooks for higher short-form retention.
              </p>
            </a>

            <a
              href="/tools/creator/hashtag-keyword-mixer"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/hashtag-keyword-mixer');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-emerald-600 transition-colors">
                  Hashtag &amp; Keyword Mixer
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Combine balanced hashtag tiers with natural language search terms.
              </p>
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};
