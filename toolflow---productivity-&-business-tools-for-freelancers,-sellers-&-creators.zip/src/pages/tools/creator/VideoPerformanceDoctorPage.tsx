import React, { useState } from 'react';
import { VideoPerformanceFormData, VideoPerformanceResult } from '../../../types';
import { fetchVideoPerformance } from '../../../services/creatorToolsService';
import { useApp } from '../../../context/AppContext';
import { Button } from '../../../components/common/Button';
import { Input } from '../../../components/common/Input';
import { Select } from '../../../components/common/Select';
import { Card } from '../../../components/common/Card';
import { Badge } from '../../../components/common/Badge';
import { AdBanner, SmartlinkPromo } from '../../../components/ads';
import {
  Activity,
  ArrowLeft,
  Sparkles,
  Check,
  Copy,
  Bookmark,
  RotateCcw,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  Lightbulb,
  Info,
  CheckCircle2,
  Percent,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  ArrowRight,
  Layers,
  Compass,
  Clock,
  FileText,
} from 'lucide-react';
import { usePageSEO } from '../../../utils/usePageSEO';

interface VideoPerformanceDoctorPageProps {
  onNavigate: (path: string) => void;
}

export const VideoPerformanceDoctorPage: React.FC<VideoPerformanceDoctorPageProps> = ({
  onNavigate,
}) => {
  usePageSEO({
    title: 'Video Performance Doctor – Analyze Short-Form Video Performance | ToolFlow',
    description:
      'Analyze short-form video performance with ToolFlow. Improve video retention and audience engagement by auditing like-to-view, share, and completion ratios.',
    canonicalPath: '/tools/creator/video-performance-doctor',
    robots: 'index, follow',
  });

  const { saveResult, addToast } = useApp();
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'How do you analyze short-form video performance effectively?',
      answer:
        'Rather than focusing purely on raw view counts, evaluate core engagement ratios: Like-to-View Ratio (target 6%-10%), Comment-to-View Ratio (target 0.3%-0.8%), and Share-to-View Ratio (target >0.5%). These ratios pinpoint whether weak performance is due to packaging (CTR/Hook) or mid-video viewer drop-offs.',
    },
    {
      question: 'Why is the share-to-view ratio considered the strongest algorithm signal?',
      answer:
        'Recommendation engines on TikTok, Instagram, and YouTube prioritize videos that attract external users back to the app or trigger DM conversations. When a viewer sends a video to a friend, the algorithm interprets the content as exceptionally valuable and distributes it to a broader test cohort.',
    },
    {
      question: 'What are typical like-to-view benchmarks for TikTok and Reels?',
      answer:
        'A like-to-view ratio below 4% indicates below-average resonance or misleading hook packaging. 4% to 8% represents a healthy baseline for entertaining or educational content, while ratios above 9% indicate strong viewer resonance that frequently precedes organic algorithm expansion.',
    },
    {
      question: 'How can creators diagnose whether low views are due to CTR vs retention?',
      answer:
        'If impressions are high but views are low (or swipe-away rate is >65%), the issue is packaging—your thumbnail, title, or opening 3-second hook failed to capture attention. If initial 3-second retention is high (e.g., >70% watched past 3s) but average percentage viewed drops below 40%, the body pacing or delivery lacks momentum.',
    },
    {
      question: 'What immediate changes improve mid-video drop-off?',
      answer:
        'To fix mid-video drop-offs, trim pauses and breaths between sentences, introduce visual b-roll or on-screen callouts every 4 to 6 seconds, and use open loops (e.g., "In a second, I will show you the exact setting to toggle") to keep viewers invested until the conclusion.',
    },
  ];

  const [formData, setFormData] = useState<VideoPerformanceFormData>({
    platform: 'YouTube Shorts',
    videoLength: '48 seconds',
    views: 18500,
    likes: 1240,
    comments: 68,
    shares: 215,
    averageWatchTime: '31 seconds',
    averagePercentageViewed: 64,
    impressions: 42000,
    ctr: 5.8,
    followers: 12500,
    videoTitle: 'The 3-minute freelance invoice workflow that stops late payments',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<VideoPerformanceResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleDiagnose = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!formData.views || formData.views <= 0) {
      addToast({
        title: 'Views are required',
        message: 'Please enter a positive view count to calculate engagement ratios.',
        type: 'error',
      });
      return;
    }

    setIsLoading(true);
    try {
      const data = await fetchVideoPerformance(formData);
      setResult(data);
      addToast({
        title: 'Performance Diagnostics Ready',
        message: 'Calculated engagement benchmarks and formulated 3 tactical suggestions.',
        type: 'success',
      });
    } catch (err: any) {
      addToast({
        title: 'Audit Failed',
        message: err.message || 'Unable to audit video performance.',
        type: 'error',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyAnalysis = () => {
    if (!result) return;
    const text = `VIDEO PERFORMANCE DIAGNOSTICS:
Platform: ${formData.platform} | Views: ${formData.views.toLocaleString()}
Like Ratio: ${result.calculations.likeToViewRatio}% | Comment Ratio: ${result.calculations.commentRatio}% | Share Ratio: ${result.calculations.shareRatio}%

OBSERVATIONS:
${result.performanceObservations}

REACH & RETENTION:
- Reach: ${result.reachObservations}
- Retention: ${result.retentionObservations}

PRACTICAL IMPROVEMENTS:
${result.practicalSuggestions.map((s, i) => `${i + 1}. ${s}`).join('\n')}

NEXT VIDEO IDEAS:
${result.nextVideoRecommendations.map((r, i) => `${i + 1}. ${r}`).join('\n')}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    addToast({
      title: 'Audit Copied',
      message: 'Full diagnostic summary copied to clipboard.',
      type: 'info',
    });
  };

  const handleSaveResult = () => {
    if (!result) return;
    saveResult({
      toolId: 'video-performance-doctor',
      toolName: 'Video Performance Doctor',
      category: 'creator',
      title: `Audit: ${formData.videoTitle || formData.platform + ' Video'}`,
      preview: `${formData.views.toLocaleString()} views • ${result.calculations.totalEngagementRate}% engagement`,
      content: result.performanceObservations,
      data: {
        formData,
        result,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Breadcrumb */}
      <div className="mb-6 flex items-center justify-between">
        <a
          href="/tools?category=creator"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools?category=creator');
            }
          }}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Creator Tools
        </a>

        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
          Video Analytics Audit
        </span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-xs">
            <Activity className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Video Performance Doctor
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Audit engagement ratios, diagnose reach/retention bottlenecks, and receive 3 practical improvements for your next video.
            </p>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-3 p-3 rounded-lg bg-slate-100/80 border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-600">
          <Info className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong className="font-semibold text-slate-700">Notice on Diagnostics:</strong> This audit is strictly formulated from the numerical inputs you enter below and compares them to standard creator platform heuristics. It is an analytical guide and cannot guarantee future algorithmic performance.
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form */}
        <div className="lg:col-span-5">
          <Card className="p-6 bg-white shadow-xs sticky top-20">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-4 flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-indigo-600" />
              Video Performance Metrics
            </h2>

            <form onSubmit={handleDiagnose} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <Select
                  label="Platform"
                  value={formData.platform}
                  onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                  options={[
                    { value: 'YouTube Shorts', label: 'YouTube Shorts' },
                    { value: 'YouTube Long-form', label: 'YouTube Long-form' },
                    { value: 'TikTok', label: 'TikTok' },
                    { value: 'Instagram Reels', label: 'Instagram Reels' },
                  ]}
                />
                <Input
                  label="Video Duration"
                  placeholder="e.g. 45s, 12 min"
                  value={formData.videoLength}
                  onChange={(e) => setFormData({ ...formData, videoLength: e.target.value })}
                />
              </div>

              <Input
                label="Optional Video Title or Core Concept"
                placeholder="e.g. 3 freelance invoice mistakes"
                value={formData.videoTitle || ''}
                onChange={(e) => setFormData({ ...formData, videoTitle: e.target.value })}
              />

              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Views"
                  type="number"
                  min="1"
                  value={formData.views}
                  onChange={(e) => setFormData({ ...formData, views: Number(e.target.value) || 0 })}
                  required
                />
                <Input
                  label="Likes"
                  type="number"
                  min="0"
                  value={formData.likes}
                  onChange={(e) => setFormData({ ...formData, likes: Number(e.target.value) || 0 })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Comments"
                  type="number"
                  min="0"
                  value={formData.comments}
                  onChange={(e) => setFormData({ ...formData, comments: Number(e.target.value) || 0 })}
                />
                <Input
                  label="Shares"
                  type="number"
                  min="0"
                  value={formData.shares}
                  onChange={(e) => setFormData({ ...formData, shares: Number(e.target.value) || 0 })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Avg Watch Time"
                  placeholder="e.g. 28s or 4m 12s"
                  value={formData.averageWatchTime}
                  onChange={(e) => setFormData({ ...formData, averageWatchTime: e.target.value })}
                />
                <Input
                  label="Avg % Viewed (if known)"
                  type="number"
                  placeholder="e.g. 62"
                  min="0"
                  max="100"
                  value={formData.averagePercentageViewed || ''}
                  onChange={(e) => setFormData({ ...formData, averagePercentageViewed: Number(e.target.value) || undefined })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Impressions (Optional)"
                  type="number"
                  placeholder="e.g. 25000"
                  value={formData.impressions || ''}
                  onChange={(e) => setFormData({ ...formData, impressions: Number(e.target.value) || undefined })}
                />
                <Input
                  label="CTR % (Optional)"
                  type="number"
                  step="0.1"
                  placeholder="e.g. 5.4"
                  value={formData.ctr || ''}
                  onChange={(e) => setFormData({ ...formData, ctr: Number(e.target.value) || undefined })}
                />
              </div>

              <Input
                label="Account Followers / Subs"
                type="number"
                min="0"
                value={formData.followers}
                onChange={(e) => setFormData({ ...formData, followers: Number(e.target.value) || 0 })}
              />

              <Button
                type="submit"
                variant="primary"
                className="w-full mt-4 font-semibold"
                isLoading={isLoading}
                leftIcon={<Activity className="h-4 w-4" />}
              >
                {isLoading ? 'Calculating Audit...' : 'Diagnose Video Performance'}
              </Button>
            </form>
          </Card>
        </div>

        {/* Right Output */}
        <div className="lg:col-span-7 space-y-6">
          {isLoading ? (
            <Card className="p-16 text-center bg-white">
              <div className="animate-spin rounded-full h-10 w-10 border-2 border-slate-200 border-t-indigo-600 mx-auto mb-4" />
              <p className="text-sm font-semibold text-slate-800">
                Auditing ratios and retention metrics...
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Comparing your like, comment, and share metrics against platform norms...
              </p>
            </Card>
          ) : result ? (
            <div className="space-y-6">
              {/* Stat Ratios Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <Card className="p-4 bg-white border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Like-to-View</span>
                  <p className="text-xl font-bold font-mono text-slate-900 mt-1">
                    {result.calculations.likeToViewRatio}%
                  </p>
                  <span className="text-[10px] text-slate-500">Benchmark: 4-8%</span>
                </Card>

                <Card className="p-4 bg-white border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Comment Ratio</span>
                  <p className="text-xl font-bold font-mono text-indigo-700 mt-1">
                    {result.calculations.commentRatio}%
                  </p>
                  <span className="text-[10px] text-slate-500">Benchmark: 0.3-1%</span>
                </Card>

                <Card className="p-4 bg-white border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Share Ratio</span>
                  <p className="text-xl font-bold font-mono text-rose-700 mt-1">
                    {result.calculations.shareRatio}%
                  </p>
                  <span className="text-[10px] text-slate-500">Discovery multiplier</span>
                </Card>

                <Card className="p-4 bg-white border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Engage</span>
                  <p className="text-xl font-bold font-mono text-emerald-700 mt-1">
                    {result.calculations.totalEngagementRate}%
                  </p>
                  <span className="text-[10px] text-slate-500">Likes+Comments+Shares</span>
                </Card>
              </div>

              {/* Performance Observations Header Card */}
              <Card className="p-5 sm:p-6 bg-white border border-slate-200 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 mb-3">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-indigo-600" />
                    Algorithmic Health Audit
                  </h3>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCopyAnalysis}
                      leftIcon={copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    >
                      {copied ? 'Copied' : 'Copy Audit'}
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handleSaveResult}
                      leftIcon={saved ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
                    >
                      {saved ? 'Saved' : 'Save'}
                    </Button>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed mb-4">
                  {result.performanceObservations}
                </p>

                {/* Reach vs Retention */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-lg bg-indigo-50/60 border border-indigo-100 text-indigo-950">
                    <strong className="font-semibold text-indigo-900 block mb-1">Discovery & Reach Signals:</strong>
                    <p className="leading-relaxed">{result.reachObservations}</p>
                  </div>
                  <div className="p-3.5 rounded-lg bg-emerald-50/60 border border-emerald-100 text-emerald-950">
                    <strong className="font-semibold text-emerald-900 block mb-1">Watch Time & Retention:</strong>
                    <p className="leading-relaxed">{result.retentionObservations}</p>
                  </div>
                </div>
              </Card>

              {/* Strengths & Weaknesses */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card className="p-5 bg-white border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full inline-block mb-3">
                    Identified Strengths
                  </span>
                  <ul className="space-y-2 text-xs text-slate-600">
                    {result.possibleStrengths.map((str, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{str}</span>
                      </li>
                    ))}
                  </ul>
                </Card>

                <Card className="p-5 bg-white border border-slate-200 shadow-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full inline-block mb-3">
                    Friction Points to Fix
                  </span>
                  <ul className="space-y-2 text-xs text-slate-600">
                    {result.possibleWeaknesses.map((weak, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" />
                        <span>{weak}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>

              {/* 3 Practical Suggestions */}
              <Card className="p-5 sm:p-6 bg-slate-900 text-white shadow-xs rounded-xl">
                <div className="flex items-center gap-2 mb-3">
                  <Lightbulb className="h-4 w-4 text-amber-400" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-amber-300">
                    3 Practical Adjustments for Next Video
                  </h3>
                </div>

                <div className="space-y-2.5">
                  {result.practicalSuggestions.map((sug, i) => (
                    <div key={i} className="p-3 rounded-lg bg-white/10 border border-white/10 flex items-start gap-3 text-xs leading-relaxed">
                      <span className="h-5 w-5 rounded-full bg-amber-400 text-slate-900 font-bold text-center shrink-0 flex items-center justify-center text-[11px]">
                        {i + 1}
                      </span>
                      <p className="text-slate-100">{sug}</p>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Next Video Recommendations */}
              <Card className="p-5 bg-white border border-slate-200 shadow-xs">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-3">
                  Follow-Up Video Concepts (Next-in-Sequence)
                </h3>
                <div className="space-y-2">
                  {result.nextVideoRecommendations.map((rec, i) => (
                    <div key={i} className="p-3 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-700">
                      <span className="font-bold text-indigo-600 mr-2">Idea #{i + 1}:</span>
                      {rec}
                    </div>
                  ))}
                </div>
              </Card>

              {/* Banner Ad */}
              <div className="pt-4 flex justify-center">
                <AdBanner size="468x60" />
              </div>
            </div>
          ) : (
            <Card className="p-12 text-center bg-white border-dashed">
              <div className="h-12 w-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3">
                <Activity className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No Video Audited Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-5">
                Input your view, like, and watch time statistics on the left to audit retention drops and compute diagnostic ratios.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleDiagnose()}
                leftIcon={<Sparkles className="h-3.5 w-3.5" />}
              >
                Audit Sample Metrics
              </Button>
            </Card>
          )}

          {/* Smartlink promo */}
          <SmartlinkPromo
            variant="card"
            title="Video Analytics & Editing Tools"
            description="Access exclusive creator discounts for auto-captions, audio cleanup, and A/B thumbnail testing."
          />
        </div>
      </div>

      {/* Comprehensive Editorial & Strategy Guide */}
      <div className="mt-16 space-y-12">
        {/* Mathematical Ratio Formulas & Benchmarks */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <BarChart3 className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              Key Short-Form Video Retention &amp; Performance Formulas
            </h2>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed mb-6">
            Raw views are a vanity metric heavily influenced by previous subscriber counts or random feed distribution. Sustainable audience growth is determined by algorithmic retention ratios.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Ratio 1</span>
                <span className="text-xs px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold">Target: 6% - 10%</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Like-to-View Ratio</h3>
              <p className="font-mono text-xs text-indigo-700 bg-white p-2 rounded border border-indigo-100 mb-2">
                (Likes ÷ Views) × 100
              </p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Measures instant emotional or practical resonance. Below 4% signals weak delivery; above 9% indicates strong community appreciation.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Ratio 2</span>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">Target: 0.3% - 0.8%</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Comment-to-View Ratio</h3>
              <p className="font-mono text-xs text-emerald-700 bg-white p-2 rounded border border-emerald-100 mb-2">
                (Comments ÷ Views) × 100
              </p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Evaluates discussion triggers and debate potential. Comments keep the video playing in the background, significantly boosting dwell time.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200/70">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Ratio 3</span>
                <span className="text-xs px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-semibold">Target: &gt; 0.5%</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Share-to-View Ratio</h3>
              <p className="font-mono text-xs text-rose-700 bg-white p-2 rounded border border-rose-100 mb-2">
                (Shares ÷ Views) × 100
              </p>
              <p className="text-xs text-slate-600 leading-relaxed">
                The single most powerful algorithmic multiplier. Shares signal to recommendation engines that the content is so valuable it warrants private referral.
              </p>
            </div>
          </div>
        </section>

        {/* Real-World Audit Scenario */}
        <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <TrendingUp className="h-5 w-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">
              Real-World Diagnostic Audit Scenario
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
            Reviewing an actual creator video audit demonstrating how engagement ratios diagnose distribution bottlenecks.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm">
            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <h4 className="font-bold text-indigo-400 uppercase tracking-wider text-xs">Video Performance Inputs</h4>
              <div>
                <span className="text-slate-400 block text-xs">Topic &amp; Platform:</span>
                <span className="font-semibold text-white">"3-Minute Freelance Invoice Setup" (Shorts/TikTok)</span>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Audit Data:</span>
                <span className="text-slate-200">18,500 Views • 1,240 Likes (6.7%) • 45 Comments (0.24%) • 215 Shares (1.16%) • 64% Avg Watch Time</span>
              </div>
            </div>

            <div className="space-y-4 bg-slate-800/80 p-5 rounded-xl border border-slate-700">
              <h4 className="font-bold text-emerald-400 uppercase tracking-wider text-xs">Doctor Diagnostic &amp; Prescription</h4>
              <div>
                <span className="text-slate-400 block text-xs">Diagnostic Assessment:</span>
                <p className="text-slate-300 text-xs">Shares (1.16%) and Like ratio (6.7%) are exceptionally strong, confirming high viewer utility. However, comments (0.24%) are under the 0.4% healthy threshold.</p>
              </div>
              <div>
                <span className="text-slate-400 block text-xs">Corrective Action for Next Upload:</span>
                <p className="text-emerald-400 text-xs font-semibold">Introduce an open-ended debate prompt at second 30: "Do you charge 50% upfront or 100% upfront on small gigs? Let me know below." This activates the comment feed to multiply session time.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Operational Limitations */}
        <section className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-6 sm:p-8 text-amber-950">
          <div className="flex items-center gap-2.5 mb-3">
            <Lightbulb className="h-5 w-5 text-amber-600 shrink-0" />
            <h2 className="text-lg sm:text-xl font-bold text-amber-900">
              Operational Limitations &amp; Benchmarking Advice
            </h2>
          </div>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90 mb-3">
            <strong>Platform Metric Variance:</strong> Each social media platform registers views and watch percentages differently. For example, YouTube Shorts considers a view after a few seconds of watch time, while TikTok registers views instantly upon play. Treat ratio benchmarks as comparative diagnostic heuristics rather than universal constants.
          </p>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90">
            <strong>Sample Size Notice:</strong> Never draw definitive conclusions from a single video upload. Test creative and pacing adjustments across at least 3 to 5 uploads before concluding whether an editing change succeeded.
          </p>
        </section>

        {/* FAQ Accordion */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2.5 mb-6">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                Frequently Asked Questions
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Answers to common questions about short-form video diagnostics, engagement ratios, and viewer drop-offs.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={index}
                  className="rounded-xl border border-slate-200/80 overflow-hidden transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => toggleFaq(index)}
                    className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-semibold text-slate-900">
                      {item.question}
                    </span>
                    <span className="text-slate-400 shrink-0">
                      {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="p-4 sm:p-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed bg-white border-t border-slate-100">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Related Creator Growth Utilities */}
        <section className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Layers className="h-4 w-4 text-indigo-600" />
            Related Creator Workflow Tools
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a
              href="/tools/creator/hook-doctor"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/hook-doctor');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-rose-600 transition-colors">
                  Hook Doctor
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-rose-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Improve opening 3-second retention and cut swipe-away percentages.
              </p>
            </a>

            <a
              href="/tools/engagement-calculator"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/engagement-calculator');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors">
                  Engagement Rate Calculator
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                Benchmark overall account engagement percentage against industry averages.
              </p>
            </a>

            <a
              href="/tools/creator/content-experiment-generator"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/tools/creator/content-experiment-generator');
                }
              }}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50 transition-all group block cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold text-sm text-slate-900 group-hover:text-emerald-600 transition-colors">
                  Content Experiment Generator
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-0.5" />
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">
                A/B test 3 different narrative structures for your next video upload.
              </p>
            </a>
          </div>
        </section>
      </div>
    </div>
  );
};
