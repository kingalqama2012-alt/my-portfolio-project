import React, { useState, useMemo, useEffect } from 'react';
import { FreelancerRateFormData } from '../../types';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Card } from '../../components/common/Card';
import { StatCard } from '../../components/common/StatCard';
import { Badge } from '../../components/common/Badge';
import {
  Calculator,
  DollarSign,
  Clock,
  Briefcase,
  Bookmark,
  ArrowLeft,
  Info,
  Check,
  TrendingUp,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Lightbulb,
  FileText,
  Target,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Layers,
  Scale,
} from 'lucide-react';
import { AdBanner } from '../../components/ads';

interface FreelancerRateCalculatorPageProps {
  onNavigate: (path: string) => void;
}

export const FreelancerRateCalculatorPage: React.FC<FreelancerRateCalculatorPageProps> = ({
  onNavigate,
}) => {
  const { currency, saveResult } = useApp();

  const [formData, setFormData] = useState<FreelancerRateFormData>({
    desiredIncome: 6500,
    hoursPerWeek: 30,
    weeksPerMonth: 4,
    businessExpenses: 800,
    taxPercentage: 25,
  });

  const [saved, setSaved] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'How do I calculate my freelance hourly rate?',
      answer:
        'To calculate your freelance hourly rate, add your target take-home income to your ongoing business expenses. Then divide that total by (1 - your estimated tax percentage) to establish your required gross monthly revenue. Finally, divide your gross revenue by your realistic monthly billable hours. ToolFlow’s freelance hourly rate calculator automates this entire formula in real time.',
    },
    {
      question: 'What should a freelancer charge per hour?',
      answer:
        'What a freelancer should charge depends on their experience level, technical skills, market demand, business overhead, and tax responsibilities. Rather than guessing an arbitrary number or matching full-time employee salaries, calculate your minimum acceptable hourly rate based on personal financial goals and non-billable overhead.',
    },
    {
      question: 'Should I include business expenses in my rate?',
      answer:
        'Yes, absolutely. Software subscriptions, laptop hardware, high-speed internet, accounting fees, health insurance, and workspace costs must be funded directly from your gross revenue. Omitting operating expenses from your hourly rate calculator means those costs directly decrease your personal take-home pay.',
    },
    {
      question: 'How do taxes affect my freelance rate?',
      answer:
        'Unlike traditional payroll employees whose employers cover half of social security and Medicare contributions, independent freelancers bear the full responsibility for self-employment tax in addition to standard income taxes. Calculating rates on a pre-tax gross basis ensures you set aside necessary tax funds without falling short on your take-home goals.',
    },
    {
      question: 'What are billable hours?',
      answer:
        'Billable hours represent the direct time spent producing deliverables for paying clients that you can invoice. Non-billable hours include administrative tasks such as answering client emails, drafting proposals, issuing invoices, and prospecting for new leads. Most full-time freelancers log between 20 and 30 billable hours in a typical 40-hour workweek.',
    },
    {
      question: 'Is hourly or project-based pricing better?',
      answer:
        'Hourly pricing is best suited for consulting, discovery phases, and projects with open-ended or evolving scopes where client requirements may shift. Project-based (fixed) pricing is superior when deliverables are clearly defined, allowing you to charge for the overall value created rather than trading time for money. Your calculated hourly rate serves as the baseline for estimating fixed project bids.',
    },
    {
      question: 'Can beginners use a freelancer rate calculator?',
      answer:
        'Yes, beginner freelancers should use a rate calculator before submitting their very first client pitch. New freelancers often undercharge because they overlook self-employment taxes, software expenses, and unpaid administrative hours. Using a calculator provides an accurate, sustainable foundation from day one.',
    },
  ];

  // Technical SEO & Structured Data
  useEffect(() => {
    const previousTitle = document.title;
    document.title = 'Freelancer Rate Calculator – Calculate Your Hourly Rate | ToolFlow';

    // Unique Meta Description (159 characters targeting primary keywords)
    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    const newDesc =
      "Use ToolFlow's free freelancer rate calculator and hourly rate calculator to calculate freelance rates, expenses, and taxes. Find your true freelance hourly rate.";

    if (metaDesc) {
      metaDesc.setAttribute('content', newDesc);
    } else {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      metaDesc.setAttribute('content', newDesc);
      document.head.appendChild(metaDesc);
    }

    // Canonical URL pointing to published URL
    const canonicalHref =
      'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/tools/freelancer-rate-calculator';
    let canonical = document.querySelector('link[rel="canonical"]');
    const prevCanonical = canonical ? canonical.getAttribute('href') : null;
    if (canonical) {
      canonical.setAttribute('href', canonicalHref);
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      canonical.setAttribute('href', canonicalHref);
      document.head.appendChild(canonical);
    }

    // OpenGraph & Twitter tags
    let ogTitle = document.querySelector('meta[property="og:title"]');
    const prevOgTitle = ogTitle ? ogTitle.getAttribute('content') : '';
    if (ogTitle) ogTitle.setAttribute('content', 'Freelancer Rate Calculator – Calculate Your Hourly Rate | ToolFlow');

    let ogDesc = document.querySelector('meta[property="og:description"]');
    const prevOgDesc = ogDesc ? ogDesc.getAttribute('content') : '';
    if (ogDesc) ogDesc.setAttribute('content', newDesc);

    // Robots meta tag to ensure search engine indexing
    let robotsMeta = document.querySelector('meta[name="robots"]');
    const prevRobots = robotsMeta ? robotsMeta.getAttribute('content') : '';
    if (robotsMeta) {
      robotsMeta.setAttribute('content', 'index, follow');
    } else {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      robotsMeta.setAttribute('content', 'index, follow');
      document.head.appendChild(robotsMeta);
    }

    // Schema.org JSON-LD Structured Data
    const scriptId = 'freelancer-rate-calculator-schema';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }

    const structuredData = [
      {
        '@context': 'https://schema.org',
        '@type': 'WebApplication',
        name: 'Freelancer Rate Calculator',
        applicationCategory: 'BusinessApplication',
        operatingSystem: 'All',
        url: canonicalHref,
        description: newDesc,
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'USD',
        },
      },
      {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqItems.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      },
    ];

    script.text = JSON.stringify(structuredData);

    return () => {
      document.title = previousTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      if (ogTitle && prevOgTitle) ogTitle.setAttribute('content', prevOgTitle);
      if (ogDesc && prevOgDesc) ogDesc.setAttribute('content', prevOgDesc);
      if (canonical && prevCanonical) {
        canonical.setAttribute('href', prevCanonical);
      } else if (canonical && !prevCanonical) {
        canonical.remove();
      }
      if (robotsMeta && prevRobots) {
        robotsMeta.setAttribute('content', prevRobots);
      } else if (robotsMeta && !prevRobots) {
        robotsMeta.remove();
      }
      const existingScript = document.getElementById(scriptId);
      if (existingScript) existingScript.remove();
    };
  }, []);

  // Real-time calculation logic
  const calculations = useMemo(() => {
    const netDesired = Number(formData.desiredIncome) || 0;
    const expMonthly = Number(formData.businessExpenses) || 0;
    const taxRate = (Number(formData.taxPercentage) || 0) / 100;
    const hrsPerWeek = Number(formData.hoursPerWeek) || 1;
    const wksPerMonth = Number(formData.weeksPerMonth) || 1;

    // Gross target monthly = (Net + Expenses) / (1 - TaxRate)
    const divisor = 1 - taxRate;
    const grossMonthly = divisor > 0 ? (netDesired + expMonthly) / divisor : netDesired + expMonthly;
    const grossYearly = grossMonthly * 12;

    // Billable hours
    const billableHoursMonthly = hrsPerWeek * wksPerMonth;
    const billableHoursYearly = billableHoursMonthly * 12;

    // Hourly rate needed
    const hourlyRate = billableHoursMonthly > 0 ? grossMonthly / billableHoursMonthly : 0;

    // Taxes & expenses
    const yearlyTaxes = grossYearly * taxRate;
    const yearlyExpenses = expMonthly * 12;
    const takeHomeYearly = netDesired * 12;

    return {
      hourlyRate: Math.ceil(hourlyRate * 100) / 100,
      monthlyRevenue: Math.round(grossMonthly),
      yearlyRevenue: Math.round(grossYearly),
      billableHoursMonthly,
      billableHoursYearly,
      yearlyTaxes: Math.round(yearlyTaxes),
      yearlyExpenses: Math.round(yearlyExpenses),
      takeHomeYearly: Math.round(takeHomeYearly),
    };
  }, [formData]);

  const handleSave = () => {
    saveResult({
      toolId: 'freelancer-rate-calculator',
      toolName: 'Freelancer Rate Calculator',
      category: 'freelancer',
      title: `Hourly Rate Calculation: ${currency}${calculations.hourlyRate}/hr`,
      preview: `Target: ${currency}${formData.desiredIncome}/mo net | Gross: ${currency}${calculations.monthlyRevenue}/mo | Rate: ${currency}${calculations.hourlyRate}/hr`,
      content: `Target Net Income: ${currency}${formData.desiredIncome}/mo\nRecommended Hourly Rate: ${currency}${calculations.hourlyRate}/hr\nEstimated Monthly Gross: ${currency}${calculations.monthlyRevenue}\nEstimated Yearly Revenue: ${currency}${calculations.yearlyRevenue}\nBillable Hours: ${formData.hoursPerWeek} hrs/week (~${calculations.billableHoursMonthly} hrs/mo)\nEstimated Yearly Taxes: ${currency}${calculations.yearlyTaxes} (${formData.taxPercentage}%)\nEstimated Yearly Expenses: ${currency}${calculations.yearlyExpenses}`,
      data: {
        ...formData,
        ...calculations,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Top Header */}
      <div className="mb-6">
        <a
          href="/tools"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools');
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors mb-3 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Tools Directory
        </a>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="indigo">Freelancer Tools</Badge>
              <Badge variant="emerald">Financial Utility</Badge>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Freelancer Rate Calculator
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Determine the exact billable hourly rate needed to achieve your take-home goals after taxes and software expenses.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSave}
            leftIcon={saved ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Bookmark className="h-3.5 w-3.5" />}
          >
            {saved ? 'Calculation Saved' : 'Save Calculation'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Input Form */}
        <div className="lg:col-span-5">
          <Card className="p-5 sm:p-6 bg-white shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-5 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Calculator className="h-4 w-4 text-indigo-600" />
              Financial Inputs
            </h2>

            <div className="space-y-4">
              <Input
                label="Desired Monthly Take-Home Income"
                type="number"
                min="0"
                step="100"
                leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                value={formData.desiredIncome}
                onChange={(e) => setFormData({ ...formData, desiredIncome: parseFloat(e.target.value) || 0 })}
                helperText="Your target clean in-pocket money each month."
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  label="Billable Hours / Week"
                  type="number"
                  min="1"
                  max="80"
                  value={formData.hoursPerWeek}
                  onChange={(e) => setFormData({ ...formData, hoursPerWeek: parseFloat(e.target.value) || 0 })}
                  helperText="Exclude admin & marketing."
                />

                <Input
                  label="Working Weeks / Month"
                  type="number"
                  min="1"
                  max="4.5"
                  step="0.1"
                  value={formData.weeksPerMonth}
                  onChange={(e) => setFormData({ ...formData, weeksPerMonth: parseFloat(e.target.value) || 0 })}
                  helperText="Average ~4 weeks."
                />
              </div>

              <Input
                label="Monthly Business Expenses"
                type="number"
                min="0"
                step="50"
                leftPrefix={<span className="text-xs font-bold text-slate-500">{currency}</span>}
                value={formData.businessExpenses}
                onChange={(e) => setFormData({ ...formData, businessExpenses: parseFloat(e.target.value) || 0 })}
                helperText="Software, hardware, insurance, co-working, etc."
              />

              <Input
                label="Taxes & Self-Employment Set-Aside (%)"
                type="number"
                min="0"
                max="60"
                rightSuffix="%"
                value={formData.taxPercentage}
                onChange={(e) => setFormData({ ...formData, taxPercentage: parseFloat(e.target.value) || 0 })}
                helperText="Typical self-employment tax allowance is 20% - 30%."
              />
            </div>
          </Card>
        </div>

        {/* Results & Statistical Cards */}
        <div className="lg:col-span-7 space-y-6">
          {/* Primary Recommended Rate Highlight Card */}
          <div className="rounded-xl border border-indigo-200 bg-gradient-to-br from-indigo-50/80 via-white to-indigo-50/30 p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-100/70 px-2 py-0.5 rounded">
                  Recommended Baseline
                </span>
                <p className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2 font-mono">
                  {currency}{calculations.hourlyRate.toFixed(2)}
                  <span className="text-base font-normal text-slate-500"> / hour</span>
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  Based on {formData.hoursPerWeek} billable hours/week ({calculations.billableHoursMonthly} hrs/mo)
                </p>
              </div>

              <div className="text-left sm:text-right">
                <span className="text-xs text-slate-500">Minimum Project Rate</span>
                <p className="text-lg font-bold text-slate-900 font-mono">
                  {currency}{(calculations.hourlyRate * 10).toFixed(0)} <span className="text-xs font-normal text-slate-500">/ 10-hr sprint</span>
                </p>
              </div>
            </div>
          </div>

          {/* Secondary Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <StatCard
              label="Estimated Monthly Revenue"
              value={`${currency}${calculations.monthlyRevenue.toLocaleString()}`}
              subtext="Total gross billing needed"
              icon={<DollarSign className="h-5 w-5" />}
              variant="highlight"
            />
            <StatCard
              label="Estimated Yearly Revenue"
              value={`${currency}${calculations.yearlyRevenue.toLocaleString()}`}
              subtext="Annualized business turnover"
              icon={<TrendingUp className="h-5 w-5" />}
            />
          </div>

          {/* Detailed Breakdown Card */}
          <Card className="p-6 bg-white">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-4">
              Annual Revenue Breakdown
            </h3>

            {/* Visual Bar */}
            <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex mb-4">
              <div
                style={{ width: `${(calculations.takeHomeYearly / (calculations.yearlyRevenue || 1)) * 100}%` }}
                className="bg-emerald-500 h-full"
                title="Take-home pay"
              />
              <div
                style={{ width: `${(calculations.yearlyTaxes / (calculations.yearlyRevenue || 1)) * 100}%` }}
                className="bg-amber-400 h-full"
                title="Taxes"
              />
              <div
                style={{ width: `${(calculations.yearlyExpenses / (calculations.yearlyRevenue || 1)) * 100}%` }}
                className="bg-indigo-400 h-full"
                title="Expenses"
              />
            </div>

            {/* Legend & Numbers */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-sm bg-emerald-500 shrink-0" />
                <div>
                  <span className="text-slate-500">Take-Home:</span>{' '}
                  <strong className="text-slate-800 font-mono">{currency}{calculations.takeHomeYearly.toLocaleString()}</strong>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-sm bg-amber-400 shrink-0" />
                <div>
                  <span className="text-slate-500">Taxes ({formData.taxPercentage}%):</span>{' '}
                  <strong className="text-slate-800 font-mono">{currency}{calculations.yearlyTaxes.toLocaleString()}</strong>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-sm bg-indigo-400 shrink-0" />
                <div>
                  <span className="text-slate-500">Expenses:</span>{' '}
                  <strong className="text-slate-800 font-mono">{currency}{calculations.yearlyExpenses.toLocaleString()}</strong>
                </div>
              </div>
            </div>
          </Card>

          {/* Explanation Box */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-600 leading-relaxed">
            <div className="flex items-start gap-2.5">
              <Info className="h-4 w-4 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-800 font-semibold block mb-0.5">
                  How This Calculation Works
                </strong>
                Unlike salaried employees, freelancers bear the full burden of self-employment taxes, healthcare, software subscriptions, unbillable marketing, and client revisions. The formula calculates your required gross monthly earnings:
                <code className="mx-1 px-1.5 py-0.5 bg-white border border-slate-200 rounded font-mono text-slate-800">
                  Gross = (Net Income + Expenses) / (1 - TaxRate)
                </code>
                and divides it across your realistic billable hours.
              </div>
            </div>
          </div>

          {/* Adsterra Standard Banner 468x60 (ID: 31491252) */}
          <div className="flex justify-center pt-2">
            <AdBanner size="468x60" />
          </div>
        </div>
      </div>

      {/* SEO & Educational Guide Section */}
      <section className="mt-16 pt-12 border-t border-slate-200/80 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-semibold mb-3 border border-emerald-100">
            <Lightbulb className="h-3.5 w-3.5 text-emerald-600" />
            <span>Freelance Pricing Guide</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            How to Calculate Your True Freelance Hourly Rate
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Discover how to use a freelance rate calculator to price your services profitably, account for business expenses and self-employment taxes, and protect your take-home income.
          </p>
        </div>

        {/* 3 Core Conceptual Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 font-bold">
              <Calculator className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              What a Freelancer Rate Calculator Does
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              A <strong>freelancer rate calculator</strong> is an essential financial planning utility that determines the exact hourly rate you must charge clients to reach your target take-home income. Instead of guessing numbers or copying competitors, it models your overhead, tax obligations, and non-billable hours.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4 font-bold">
              <Scale className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              Why Calculate Your True Hourly Rate?
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Full-time employees receive employer-paid payroll taxes, paid time off, health insurance, and workplace hardware. Independent freelancers must fund every operational cost themselves. Calculating your true <strong>freelance hourly rate</strong> protects you from accidental undercharging and career burnout.
            </p>
          </Card>

          <Card className="p-6 bg-white border border-slate-200/80 hover:border-slate-300 transition-colors shadow-xs">
            <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4 font-bold">
              <Clock className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">
              Why Billable Hours Matter
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              In freelance business, working 40 hours a week does not mean billing 40 hours. Administrative work, client emails, project proposals, and marketing are non-billable. Most successful freelancers log 20 to 30 billable hours per week, meaning your billable hours must cover all operating costs.
            </p>
          </Card>
        </div>

        {/* Detailed Breakdown: Taxes, Expenses & Step-by-Step Guide */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80 space-y-6">
          <div className="max-w-3xl">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
              Financial Foundations
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              How Expenses and Taxes Impact Freelance Pricing
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Understanding the mathematical relationship between gross revenue, business overhead, and net personal income is the cornerstone of sustainable freelancing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 shrink-0 mt-0.5">
                  <DollarSign className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    Accounting for Business Expenses
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Software licenses (Figma, Adobe Creative Cloud, IDEs), high-speed fiber internet, web hosting, accounting software, and professional equipment are mandatory expenses. If your monthly expenses total $800, that amount must be added directly to your required gross revenue before calculating your hourly billable rate.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200/70">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600 shrink-0 mt-0.5">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    Handling Self-Employment Taxes
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Unlike standard W-2 employees where the employer pays half of social security and Medicare, self-employed professionals pay both halves. ToolFlow uses the formula <code>Gross = (Net + Expenses) / (1 - TaxRate)</code> to ensure taxes are factored into your gross target before you quote clients.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* How to use the calculator */}
          <div className="p-5 rounded-xl bg-white border border-slate-200/70 mt-4">
            <h4 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              How to Use the ToolFlow Rate Calculator (5 Easy Steps)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">1. Desired Net Income</span>
                <span className="text-slate-500">Enter your target monthly take-home pay after all personal expenses.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">2. Billable Hours</span>
                <span className="text-slate-500">Input your weekly billable hours, excluding unbillable admin tasks.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">3. Weeks Worked</span>
                <span className="text-slate-500">Select active working weeks per month (typically 4 weeks).</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">4. Business Expenses</span>
                <span className="text-slate-500">Add up recurring monthly tool, software, and hardware costs.</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                <span className="font-bold text-slate-900 block mb-1">5. Tax Percentage</span>
                <span className="text-slate-500">Set your estimated self-employment and income tax bracket.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Pricing Models Comparison Section */}
        <div>
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Hourly vs. Daily vs. Project-Based Pricing
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5">
              Knowing how to structure your freelance pricing determines your long-term earning potential and client satisfaction:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Hourly Rate */}
            <Card className="p-6 bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
                  <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                    <Clock className="h-4 w-4" />
                  </div>
                  <h4 className="text-base font-bold text-slate-900">Hourly Pricing</h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  You bill clients for the precise hours logged. Best for technical troubleshooting, consulting, ongoing support, and projects with unpredictable or shifting scopes.
                </p>
                <div className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
                  <div className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span>Guarantees payment for all hours worked</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span>Low risk when client scope expands</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <span className="text-slate-400 font-bold">•</span>
                    <span className="text-slate-500">Penalizes speed and efficiency</span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Daily / Weekly Rates */}
            <Card className="p-6 bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
                  <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                    <Layers className="h-4 w-4" />
                  </div>
                  <h4 className="text-base font-bold text-slate-900">Daily / Weekly Retainers</h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  Clients reserve dedicated blocks of your time (e.g. 2 days per week or monthly retainers). Best for embedded contractors, fractional roles, and design sprints.
                </p>
                <div className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
                  <div className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span>Predictable recurring cash flow</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span>Eliminates tedious minute-by-minute time tracking</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <span className="text-slate-400 font-bold">•</span>
                    <span className="text-slate-500">Requires strict availability boundaries</span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Project-Based Pricing */}
            <Card className="p-6 bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
                  <div className="p-1.5 rounded-lg bg-purple-50 text-purple-600">
                    <Target className="h-4 w-4" />
                  </div>
                  <h4 className="text-base font-bold text-slate-900">Project-Based (Value)</h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  You quote a flat price based on agreed-upon deliverables and business value. Best for branding packages, website redesigns, and custom software builds.
                </p>
                <div className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
                  <div className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span>Rewards expertise, automation, and speed</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span>Aligns pricing with business outcomes</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <span className="text-slate-400 font-bold">•</span>
                    <span className="text-slate-500">Requires airtight milestone agreements</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Frequently Asked Questions
              </h3>
              <p className="text-xs sm:text-sm text-slate-500">
                Common questions about calculating hourly rates and managing freelance pricing.
              </p>
            </div>
          </div>

          <div className="mt-6 divide-y divide-slate-100">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={index} className="py-4 first:pt-0 last:pb-0">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between text-left gap-4 group cursor-pointer focus:outline-none"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                      {item.question}
                    </span>
                    <span className="p-1 rounded-md text-slate-400 group-hover:text-emerald-600 shrink-0">
                      {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="mt-2.5 pr-8 text-xs sm:text-sm text-slate-600 leading-relaxed font-sans animate-in fade-in duration-200">
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Internal Links Directory */}
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-50/80 border border-slate-200/80">
          <div className="mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Explore More Tools
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
              Productivity & Business Calculators on ToolFlow
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Streamline your freelance workflow, e-commerce store, and content campaigns with our full suite of free tools:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Proposal Generator */}
            <a
              href="/tools/proposal-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/proposal-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                  <FileText className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                AI Proposal Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Generate tailored, high-converting client proposals for Upwork, Fiverr, and direct contracts based on your target hourly rate.
              </p>
            </a>

            {/* Social Caption Generator */}
            <a
              href="/tools/social-caption-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/social-caption-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-pink-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-pink-50 text-pink-600">
                  <Sparkles className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-pink-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-pink-600 transition-colors">
                Social Caption Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Create engaging social media captions, viral hooks, and hashtag recommendations for client campaigns and creator branding.
              </p>
            </a>

            {/* Amazon Profit Calculator */}
            <a
              href="/tools/amazon-profit-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-profit-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-amber-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
                  <DollarSign className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-amber-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                Amazon Profit Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Calculate net profit margins, Amazon FBA fulfillment fees, and return on investment for e-commerce product portfolios.
              </p>
            </a>

            {/* Amazon PPC Calculator */}
            <a
              href="/tools/amazon-ppc-calculator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-ppc-calculator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-blue-400 hover:shadow-xs transition-all group block"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
                  <TrendingUp className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                Amazon PPC Calculator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Optimize advertising campaigns, analyze break-even ACoS, and compute maximum recommended cost-per-click bids.
              </p>
            </a>

            {/* Amazon Keyword Generator */}
            <a
              href="/tools/amazon-keyword-generator"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools/amazon-keyword-generator');
              }}
              className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-emerald-400 hover:shadow-xs transition-all group block sm:col-span-2 lg:col-span-1"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                  <Target className="h-4 w-4" />
                </span>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                Amazon Keyword Generator
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Generate high-search-intent keywords, backend search terms, and PPC target phrases for marketplace product listings.
              </p>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
