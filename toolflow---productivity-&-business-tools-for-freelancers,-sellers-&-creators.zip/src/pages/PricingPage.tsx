import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/common/Button';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { usePageSEO } from '../utils/usePageSEO';
import {
  Check,
  Sparkles,
  HelpCircle,
  CreditCard,
  Lock,
  ArrowRight,
  Shield,
  Layers,
} from 'lucide-react';

interface PricingPageProps {
  onNavigate: (path: string) => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Pricing & Plans – Free & Pro ToolSuite | ToolFlow',
    description:
      'Explore ToolFlow pricing plans. Start free with essential business calculators or upgrade to Pro for higher AI allowances, cloud sync, and advanced seller exports.',
    canonicalPath: '/pricing',
    robots: 'index, follow',
  });

  const { brandName, currency, addToast } = useApp();
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedPlanModal, setSelectedPlanModal] = useState<string | null>(null);

  const plans = [
    {
      id: 'free',
      name: 'Free',
      tagline: 'Essential calculators and basic tools for getting started.',
      priceMonthly: 0,
      priceYearly: 0,
      badge: 'Starter',
      popular: false,
      features: [
        'Access to all standard business calculators',
        'Up to 10 AI generations per month',
        'Save up to 5 results in local workspace',
        'Standard community support',
        'Single user account',
      ],
      ctaText: 'Current Plan',
      variant: 'outline' as const,
    },
    {
      id: 'pro',
      name: 'Pro',
      tagline: 'Complete toolsuite for solo operators, active sellers & creators.',
      priceMonthly: 19,
      priceYearly: 15, // $180 billed annually (~$15/mo)
      badge: 'Most Popular',
      popular: true,
      features: [
        'All Free tier features',
        'Up to 250 high-priority AI generations/mo',
        'Unlimited saved results & cloud sync ready',
        'Full Amazon FBA & PPC diagnostic exports',
        'CSV keyword & caption batch downloads',
        'Priority email & product updates',
      ],
      ctaText: 'Upgrade to Pro',
      variant: 'primary' as const,
    },
    {
      id: 'business',
      name: 'Business',
      tagline: 'Higher limits and collaborative tooling for agencies & brand teams.',
      priceMonthly: 49,
      priceYearly: 39, // $468 billed annually (~$39/mo)
      badge: 'Scale',
      popular: false,
      features: [
        'All Pro tier features',
        'Up to 1,000 AI generations per month',
        'Shared workspace with up to 5 team members',
        'Custom brand presets and custom formulas',
        'Dedicated onboarding & account support',
        'Early access to beta integrations',
      ],
      ctaText: 'Get Business',
      variant: 'outline' as const,
    },
  ];

  const handlePlanClick = (planName: string) => {
    setSelectedPlanModal(planName);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
          Transparent Pricing
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mt-3 mb-4">
          Simple, Predictable Plans for Growing Businesses
        </h1>
        <p className="text-base text-slate-600 max-w-xl mx-auto">
          Start for free, then upgrade as your volume grows. Realistic limits designed for sustainable, production-grade usage.
        </p>

        {/* Billing Toggle */}
        <div className="mt-8 inline-flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200">
          <button
            onClick={() => setBillingPeriod('monthly')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              billingPeriod === 'monthly'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Monthly Billing
          </button>
          <button
            onClick={() => setBillingPeriod('yearly')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              billingPeriod === 'yearly'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Annual Billing</span>
            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800">
              Save 20%
            </span>
          </button>
        </div>
      </div>

      {/* Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto items-stretch mb-16">
        {plans.map((plan) => {
          const price = billingPeriod === 'monthly' ? plan.priceMonthly : plan.priceYearly;

          return (
            <Card
              key={plan.id}
              className={`p-6 sm:p-8 flex flex-col justify-between relative transition-all duration-200 ${
                plan.popular
                  ? 'border-indigo-600 ring-2 ring-indigo-600/20 shadow-md bg-white'
                  : 'bg-white border-slate-200 shadow-xs'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-slate-900">{plan.name}</h3>
                  <Badge variant={plan.popular ? 'indigo' : 'slate'} size="sm">
                    {plan.badge}
                  </Badge>
                </div>

                <p className="text-xs text-slate-500 min-h-[36px] mb-6">
                  {plan.tagline}
                </p>

                <div className="mb-6 pb-6 border-b border-slate-100">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-mono">
                      {currency}{price}
                    </span>
                    <span className="text-xs text-slate-500">
                      / month {billingPeriod === 'yearly' && price > 0 && '(billed annually)'}
                    </span>
                  </div>
                  {price === 0 && (
                    <span className="text-[11px] text-emerald-600 font-semibold mt-1 inline-block">
                      Free forever, no credit card required
                    </span>
                  )}
                </div>

                <div className="space-y-3 mb-8">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Included Capabilities:
                  </p>
                  {plan.features.map((feat, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-xs text-slate-700">
                      <Check className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Button
                  variant={plan.variant}
                  size="md"
                  className="w-full font-semibold"
                  onClick={() => handlePlanClick(plan.name)}
                >
                  {plan.ctaText}
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* FAQ Section */}
      <div className="max-w-3xl mx-auto pt-12 border-t border-slate-200">
        <h2 className="text-xl font-bold text-slate-900 text-center mb-8">
          Frequently Asked Questions
        </h2>

        <div className="space-y-4 text-sm text-slate-600">
          <Card className="p-4 bg-white">
            <h4 className="font-bold text-slate-900 mb-1">Can I use the calculators for free?</h4>
            <p className="text-xs leading-relaxed text-slate-500">
              Yes, all essential financial calculators (Amazon Profit, Rate Calculator, PPC Calculator, and Engagement Rate) are free to use without requiring an account.
            </p>
          </Card>

          <Card className="p-4 bg-white">
            <h4 className="font-bold text-slate-900 mb-1">How are AI generations counted?</h4>
            <p className="text-xs leading-relaxed text-slate-500">
              Each generated proposal or set of platform-specific captions counts as 1 generation. We provide clear, predictable quotas rather than deceptive unlimited claims.
            </p>
          </Card>

          <Card className="p-4 bg-white">
            <h4 className="font-bold text-slate-900 mb-1">How will billing and payments work?</h4>
            <p className="text-xs leading-relaxed text-slate-500">
              We are currently in preview release. In production, payment processing will be handled via Stripe with secure customer portals, tax invoicing, and instant cancellation.
            </p>
          </Card>
        </div>
      </div>

      {/* Payment Gateway Readiness Modal */}
      {selectedPlanModal && (
        <Modal
          isOpen={!!selectedPlanModal}
          onClose={() => setSelectedPlanModal(null)}
          title={`${selectedPlanModal} Plan Checkout`}
          maxWidth="md"
        >
          <div className="space-y-4 text-sm text-slate-600">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-3">
              <CreditCard className="h-5 w-5 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-slate-900">Payment Architecture Ready</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  The application is configured for Stripe integration. In production, connecting your Stripe publishable keys in your environment variables activates live subscriptions and customer checkout sessions.
                </p>
              </div>
            </div>

            <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span>Selected Plan:</span>
                <strong className="text-slate-900">{selectedPlanModal}</strong>
              </div>
              <div className="flex justify-between">
                <span>Billing Frequency:</span>
                <span className="capitalize">{billingPeriod}</span>
              </div>
              <div className="flex justify-between border-t border-slate-100 pt-2">
                <span>Status:</span>
                <span className="text-emerald-700 font-semibold">Ready for Stripe webhook sync</span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedPlanModal(null)}
              >
                Close
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  addToast({
                    title: 'Subscription Simulated',
                    message: `Simulated subscription to ${selectedPlanModal} plan.`,
                    type: 'success',
                  });
                  setSelectedPlanModal(null);
                }}
              >
                Simulate Activation
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
