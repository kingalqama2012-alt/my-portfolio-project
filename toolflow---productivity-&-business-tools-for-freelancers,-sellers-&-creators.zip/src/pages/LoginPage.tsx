import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/common/Button';
import { Input } from '../components/common/Input';
import { Card } from '../components/common/Card';
import { Modal } from '../components/common/Modal';
import { usePageSEO } from '../utils/usePageSEO';
import {
  Layers,
  Lock,
  Mail,
  ArrowRight,
  ShieldAlert,
  Info,
  KeyRound,
  CheckCircle2,
} from 'lucide-react';

interface LoginPageProps {
  onNavigate: (path: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Sign In | ToolFlow',
    description: 'Sign in to access your ToolFlow workspace and saved calculator results.',
    canonicalPath: '/login',
    robots: 'noindex, nofollow',
  });

  const { brandName, login, addToast } = useApp();
  const [email, setEmail] = useState('alex.morgan@example.com');
  const [password, setPassword] = useState('password123');
  const [oauthModalProvider, setOauthModalProvider] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      addToast({
        title: 'Email Required',
        message: 'Please provide a valid email address.',
        type: 'error',
      });
      return;
    }

    login(email, 'Alex Morgan');
    onNavigate('/dashboard');
  };

  const handleOauthClick = (provider: string) => {
    setOauthModalProvider(provider);
  };

  const handleQuickDemoLogin = () => {
    login('alex.demo@toolflow.dev', 'Alex Morgan (Demo)');
    onNavigate('/dashboard');
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <button
            onClick={() => onNavigate('/')}
            className="inline-flex items-center gap-2 mb-4 group cursor-pointer"
          >
            <div className="h-9 w-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs group-hover:bg-indigo-700 transition-colors">
              <Layers className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">{brandName}</span>
          </button>
          <h1 className="text-2xl font-extrabold text-slate-900">Welcome Back</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Sign in to access your tools and saved calculations.
          </p>
        </div>

        <Card className="p-6 sm:p-8 bg-white shadow-sm border-slate-200">
          {/* Quick Demo Access Bar */}
          <div className="p-3 bg-indigo-50/70 border border-indigo-200/60 rounded-lg mb-6 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-indigo-600 shrink-0" />
              <span className="text-xs text-indigo-900 font-medium">Test Mode Available</span>
            </div>
            <button
              onClick={handleQuickDemoLogin}
              className="text-xs font-bold text-indigo-700 hover:text-indigo-900 underline cursor-pointer"
            >
              1-Click Demo Sign In
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Email Address"
              type="email"
              placeholder="you@example.com"
              leftPrefix={<Mail className="h-4 w-4 text-slate-400" />}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                  Password
                </label>
                <a
                  href="#forgot"
                  onClick={(e) => {
                    e.preventDefault();
                    addToast({
                      title: 'Password Reset',
                      message: 'Password reset instructions sent to email (simulated).',
                      type: 'info',
                    });
                  }}
                  className="text-xs text-indigo-600 hover:underline"
                >
                  Forgot?
                </a>
              </div>
              <Input
                type="password"
                placeholder="••••••••"
                leftPrefix={<Lock className="h-4 w-4 text-slate-400" />}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <Button type="submit" variant="primary" size="md" className="w-full font-semibold">
              Sign In to Workspace
            </Button>
          </form>

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-slate-400 font-semibold">
                Or Continue With
              </span>
            </div>
          </div>

          {/* 3P OAuth Buttons (Config Ready) */}
          <div className="space-y-2">
            <button
              type="button"
              onClick={() => handleOauthClick('Google')}
              className="w-full flex items-center justify-center gap-2.5 px-4 py-2 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <svg className="h-4 w-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
              <span className="text-[10px] text-slate-400 font-mono">(Ready)</span>
            </button>

            <button
              type="button"
              onClick={() => handleOauthClick('Apple')}
              className="w-full flex items-center justify-center gap-2.5 px-4 py-2 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <svg className="h-4 w-4 fill-current text-slate-900" viewBox="0 0 24 24">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 5.1c.62-.75 1.04-1.8 0.93-2.85-.9.04-1.99.6-2.63 1.35-.56.65-1.06 1.71-.93 2.74 1 .08 2.01-.49 2.63-1.24z" />
              </svg>
              <span>Continue with Apple</span>
              <span className="text-[10px] text-slate-400 font-mono">(Ready)</span>
            </button>

            <button
              type="button"
              onClick={() => handleOauthClick('Facebook')}
              className="w-full flex items-center justify-center gap-2.5 px-4 py-2 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <svg className="h-4 w-4 fill-[#1877F2]" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              <span>Continue with Facebook</span>
              <span className="text-[10px] text-slate-400 font-mono">(Ready)</span>
            </button>
          </div>

          <div className="mt-6 text-center text-xs text-slate-500">
            Don't have an account?{' '}
            <button
              onClick={() => onNavigate('/signup')}
              className="text-indigo-600 font-semibold hover:underline cursor-pointer"
            >
              Create Account
            </button>
          </div>
        </Card>
      </div>

      {/* OAuth Configuration Dialog */}
      {oauthModalProvider && (
        <Modal
          isOpen={!!oauthModalProvider}
          onClose={() => setOauthModalProvider(null)}
          title={`${oauthModalProvider} OAuth Integration`}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs sm:text-sm text-slate-600">
            <div className="p-3.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-2.5">
              <ShieldAlert className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-xs uppercase tracking-wide">
                  Configuration Ready Mode
                </p>
                <p className="text-xs mt-1 leading-relaxed">
                  Real 3P OAuth credentials ({oauthModalProvider} Client ID & Secret) are not yet supplied in the environment. Per architectural guidelines, we do not fake successful OAuth logins.
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              To test the full authenticated user flow immediately, use the standard email sign-in or click "1-Click Demo Sign In".
            </p>

            <div className="flex justify-end gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setOauthModalProvider(null)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  setOauthModalProvider(null);
                  handleQuickDemoLogin();
                }}
              >
                Sign In with Demo User
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
