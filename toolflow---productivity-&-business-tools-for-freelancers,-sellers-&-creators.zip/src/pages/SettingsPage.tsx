import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Input } from '../components/common/Input';
import { Select } from '../components/common/Select';
import { Badge } from '../components/common/Badge';
import { usePageSEO } from '../utils/usePageSEO';
import {
  Settings,
  User,
  DollarSign,
  Palette,
  Shield,
  Key,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

interface SettingsPageProps {
  onNavigate: (path: string) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Account Settings | ToolFlow',
    description: 'Manage your ToolFlow user profile, default currency, and workspace preferences.',
    canonicalPath: '/settings',
    robots: 'noindex, nofollow',
  });

  const { user, currency, setCurrency, brandName, setBrandName, addToast } = useApp();

  const [userName, setUserName] = useState(user?.name || 'Alex Morgan');
  const [userEmail, setUserEmail] = useState(user?.email || 'alex@example.com');
  const [tempBrand, setTempBrand] = useState(brandName);
  const [selectedCurrency, setSelectedCurrency] = useState(currency);
  const [geminiConfigured, setGeminiConfigured] = useState<boolean | null>(null);

  useEffect(() => {
    fetch('/api/gemini-status')
      .then((res) => res.json())
      .then((data) => {
        setGeminiConfigured(Boolean(data.configured));
      })
      .catch(() => {
        setGeminiConfigured(false);
      });
  }, []);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setBrandName(tempBrand);
    setCurrency(selectedCurrency);
    addToast({
      title: 'Settings Saved',
      message: 'Your profile and system preferences have been updated.',
      type: 'success',
    });
  };

  return (
    <DashboardLayout
      currentPath="/settings"
      onNavigate={onNavigate}
      title="Workspace Settings"
      subtitle="Manage your profile, default calculation currency, and brand configuration."
      activeNav="settings"
    >
      <div className="max-w-3xl space-y-8">
        <form onSubmit={handleSaveProfile} className="space-y-6">
          {/* Brand Configuration Card */}
          <Card className="p-6 bg-white">
            <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
              <Palette className="h-4 w-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Brand & Appearance
              </h3>
            </div>

            <div className="space-y-4">
              <Input
                label="Application Brand Name"
                value={tempBrand}
                onChange={(e) => setTempBrand(e.target.value)}
                helperText="Brand name is dynamic and updates navigation, logo, and exports."
              />

              <Select
                label="Default Currency Symbol"
                value={selectedCurrency}
                onChange={(e) => setSelectedCurrency(e.target.value)}
                options={[
                  { label: '$ - USD / United States Dollar', value: '$' },
                  { label: '€ - EUR / Euro', value: '€' },
                  { label: '£ - GBP / British Pound', value: '£' },
                  { label: 'CA$ - CAD / Canadian Dollar', value: 'CA$' },
                  { label: 'A$ - AUD / Australian Dollar', value: 'A$' },
                  { label: '¥ - JPY / Japanese Yen', value: '¥' },
                ]}
                helperText="Applies instantly to all financial calculators and summaries."
              />
            </div>
          </Card>

          {/* User Profile Card */}
          <Card className="p-6 bg-white">
            <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
              <User className="h-4 w-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Account Information
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Display Name"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
              />

              <Input
                label="Email Address"
                type="email"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
              />
            </div>
          </Card>

          <div className="flex justify-end">
            <Button type="submit" variant="primary" size="md">
              Save Preferences
            </Button>
          </div>
        </form>

        {/* Integration Status Panel */}
        <Card className="p-6 bg-white">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Key className="h-4 w-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Services & Architecture Status
              </h3>
            </div>
            <Badge variant="indigo" size="sm">Architecture V1</Badge>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-lg border border-slate-200/80 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 block">AI Engine (Gemini 3.8 Flash via Server Proxy)</span>
                <span className="text-slate-500">
                  {geminiConfigured === true
                    ? 'Connected securely on server. Never exposed to browser.'
                    : geminiConfigured === false
                    ? 'Server proxy operational; configure GEMINI_API_KEY in Secrets panel to activate live calls.'
                    : 'Checking server connection...'}
                </span>
              </div>
              <span
                className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                  geminiConfigured === true
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {geminiConfigured === true ? 'Active (Gemini)' : 'Config-Ready'}
              </span>
            </div>

            <div className="p-3 rounded-lg border border-slate-200/80 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 block">Database & State Persistence</span>
                <span className="text-slate-500">Local workspace active; schemas ready for PostgreSQL / Cloud SQL</span>
              </div>
              <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-100 text-emerald-800">
                Ready
              </span>
            </div>

            <div className="p-3 rounded-lg border border-slate-200/80 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 block">OAuth Authentication (Google, Apple, Facebook)</span>
                <span className="text-slate-500">Architecture in place; awaits client secret provisioning</span>
              </div>
              <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-100 text-amber-800">
                Config-Ready
              </span>
            </div>

            <div className="p-3 rounded-lg border border-slate-200/80 bg-slate-50 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 block">Stripe Subscriptions & Invoicing</span>
                <span className="text-slate-500">Pricing tiers structured; awaits live webhook & secret key</span>
              </div>
              <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-100 text-amber-800">
                Config-Ready
              </span>
            </div>
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
};
