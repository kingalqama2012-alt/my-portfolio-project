import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/common/Button';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { ToolCard } from '../components/tools/ToolCard';
import { IconHelper } from '../components/common/IconHelper';
import { TOOLS, CATEGORIES } from '../data/toolsData';
import {
  ArrowRight,
  Sparkles,
  Zap,
  ShieldCheck,
  CheckCircle2,
  TrendingUp,
  Cpu,
  Layers,
  ChevronRight,
  Star,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Calculator,
  FileText,
  DollarSign,
  Target,
  Search,
  MessageSquare,
  Users,
} from 'lucide-react';
import { ResponsiveLeaderboard, NativeAdBanner, SmartlinkPromo } from '../components/ads';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { brandName } = useApp();

  // Animated counter stats
  const [statsCount, setStatsCount] = useState({ tools: 0, users: 0, rating: 0 });
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      question: 'What is ToolFlow?',
      answer:
        'ToolFlow is an online productivity platform and utility suite offering specialized business calculators, AI writing generators, and operational workflow tools. Designed for freelancers, Amazon sellers, creators, and small businesses, ToolFlow simplifies administrative tasks, fee calculations, and content drafting in one centralized workspace.',
    },
    {
      question: 'What tools are available on ToolFlow?',
      answer:
        'ToolFlow features essential digital business utilities across three major workflows: Freelance tools (including our AI Proposal Generator and Freelancer Rate Calculator), Amazon seller tools (such as the Amazon Profit Calculator, Amazon PPC Calculator, and Amazon Keyword Generator), and Creator tools (including the Social Caption Generator, Engagement Rate Calculator, and content diagnostic utilities).',
    },
    {
      question: 'Is ToolFlow useful for freelancers?',
      answer:
        'Yes. Freelancers, agency owners, and independent consultants can use ToolFlow to calculate viable billable hourly rates that factor in overhead, taxes, and non-billable hours, as well as generate customized client proposals for Upwork, Fiverr, or direct contracts.',
    },
    {
      question: 'Does ToolFlow include Amazon seller tools?',
      answer:
        'Yes. ToolFlow includes dedicated e-commerce utilities for Amazon FBA and FBM sellers, such as our Amazon Profit Calculator to compute net margins and referral/fulfillment fees, the Amazon PPC Calculator to establish target ACoS and break-even bids, and the Amazon Keyword Generator for search term research.',
    },
    {
      question: "Can creators use ToolFlow's AI tools?",
      answer:
        'Yes. Content creators, social media managers, and marketers can use our Social Caption Generator to create engaging hooks, descriptions, and hashtags tailored for Instagram, LinkedIn, TikTok, and YouTube Shorts, alongside engagement rate analysis tools.',
    },
    {
      question: "Are ToolFlow's calculators and generators free to use?",
      answer:
        'Core business calculators and generators on ToolFlow are free to access directly in your browser without requiring a credit card. Optional account registration and workspace subscription tiers provide additional capabilities such as saving results to your dashboard, export features, and higher generation allowances.',
    },
  ];

  useEffect(() => {
    const pageTitle = 'ToolFlow – Productivity Tools & Business Calculators Online';
    const pageDesc =
      "Explore ToolFlow's productivity tools, AI generators, Amazon FBA calculators, and business utilities for freelancers, sellers, and creators.";
    const canonicalHref =
      'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app/';

    const previousTitle = document.title;
    document.title = pageTitle;

    // Meta description
    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    if (metaDesc) {
      metaDesc.setAttribute('content', pageDesc);
    } else {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      metaDesc.setAttribute('content', pageDesc);
      document.head.appendChild(metaDesc);
    }

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    const prevCanonical = canonical ? canonical.getAttribute('href') : null;
    if (canonical) {
      canonical.setAttribute('href', canonicalHref);
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      canonical.setAttribute('href', canonicalHref);
      document.head.appendChild(canonical);
    }

    // Robots meta
    let robotsMeta = document.querySelector('meta[name="robots"]');
    const prevRobots = robotsMeta ? robotsMeta.getAttribute('content') : '';
    if (robotsMeta) {
      robotsMeta.setAttribute('content', 'index, follow');
    } else {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      robotsMeta.setAttribute('content', 'index, follow');
      document.head.appendChild(robotsMeta);
    }

    // OpenGraph & Twitter tags
    let ogTitle = document.querySelector('meta[property="og:title"]');
    const prevOgTitle = ogTitle ? ogTitle.getAttribute('content') : '';
    if (ogTitle) ogTitle.setAttribute('content', pageTitle);

    let ogDesc = document.querySelector('meta[property="og:description"]');
    const prevOgDesc = ogDesc ? ogDesc.getAttribute('content') : '';
    if (ogDesc) ogDesc.setAttribute('content', pageDesc);

    let ogType = document.querySelector('meta[property="og:type"]');
    if (ogType) ogType.setAttribute('content', 'website');

    // JSON-LD Structured Data
    const scriptId = 'toolflow-homepage-schema';
    let script = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }

    const structuredData = [
      {
        '@context': 'https://schema.org',
        '@type': 'WebSite',
        name: 'ToolFlow',
        url: canonicalHref,
        description: pageDesc,
      },
      {
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: 'ToolFlow',
        url: canonicalHref,
      },
      {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqItems.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      },
    ];

    script.text = JSON.stringify(structuredData);

    return () => {
      document.title = previousTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      if (ogTitle && prevOgTitle) ogTitle.setAttribute('content', prevOgTitle);
      if (ogDesc && prevOgDesc) ogDesc.setAttribute('content', prevOgDesc);
      if (canonical && prevCanonical) {
        canonical.setAttribute('href', prevCanonical);
      } else if (canonical && !prevCanonical) {
        canonical.remove();
      }
      if (robotsMeta && prevRobots) {
        robotsMeta.setAttribute('content', prevRobots);
      } else if (robotsMeta && !prevRobots) {
        robotsMeta.remove();
      }
      const existingScript = document.getElementById(scriptId);
      if (existingScript) existingScript.remove();
    };
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setStatsCount({ tools: 10, users: 100, rating: 99 });
    }, 200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-28 border-b border-slate-200/80 bg-gradient-to-b from-white via-slate-50/50 to-slate-50">
        {/* Subtle background glow effect */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-indigo-100/40 rounded-full blur-3xl pointer-events-none -z-10" />

        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Top Pill / Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/70 text-indigo-700 text-xs font-semibold mb-6 shadow-xs animate-in fade-in">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Productivity Suite for Digital Operators</span>
          </div>

          {/* Exactly One H1 Headline */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-[1.14] mb-6">
            Free Productivity Tools &amp; Business Calculators for{' '}
            <span className="text-indigo-600">Freelancers</span>,{' '}
            <span className="text-amber-600">Sellers</span> &amp;{' '}
            <span className="text-rose-600">Creators</span>
          </h1>

          {/* Subheadline */}
          <p className="text-base sm:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed mb-8">
            Work smarter with AI-powered tools, calculators, and productivity utilities built for modern digital professionals.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 mb-16">
            <Button
              variant="primary"
              size="lg"
              className="w-full sm:w-auto px-6 py-3 font-semibold shadow-md hover:shadow-lg transition-all"
              href="/tools"
              onNavigate={onNavigate}
              rightIcon={<ArrowRight className="h-4 w-4" />}
            >
              Explore Tools
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="w-full sm:w-auto px-6 py-3 font-semibold"
              href="/signup"
              onNavigate={onNavigate}
            >
              Get Started Free
            </Button>
          </div>

          {/* Trust / Statistics Section */}
          <div className="pt-8 border-t border-slate-200/60 max-w-3xl mx-auto">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
              <div className="p-4 rounded-xl bg-white/70 border border-slate-200/60 shadow-xs">
                <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tracking-tight">
                  {statsCount.tools}+
                </p>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
                  Useful Tools
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">Specialized calculations &amp; generators</p>
              </div>

              <div className="p-4 rounded-xl bg-white/70 border border-slate-200/60 shadow-xs">
                <p className="text-2xl sm:text-3xl font-extrabold text-indigo-600 font-mono tracking-tight">
                  Free to Start
                </p>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
                  Instant Access
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">No credit card required</p>
              </div>

              <div className="p-4 rounded-xl bg-white/70 border border-slate-200/60 shadow-xs">
                <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tracking-tight">
                  100%
                </p>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
                  Built for Professionals
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">Real mathematical formulas</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Adsterra Leaderboard (728x90 desktop / 320x50 mobile) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-center">
        <ResponsiveLeaderboard />
      </div>

      {/* H2 #1: 3 Major Categories Section */}
      <section className="py-16 md:py-24 bg-white border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
              Tailored Workflows
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-3">
              Tools for Freelancers, Sellers &amp; Creators
            </h2>
            <p className="text-sm text-slate-500 mt-2">
              Select your domain to access purpose-built calculators, AI writers, and growth diagnostics.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {CATEGORIES.map((cat) => {
              const borderColors: Record<string, string> = {
                freelancer: 'hover:border-indigo-300 group-hover:text-indigo-600',
                amazon: 'hover:border-amber-300 group-hover:text-amber-600',
                creator: 'hover:border-rose-300 group-hover:text-rose-600',
              };

              const badgeColors: Record<string, 'indigo' | 'amber' | 'rose'> = {
                freelancer: 'indigo',
                amazon: 'amber',
                creator: 'rose',
              };

              const categoryUrl = `/tools?category=${cat.id}`;

              return (
                <Card
                  key={cat.id}
                  hoverable
                  onClick={() => onNavigate(categoryUrl)}
                  className={`p-6 sm:p-8 flex flex-col justify-between group transition-all duration-200 ${borderColors[cat.id]}`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <div className="p-3.5 rounded-xl bg-slate-100 group-hover:bg-slate-900 group-hover:text-white transition-colors text-slate-700">
                        <IconHelper name={cat.iconName} className="h-6 w-6" />
                      </div>
                      <Badge variant={badgeColors[cat.id]} size="sm">
                        {cat.toolCount} Utilities
                      </Badge>
                    </div>

                    <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-indigo-600 transition-colors">
                      <a
                        href={categoryUrl}
                        onClick={(e) => {
                          e.preventDefault();
                          onNavigate(categoryUrl);
                        }}
                        className="hover:underline focus:outline-none"
                      >
                        {cat.name}
                      </a>
                    </h3>
                    <p className="text-sm text-slate-600 leading-relaxed mb-6">
                      {cat.description}
                    </p>

                    <div className="space-y-2 mb-6 pt-4 border-t border-slate-100">
                      <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                        Included Tools:
                      </p>
                      {TOOLS.filter((t) => t.category === cat.id).map((tool) => (
                        <a
                          key={tool.id}
                          href={tool.path}
                          onClick={(e) => {
                            e.preventDefault();
                            onNavigate(tool.path);
                          }}
                          className="flex items-center gap-2 text-xs font-medium text-slate-700 hover:text-indigo-600 transition-colors"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5 text-indigo-500 shrink-0" />
                          <span>{tool.name}</span>
                        </a>
                      ))}
                    </div>
                  </div>

                  <a
                    href={categoryUrl}
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate(categoryUrl);
                    }}
                    className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-indigo-600 group-hover:translate-x-0.5 transition-transform"
                  >
                    <span>Explore {cat.name}</span>
                    <ChevronRight className="h-4 w-4" />
                  </a>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* H2 #2: Featured Tools Grid Section */}
      <section className="py-16 md:py-24 bg-slate-50/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Popular Utilities
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
                Featured Business Calculators &amp; AI Tools
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                Frequently used tools by freelancers, Amazon brand owners, and content teams.
              </p>
            </div>

            <a
              href="/tools"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/tools');
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold border border-slate-300 text-slate-700 bg-white hover:bg-slate-50 hover:border-slate-400 transition-colors cursor-pointer"
            >
              <span>View All Tools Directory</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {TOOLS.slice(0, 6).map((tool) => (
              <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} />
            ))}
          </div>

          {/* Adsterra Native Banner (ID: 31491248) */}
          <div className="mt-12">
            <NativeAdBanner />
          </div>
        </div>
      </section>

      {/* Adsterra Smartlink Promo Section (ID: 31491249) */}
      <section className="py-4 bg-slate-50 border-t border-slate-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SmartlinkPromo />
        </div>
      </section>

      {/* Concise Explanatory SEO Content Section */}
      <section className="py-16 bg-white border-t border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
              Platform Overview
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-3">
              Online Productivity Tools for Modern Digital Workflows
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-2 leading-relaxed">
              ToolFlow provides practical, browser-based business tools and online calculators engineered for freelancers, Amazon sellers, creators, small businesses, and digital professionals. Each utility eliminates manual spreadsheets and guesswork by automating critical business equations and drafting tasks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Freelancer Tools */}
            <div className="p-6 rounded-2xl bg-slate-50/70 border border-slate-200/70 space-y-3">
              <div className="h-10 w-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                <FileText className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Freelancer &amp; Consulting Utilities
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Win high-value client contracts and protect billable margins. Use our{' '}
                <a
                  href="/tools/proposal-generator"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/tools/proposal-generator');
                  }}
                  className="font-semibold text-indigo-600 hover:underline"
                >
                  AI Proposal Generator
                </a>{' '}
                to produce tailored client pitches, and our{' '}
                <a
                  href="/tools/freelancer-rate-calculator"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/tools/freelancer-rate-calculator');
                  }}
                  className="font-semibold text-indigo-600 hover:underline"
                >
                  Freelancer Rate Calculator
                </a>{' '}
                to determine minimum hourly and project pricing accounting for overhead and self-employment taxes.
              </p>
            </div>

            {/* Amazon Seller Tools */}
            <div className="p-6 rounded-2xl bg-slate-50/70 border border-slate-200/70 space-y-3">
              <div className="h-10 w-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                <DollarSign className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Amazon FBA &amp; E-Commerce Calculators
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Analyze inventory profitability before placing manufacturing orders. Calculate unit margins with the{' '}
                <a
                  href="/tools/amazon-profit-calculator"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/tools/amazon-profit-calculator');
                  }}
                  className="font-semibold text-amber-700 hover:underline"
                >
                  Amazon Profit Calculator
                </a>
                , target break-even ad bids with the{' '}
                <a
                  href="/tools/amazon-ppc-calculator"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/tools/amazon-ppc-calculator');
                  }}
                  className="font-semibold text-amber-700 hover:underline"
                >
                  Amazon PPC Calculator
                </a>
                , and discover search terms using the{' '}
                <a
                  href="/tools/amazon-keyword-generator"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/tools/amazon-keyword-generator');
                  }}
                  className="font-semibold text-amber-700 hover:underline"
                >
                  Amazon Keyword Generator
                </a>
                .
              </p>
            </div>

            {/* Creator Tools */}
            <div className="p-6 rounded-2xl bg-slate-50/70 border border-slate-200/70 space-y-3">
              <div className="h-10 w-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                <MessageSquare className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Creator &amp; Content Marketing Generators
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Streamline audience publishing across social networks. Draft platform-specific hooks and hashtags with the{' '}
                <a
                  href="/tools/social-caption-generator"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/tools/social-caption-generator');
                  }}
                  className="font-semibold text-rose-700 hover:underline"
                >
                  Social Caption Generator
                </a>
                , evaluate post engagement ratios, and analyze viral hook frameworks without complicated software setups.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* H2 #3: Why Use ToolFlow Section */}
      <section className="py-16 md:py-20 bg-slate-50/50 border-t border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Why Use ToolFlow?
            </h2>
            <p className="text-sm text-slate-500 mt-2">
              Purpose-built utilities engineered for daily business productivity, financial clarity, and fast turnaround.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="p-6 rounded-xl bg-white border border-slate-200/80 shadow-xs">
              <div className="h-10 w-10 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center mb-4">
                <Zap className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">High Speed &amp; Zero Clutter</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Fast load times, clean typography, and zero distracting popups or bloat. Perform calculations and copy outputs immediately.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-white border border-slate-200/80 shadow-xs">
              <div className="h-10 w-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Accurate Financial Formulas</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Tested against real-world Amazon fee structures and freelance tax equations. Clear, dependable numbers you can rely on.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-white border border-slate-200/80 shadow-xs">
              <div className="h-10 w-10 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center mb-4">
                <Layers className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">Integrated Workspace</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Save winning proposals, profit audits, and generated captions in one unified dashboard with one-click export and retrieval.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* H2 #4: FAQ Section */}
      <section className="py-16 md:py-20 bg-white border-t border-slate-200/80">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold mb-3 border border-indigo-100">
              <HelpCircle className="h-3.5 w-3.5" />
              <span>Got Questions?</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Frequently Asked Questions About ToolFlow
            </h2>
            <p className="text-sm text-slate-500 mt-2">
              Common questions about our online productivity calculators, AI generators, and workspace tools.
            </p>
          </div>

          <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200/80 bg-white shadow-xs p-6 sm:p-8">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={index} className="py-4 first:pt-0 last:pb-0">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between text-left gap-4 group cursor-pointer focus:outline-none"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                      {item.question}
                    </span>
                    <span className="p-1 rounded-md text-slate-400 group-hover:text-indigo-600 shrink-0">
                      {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="mt-2.5 pr-8 text-xs sm:text-sm text-slate-600 leading-relaxed animate-in fade-in duration-200">
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <section className="py-16 bg-slate-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-4">
            Ready to streamline your daily workflow?
          </h2>
          <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto mb-8">
            Access every calculator, generator, and workspace utility in {brandName} today. Free to start, no setup needed.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Button
              variant="primary"
              size="lg"
              className="w-full sm:w-auto px-6 font-semibold"
              href="/tools"
              onNavigate={onNavigate}
            >
              Start Using Tools
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="w-full sm:w-auto px-6 font-semibold text-white border-slate-700 hover:bg-slate-800"
              href="/signup"
              onNavigate={onNavigate}
            >
              Create Free Account
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};
