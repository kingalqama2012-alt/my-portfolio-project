import React from 'react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/common/Button';
import { Card } from '../components/common/Card';
import { usePageSEO } from '../utils/usePageSEO';
import {
  Layers,
  Shield,
  Zap,
  Target,
  Users,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

interface AboutPageProps {
  onNavigate: (path: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'About ToolFlow – Modern Productivity Tools for Independent Operators',
    description:
      "Learn about ToolFlow's mission to provide fast, reliable business calculators, AI writing tools, and operational utilities for freelancers, sellers, and creators.",
    canonicalPath: '/about',
    robots: 'index, follow',
  });

  const { brandName } = useApp();

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-16">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
          About {brandName}
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mt-3 mb-4">
          Practical digital tools for modern independent operators.
        </h1>
        <p className="text-base text-slate-600 leading-relaxed">
          {brandName} helps freelancers, Amazon sellers, and creators save time by bringing essential calculations, AI generators, and workspace utilities into one clean, fast interface.
        </p>
      </div>

      {/* Core Mission Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        <Card className="p-6 bg-white">
          <div className="h-10 w-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4">
            <Target className="h-5 w-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-2">Our Mission</h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Eliminate messy spreadsheets, disparate bookmarked calculator websites, and sluggish AI interfaces with a single unified, ultra-fast productivity hub.
          </p>
        </Card>

        <Card className="p-6 bg-white">
          <div className="h-10 w-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
            <Zap className="h-5 w-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-2">Speed & Utility First</h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Every tool is designed to work in seconds. No unnecessary marketing clutter, no forced popups, and no bloated multi-step flows.
          </p>
        </Card>

        <Card className="p-6 bg-white">
          <div className="h-10 w-10 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center mb-4">
            <Shield className="h-5 w-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-2">Trust & Transparency</h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            We don't disguise formulas or claim unrealistic infinite generations. Financial math is transparent, customizable, and verifiable.
          </p>
        </Card>
      </div>

      {/* Who We Build For */}
      <div className="bg-slate-50 rounded-2xl p-8 sm:p-10 border border-slate-200/80 mb-16">
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-6">
          Who We Serve
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-indigo-600"></span>
              Freelancers & Consultants
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Price services with complete tax and overhead clarity, while drafting tailored bids that convert inbound leads into paying clients.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-amber-600"></span>
              Amazon FBA & FBM Sellers
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Audit SKU economics before placing manufacturing deposits, optimize PPC campaigns to protect TACOS, and discover indexed customer keywords.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-rose-600"></span>
              Creators & Social Strategists
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Synthesize multi-platform captions with verified hooks, calculate engagement benchmarks, and track audience performance accurately.
            </p>
          </div>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="text-center pt-4 space-y-4">
        <a
          href="/tools"
          onClick={(e) => {
            if (!e.ctrlKey && !e.metaKey && e.button === 0) {
              e.preventDefault();
              onNavigate('/tools');
            }
          }}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-xs"
        >
          <span>Explore All Tools</span>
          <ArrowRight className="h-4 w-4" />
        </a>
        <p className="text-xs text-slate-500">
          Have feedback or an inquiry?{' '}
          <a
            href="/contact"
            onClick={(e) => {
              if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                e.preventDefault();
                onNavigate('/contact');
              }
            }}
            className="text-indigo-600 font-semibold hover:underline"
          >
            Contact our team
          </a>
          .
        </p>
      </div>
    </div>
  );
};
