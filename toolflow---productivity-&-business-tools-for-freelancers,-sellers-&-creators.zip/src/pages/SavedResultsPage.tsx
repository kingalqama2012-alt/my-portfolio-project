import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { SavedResult } from '../types';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { EmptyState } from '../components/common/EmptyState';
import { usePageSEO } from '../utils/usePageSEO';
import {
  Bookmark,
  Trash2,
  ExternalLink,
  Copy,
  Check,
  Search,
  Filter,
  Calendar,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface SavedResultsPageProps {
  onNavigate: (path: string) => void;
}

export const SavedResultsPage: React.FC<SavedResultsPageProps> = ({ onNavigate }) => {
  usePageSEO({
    title: 'Saved Results | ToolFlow Workspace',
    description: 'View and export your saved business calculations and generated drafts.',
    canonicalPath: '/saved',
    robots: 'noindex, nofollow',
  });

  const { savedResults, deleteSavedResult, clearAllSavedResults, addToast } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedResult, setSelectedResult] = useState<SavedResult | null>(null);
  const [copied, setCopied] = useState(false);

  const filteredResults = useMemo(() => {
    return savedResults.filter((item) => {
      const matchesCategory =
        categoryFilter === 'all' || item.category === categoryFilter;

      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        item.title.toLowerCase().includes(q) ||
        item.toolName.toLowerCase().includes(q) ||
        item.content.toLowerCase().includes(q);

      return matchesCategory && matchesSearch;
    });
  }, [savedResults, categoryFilter, searchQuery]);

  const handleCopyContent = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    addToast({
      title: 'Copied to Clipboard',
      message: 'Full record content copied.',
      type: 'success',
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const getToolRoute = (toolId: string) => {
    return `/tools/${toolId}`;
  };

  return (
    <DashboardLayout
      currentPath="/saved"
      onNavigate={onNavigate}
      title="Saved Results"
      subtitle="View, search, copy, or export your saved calculations, proposals, and AI copy."
      activeNav="saved"
    >
      <div className="space-y-6">
        {/* Controls Bar: Search & Category Filter */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          <div className="flex-1 max-w-md relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search saved records..."
              className="w-full pl-9 pr-4 py-2 bg-white rounded-lg border border-slate-300 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200">
              {['all', 'freelancer', 'amazon', 'creator'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`text-xs px-2.5 py-1 rounded-md capitalize font-medium transition-colors cursor-pointer ${
                    categoryFilter === cat
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {cat === 'all' ? 'All' : cat}
                </button>
              ))}
            </div>

            {savedResults.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllSavedResults}
                className="text-rose-600 hover:bg-rose-50"
              >
                Clear All
              </Button>
            )}
          </div>
        </div>

        {/* Results List or Empty State */}
        {filteredResults.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {filteredResults.map((item) => {
              const categoryBadge = {
                freelancer: 'indigo',
                amazon: 'amber',
                creator: 'rose',
              }[item.category] as 'indigo' | 'amber' | 'rose';

              return (
                <Card
                  key={item.id}
                  className="p-5 sm:p-6 bg-white hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <Badge variant={categoryBadge} size="sm">
                        {item.toolName}
                      </Badge>
                      <span className="flex items-center gap-1 text-[11px] text-slate-400">
                        <Calendar className="h-3 w-3" />
                        {new Date(item.createdAt).toLocaleDateString(undefined, {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 mb-1">
                      {item.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-500 line-clamp-2 leading-relaxed">
                      {item.preview}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => setSelectedResult(item)}
                    >
                      Open
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onNavigate(getToolRoute(item.toolId))}
                      title="Launch fresh tool"
                      rightIcon={<ExternalLink className="h-3 w-3" />}
                    >
                      Launch
                    </Button>
                    <button
                      onClick={() => deleteSavedResult(item.id)}
                      className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                      title="Delete record"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </Card>
              );
            })}
          </div>
        ) : (
          <EmptyState
            icon={<Bookmark className="h-8 w-8" />}
            title={searchQuery ? 'No matching saved results' : 'No saved calculations yet'}
            description={
              searchQuery
                ? 'Try a different search query or clear the filter.'
                : 'Whenever you calculate rates, profit margins, or generate proposals, click "Save" to collect them here.'
            }
            actionText="Explore Tools Directory"
            onAction={() => onNavigate('/tools')}
          />
        )}
      </div>

      {/* Detail Modal */}
      {selectedResult && (
        <Modal
          isOpen={!!selectedResult}
          onClose={() => setSelectedResult(null)}
          title={selectedResult.title}
          maxWidth="lg"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 text-xs">
              <span className="font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                {selectedResult.toolName}
              </span>
              <span className="text-slate-400">
                Created {new Date(selectedResult.createdAt).toLocaleString()}
              </span>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg font-mono text-xs text-slate-800 whitespace-pre-wrap max-h-[350px] overflow-y-auto leading-relaxed border border-slate-200/80">
              {selectedResult.content}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const path = getToolRoute(selectedResult.toolId);
                  setSelectedResult(null);
                  onNavigate(path);
                }}
                leftIcon={<ExternalLink className="h-3.5 w-3.5" />}
              >
                Open in Tool
              </Button>

              <div className="flex items-center gap-2">
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => handleCopyContent(selectedResult.content)}
                  leftIcon={copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                >
                  {copied ? 'Copied' : 'Copy Content'}
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => {
                    deleteSavedResult(selectedResult.id);
                    setSelectedResult(null);
                  }}
                  leftIcon={<Trash2 className="h-3.5 w-3.5" />}
                >
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </DashboardLayout>
  );
};
