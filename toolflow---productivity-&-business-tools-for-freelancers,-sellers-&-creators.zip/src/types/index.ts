export type ToolCategory = 'freelancer' | 'amazon' | 'creator';

export interface ToolItem {
  id: string;
  name: string;
  shortDescription: string;
  description: string;
  category: ToolCategory;
  categoryLabel: string;
  path: string;
  iconName: string;
  badge?: string;
  featured?: boolean;
  popular?: boolean;
}

export interface SavedResult {
  id: string;
  toolId: string;
  toolName: string;
  category: ToolCategory;
  title: string;
  preview: string;
  content: string;
  data?: Record<string, any>;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'Freelancer' | 'Amazon Seller' | 'Content Creator' | 'Agency';
  plan: 'free' | 'pro' | 'business';
  joinedDate: string;
  avatarUrl?: string;
}

export interface Toast {
  id: string;
  title: string;
  message?: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

// Tool Specific Input/Output Types
export interface ProposalFormData {
  jobTitle: string;
  clientRequirements: string;
  yourSkills: string;
  experience: string;
  projectBudget: string;
  tone: 'Professional' | 'Friendly' | 'Persuasive' | 'Short';
}

export interface FreelancerRateFormData {
  desiredIncome: number;
  hoursPerWeek: number;
  weeksPerMonth: number;
  businessExpenses: number;
  taxPercentage: number;
}

export interface FreelancerRateResult {
  hourlyRate: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  billableHoursPerMonth: number;
  billableHoursPerYear: number;
  yearlyTaxes: number;
  yearlyExpenses: number;
  takeHomePayYearly: number;
}

export interface AmazonProfitFormData {
  sellingPrice: number;
  productCost: number;
  shippingCost: number;
  referralFeePercent: number;
  fbaFee: number;
  adCostPerUnit: number;
  otherCosts: number;
  unitsSold: number;
}

export interface AmazonProfitResult {
  revenue: number;
  referralFeeTotal: number;
  fbaFeeTotal: number;
  amazonFeesTotal: number;
  productCostsTotal: number;
  shippingCostsTotal: number;
  advertisingCostsTotal: number;
  otherCostsTotal: number;
  totalCosts: number;
  netProfit: number;
  profitMarginPercent: number;
  roiPercent: number;
  profitPerUnit: number;
}

export interface AmazonPpcFormData {
  adSpend: number;
  adSales: number;
  totalSales: number;
}

export interface AmazonPpcResult {
  acos: number;
  tacos: number;
  roas: number;
  adSalesPercentage: number;
  organicSales: number;
  organicPercentage: number;
}

export interface AmazonKeywordFormData {
  productName: string;
  productCategory: string;
  mainFeatures: string;
  targetMarket: string;
}

export interface KeywordItem {
  keyword: string;
  type: 'Broad Match' | 'Exact / High Intent' | 'Long-Tail' | 'Competitor / Feature';
  searchVolume: 'High' | 'Medium' | 'Very High' | 'Trending';
  relevance: number; // 1-100
}

export interface SocialCaptionFormData {
  topic: string;
  platform: 'Instagram' | 'TikTok' | 'Facebook' | 'LinkedIn' | 'YouTube';
  tone: 'Professional' | 'Funny' | 'Educational' | 'Inspirational' | 'Casual';
  captionCount: number;
}

export interface GeneratedCaption {
  id: string;
  hook: string;
  body: string;
  callToAction: string;
  hashtags: string[];
  fullText: string;
  charCount: number;
}

export interface EngagementFormData {
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  followers: number;
}

export interface EngagementResult {
  totalEngagement: number;
  engagementRate: number;
  engagementPer1kFollowers: number;
  rating: 'Needs Work' | 'Average' | 'Good' | 'Excellent / Viral';
  ratingColor: string;
}

// 1. Trend Radar Types
export interface TrendRadarFormData {
  platform: string;
  niche: string;
  targetCountry: string;
  targetLanguage: string;
  contentFormat: string;
  optionalTopic?: string;
}

export interface TrendTopicItem {
  topic: string;
  trendStatus: 'Emerging' | 'Growing' | 'Established';
  whyRelevant: string;
  contentAngles: string[];
  searchTerms: string[];
  hashtags: string[];
  suggestedVideoIdea: string;
}

export interface TrendRadarResult {
  trends: TrendTopicItem[];
  disclaimer: string;
  isAiAnalysis: boolean;
}

// 2. Content Gap Finder Types
export interface ContentGapFormData {
  niche: string;
  mainTopic: string;
  platform: string;
  targetAudience: string;
  competitorExamples?: string;
}

export interface ContentGapItem {
  angle: string;
  whyUseful: string;
  suggestedTitleHook: string;
  contentIdea: string;
  opportunityScore: number; // 0-100 AI estimate
  scoreReasoning: string;
}

export interface ContentGapResult {
  coveredAngles: string[];
  unansweredQuestions: string[];
  underservedAngles: ContentGapItem[];
  disclaimer: string;
  isAiAnalysis: boolean;
}

// 3. Hook Doctor Types
export interface HookDoctorFormData {
  platform?: string;
  videoTopic: string;
  currentHook: string;
  videoFormat: string;
  targetAudience: string;
}

export interface ImprovedHookItem {
  type: string;
  hookText: string;
  whyItWorks: string;
  suggestedPacing?: string;
}

export interface HookDoctorResult {
  analysis: {
    strengths: string;
    weaknesses: string;
    retentionRiskFactors: string[];
  };
  firstThreeSecondsCue: {
    visualAction: string;
    audioSpokenCue: string;
    textOnScreen: string;
  };
  improvedHooks: ImprovedHookItem[];
  disclaimer: string;
  isAiAnalysis: boolean;
}

// 4. Video Performance Doctor Types
export interface VideoPerformanceFormData {
  platform: string;
  videoLength: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  averageWatchTime: string;
  averagePercentageViewed?: number;
  impressions?: number;
  ctr?: number;
  followers: number;
  videoTitle?: string;
}

export interface VideoPerformanceCalculations {
  likeToViewRatio: number;
  commentRatio: number;
  shareRatio: number;
  totalEngagementRate: number;
  estimatedRetentionRate?: number;
}

export interface VideoPerformanceResult {
  calculations: VideoPerformanceCalculations;
  performanceObservations: string;
  possibleStrengths: string[];
  possibleWeaknesses: string[];
  reachObservations: string;
  retentionObservations: string;
  practicalSuggestions: string[];
  nextVideoRecommendations: string[];
  disclaimer: string;
  isAiAnalysis: boolean;
}

// 5. Smart Hashtag & Keyword Mixer Types
export interface HashtagMixerFormData {
  platform: string;
  topic: string;
  niche: string;
  targetCountry: string;
  targetLanguage: string;
  audience: string;
  contentType: string;
}

export interface SuggestedCombination {
  title: string;
  description: string;
  tags: string[];
  readyText: string;
}

export interface HashtagMixerResult {
  broadHashtags: string[];
  nicheHashtags: string[];
  specificHashtags: string[];
  searchKeywords: string[];
  longTailKeywords: string[];
  captionKeywords: string[];
  suggestedCombinations: SuggestedCombination[];
  disclaimer: string;
  isAiAnalysis: boolean;
}

// 6. Content Experiment Generator Types
export interface ContentExperimentFormData {
  originalIdea: string;
  platform: string;
  audience: string;
  contentFormat: string;
  goal: string;
}

export interface ContentExperimentPlan {
  name: string;
  hook: string;
  title: string;
  contentAngle: string;
  cta: string;
  hypothesis: string;
}

export interface ContentExperimentResult {
  experimentA: ContentExperimentPlan;
  experimentB: ContentExperimentPlan;
  experimentC: ContentExperimentPlan;
  testingGuidelines: string[];
  disclaimer: string;
  isAiAnalysis: boolean;
}

