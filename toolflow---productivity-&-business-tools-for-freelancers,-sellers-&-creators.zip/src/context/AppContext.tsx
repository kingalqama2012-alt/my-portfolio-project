import React, { createContext, useContext, useState, useEffect } from 'react';
import { SavedResult, UserProfile, Toast, ToolCategory } from '../types';

interface AppContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  login: (email: string, name?: string) => void;
  logout: () => void;
  savedResults: SavedResult[];
  saveResult: (result: Omit<SavedResult, 'id' | 'createdAt'>) => string;
  deleteSavedResult: (id: string) => void;
  clearAllSavedResults: () => void;
  favorites: string[];
  toggleFavorite: (toolId: string) => void;
  isFavorite: (toolId: string) => boolean;
  recentTools: string[];
  trackToolUsage: (toolId: string) => void;
  currency: string;
  setCurrency: (c: string) => void;
  brandName: string;
  setBrandName: (b: string) => void;
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
}

const DEFAULT_USER: UserProfile = {
  id: 'usr_sample_101',
  name: 'Alex Morgan',
  email: 'alex@example.com',
  role: 'Freelancer',
  plan: 'pro',
  joinedDate: 'March 2026',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
};

const INITIAL_SAVED_RESULTS: SavedResult[] = [
  {
    id: 'res_sample_1',
    toolId: 'proposal-generator',
    toolName: 'AI Proposal Generator',
    category: 'freelancer',
    title: 'SaaS Dashboard UI Redesign Proposal',
    preview: 'Hi David, I reviewed your project for the full analytics dashboard redesign. With 6+ years specializing in Next.js & Tailwind...',
    content: `Dear David,\n\nI was thrilled to review your brief for the SaaS Dashboard Redesign. As a senior product designer and developer with over six years of experience building high-conversion enterprise interfaces, I understand the delicate balance between technical data density and intuitive user navigation.\n\n### Project Approach & Scope\n1. User Flow & Wireframing (Week 1)\n2. High-Fidelity Figma Design System (Week 2)\n3. Responsive Implementation in Tailwind CSS (Week 3)\n4. Testing & Handoff Documentation (Week 4)\n\n### Budget & Timeline\n- Timeline: 4 Weeks\n- Flat Project Rate: $4,500\n\nI'd love to schedule a quick 15-minute intro call to share relevant live portfolio links.\n\nBest regards,\nAlex Morgan`,
    createdAt: '2026-09-28T14:22:00Z',
  },
  {
    id: 'res_sample_2',
    toolId: 'amazon-profit-calculator',
    toolName: 'Amazon Profit Calculator',
    category: 'amazon',
    title: 'Insulated Water Bottle (32oz) - Batch #4',
    preview: 'Selling Price: $29.99 | Unit Cost: $6.50 | Net Profit: $8.42 (28.1% Margin) | ROI: 129.5%',
    content: `Selling Price: $29.99\nProduct Cost: $6.50\nShipping: $1.20\nAmazon Referral Fee (15%): $4.50\nFBA Fulfillment: $5.87\nAd Spend / Unit: $3.50\n\nNet Profit / Unit: $8.42\nNet Margin: 28.1%\nROI: 129.5%\nProjected 500-unit Profit: $4,210.00`,
    data: {
      sellingPrice: 29.99,
      netProfit: 8.42,
      margin: 28.1,
      roi: 129.5,
    },
    createdAt: '2026-09-29T09:15:00Z',
  },
  {
    id: 'res_sample_3',
    toolId: 'social-caption-generator',
    toolName: 'Social Caption Generator',
    category: 'creator',
    title: 'Instagram: 5 Freelance Pricing Mistakes',
    preview: 'Stop charging hourly if you want to scale past $10k/month. Here is the framework I used to double client retainers...',
    content: `Stop charging hourly if you want to scale past $10k/month 🚫\n\nWhen you bill by the hour, you are essentially penalized for being fast and experienced.\n\nHere are 3 value-pricing shifts that changed my business:\n1️⃣ Quote based on business outcome, not time spent.\n2️⃣ Include high-leverage deliverables in clear tiers.\n3️⃣ Always require a 50% deposit before kickoff.\n\nSave this post for your next client pitch 📌\n\n#freelanceTips #pricingStrategy #creativeEntrepreneur #clientWork`,
    createdAt: '2026-09-29T18:40:00Z',
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Auth state
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('toolflow_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_USER;
      }
    }
    return DEFAULT_USER; // Default logged in for immediate SaaS demo convenience
  });

  // Saved Results state
  const [savedResults, setSavedResults] = useState<SavedResult[]>(() => {
    const saved = localStorage.getItem('toolflow_saved_results');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_SAVED_RESULTS;
      }
    }
    return INITIAL_SAVED_RESULTS;
  });

  // Favorites
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('toolflow_favorites');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return ['proposal-generator', 'amazon-profit-calculator', 'social-caption-generator'];
      }
    }
    return ['proposal-generator', 'amazon-profit-calculator', 'social-caption-generator'];
  });

  // Recent tools
  const [recentTools, setRecentTools] = useState<string[]>(() => {
    const saved = localStorage.getItem('toolflow_recent_tools');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return ['proposal-generator', 'amazon-profit-calculator', 'freelancer-rate-calculator'];
      }
    }
    return ['proposal-generator', 'amazon-profit-calculator', 'freelancer-rate-calculator'];
  });

  // Currency
  const [currency, setCurrencyState] = useState<string>(() => {
    return localStorage.getItem('toolflow_currency') || '$';
  });

  // Brand Name (Allows easy rebranding)
  const [brandName, setBrandNameState] = useState<string>(() => {
    return localStorage.getItem('toolflow_brand') || 'ToolFlow';
  });

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem('toolflow_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('toolflow_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('toolflow_saved_results', JSON.stringify(savedResults));
  }, [savedResults]);

  useEffect(() => {
    localStorage.setItem('toolflow_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('toolflow_recent_tools', JSON.stringify(recentTools));
  }, [recentTools]);

  const login = (email: string, name?: string) => {
    const newUser: UserProfile = {
      id: `usr_${Date.now()}`,
      name: name || email.split('@')[0],
      email: email,
      role: 'Freelancer',
      plan: 'free',
      joinedDate: 'September 2026',
      avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${name || email}`,
    };
    setUser(newUser);
    addToast({
      title: 'Welcome to ToolFlow',
      message: `Signed in as ${newUser.email}`,
      type: 'success',
    });
  };

  const logout = () => {
    setUser(null);
    addToast({
      title: 'Signed Out',
      message: 'You have been logged out successfully.',
      type: 'info',
    });
  };

  const saveResult = (result: Omit<SavedResult, 'id' | 'createdAt'>): string => {
    const newId = `res_${Date.now()}`;
    const newResult: SavedResult = {
      ...result,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    setSavedResults((prev) => [newResult, ...prev]);
    addToast({
      title: 'Saved to Results',
      message: `"${result.title}" has been saved to your dashboard.`,
      type: 'success',
    });
    return newId;
  };

  const deleteSavedResult = (id: string) => {
    setSavedResults((prev) => prev.filter((item) => item.id !== id));
    addToast({
      title: 'Result Deleted',
      message: 'The item has been removed from your saved list.',
      type: 'info',
    });
  };

  const clearAllSavedResults = () => {
    setSavedResults([]);
    addToast({
      title: 'Cleared All',
      message: 'All saved results have been cleared.',
      type: 'warning',
    });
  };

  const toggleFavorite = (toolId: string) => {
    setFavorites((prev) => {
      const exists = prev.includes(toolId);
      const updated = exists ? prev.filter((id) => id !== toolId) : [...prev, toolId];
      addToast({
        title: exists ? 'Removed from Favorites' : 'Added to Favorites',
        type: 'info',
      });
      return updated;
    });
  };

  const isFavorite = (toolId: string) => favorites.includes(toolId);

  const trackToolUsage = (toolId: string) => {
    setRecentTools((prev) => {
      const filtered = prev.filter((id) => id !== toolId);
      return [toolId, ...filtered].slice(0, 8);
    });
  };

  const setCurrency = (c: string) => {
    setCurrencyState(c);
    localStorage.setItem('toolflow_currency', c);
  };

  const setBrandName = (b: string) => {
    setBrandNameState(b);
    localStorage.setItem('toolflow_brand', b);
  };

  const addToast = (toast: Omit<Toast, 'id'>) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newToast: Toast = { ...toast, id };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <AppContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        savedResults,
        saveResult,
        deleteSavedResult,
        clearAllSavedResults,
        favorites,
        toggleFavorite,
        isFavorite,
        recentTools,
        trackToolUsage,
        currency,
        setCurrency,
        brandName,
        setBrandName,
        toasts,
        addToast,
        removeToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
