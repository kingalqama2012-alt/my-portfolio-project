import React from 'react';

interface NativeAdBannerProps {
  className?: string;
  showBadge?: boolean;
}

export const NativeAdBanner: React.FC<NativeAdBannerProps> = ({
  className = '',
  showBadge = true,
}) => {
  const nativeHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    body {
      background: transparent;
      overflow: hidden;
      width: 100%;
      padding: 0;
    }
    #container-23640598d61e236eb8fcf68219c76241 {
      width: 100%;
      min-height: 120px;
    }
  </style>
</head>
<body>
  <script async="async" data-cfasync="false" src="https://pl31591747.profitableratecpmnetwork.com/23640598d61e236eb8fcf68219c76241/invoke.js"></script>
  <div id="container-23640598d61e236eb8fcf68219c76241"></div>
</body>
</html>`;

  return (
    <div className={`w-full my-6 flex flex-col items-center ${className}`}>
      {showBadge && (
        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5 select-none self-start">
          Sponsored Content
        </span>
      )}
      <div className="w-full bg-white rounded-xl border border-slate-200/80 p-3 shadow-xs overflow-hidden">
        <iframe
          title="Adsterra Native Ad"
          srcDoc={nativeHtml}
          className="w-full border-none min-h-[160px]"
          scrolling="no"
          loading="lazy"
        />
      </div>
    </div>
  );
};
