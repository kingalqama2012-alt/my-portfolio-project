import React from 'react';

export type AdSize = '728x90' | '468x60' | '300x250' | '320x50' | '160x600' | '160x300';

export interface AdConfig {
  key: string;
  width: number;
  height: number;
  scriptUrl: string;
  label: string;
}

export const AD_CONFIGS: Record<AdSize, AdConfig> = {
  '728x90': {
    key: '80eb432a2a273c7535caa9888da50462',
    width: 728,
    height: 90,
    scriptUrl: 'https://www.highrevenueformat.com/80eb432a2a273c7535caa9888da50462/invoke.js',
    label: 'Leaderboard (728x90)',
  },
  '468x60': {
    key: 'a30bfa527eb6d2e1b6ec63f914ca1f1d',
    width: 468,
    height: 60,
    scriptUrl: 'https://www.highrevenueformat.com/a30bfa527eb6d2e1b6ec63f914ca1f1d/invoke.js',
    label: 'Standard Banner (468x60)',
  },
  '300x250': {
    key: '693471ee17d5cc30a9dfdeace52febbb',
    width: 300,
    height: 250,
    scriptUrl: 'https://www.highrevenueformat.com/693471ee17d5cc30a9dfdeace52febbb/invoke.js',
    label: 'Medium Rectangle (300x250)',
  },
  '320x50': {
    key: '197b97f3d0df94919e104c69bc8fd1d3',
    width: 320,
    height: 50,
    scriptUrl: 'https://www.highrevenueformat.com/197b97f3d0df94919e104c69bc8fd1d3/invoke.js',
    label: 'Mobile Banner (320x50)',
  },
  '160x600': {
    key: '40d718879f78dc93b3c175c9a8a59146',
    width: 160,
    height: 600,
    scriptUrl: 'https://www.highrevenueformat.com/40d718879f78dc93b3c175c9a8a59146/invoke.js',
    label: 'Wide Skyscraper (160x600)',
  },
  '160x300': {
    key: '31e96c74d15fc6566d346f286d00ccee',
    width: 160,
    height: 300,
    scriptUrl: 'https://www.highrevenueformat.com/31e96c74d15fc6566d346f286d00ccee/invoke.js',
    label: 'Half Skyscraper (160x300)',
  },
};

interface AdBannerProps {
  size: AdSize;
  className?: string;
  showBadge?: boolean;
}

export const AdBanner: React.FC<AdBannerProps> = ({
  size,
  className = '',
  showBadge = true,
}) => {
  const config = AD_CONFIGS[size];

  if (!config) return null;

  const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: transparent;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      width: ${config.width}px;
      height: ${config.height}px;
    }
  </style>
</head>
<body>
  <script type="text/javascript">
    atOptions = {
      'key' : '${config.key}',
      'format' : 'iframe',
      'height' : ${config.height},
      'width' : ${config.width},
      'params' : {}
    };
  </script>
  <script type="text/javascript" src="${config.scriptUrl}"></script>
</body>
</html>`;

  return (
    <div className={`flex flex-col items-center justify-center my-4 ${className}`}>
      {showBadge && (
        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1 select-none">
          Sponsored Ad
        </span>
      )}
      <div
        className="overflow-hidden rounded-lg bg-slate-100/60 border border-slate-200/60 shadow-xs flex items-center justify-center"
        style={{ width: `${config.width}px`, height: `${config.height}px` }}
      >
        <iframe
          title={`Adsterra Ad ${config.width}x${config.height}`}
          srcDoc={htmlContent}
          width={config.width}
          height={config.height}
          style={{
            width: `${config.width}px`,
            height: `${config.height}px`,
            border: 'none',
            overflow: 'hidden',
          }}
          scrolling="no"
          loading="lazy"
        />
      </div>
    </div>
  );
};

/**
 * Responsive banner that automatically switches between Leaderboard (728x90) on desktop/tablet
 * and Mobile Banner (320x50) on smaller screens.
 */
export const ResponsiveLeaderboard: React.FC<{ className?: string; showBadge?: boolean }> = ({
  className = '',
  showBadge = true,
}) => {
  return (
    <div className={`w-full flex flex-col items-center justify-center ${className}`}>
      {/* Desktop & Tablet: 728x90 */}
      <div className="hidden md:block">
        <AdBanner size="728x90" showBadge={showBadge} />
      </div>
      {/* Mobile: 320x50 */}
      <div className="block md:hidden">
        <AdBanner size="320x50" showBadge={showBadge} />
      </div>
    </div>
  );
};
