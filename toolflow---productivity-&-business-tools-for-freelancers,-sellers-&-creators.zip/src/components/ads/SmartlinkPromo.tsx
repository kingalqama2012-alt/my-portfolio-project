import React from 'react';
import { ExternalLink, Sparkles, TrendingUp, Flame } from 'lucide-react';

export const SMARTLINK_URL = 'https://www.profitableratecpmnetwork.com/nc3hnzzf8j?key=250e6704dbcc8d1767a9b80ce3975321';

interface SmartlinkPromoProps {
  variant?: 'button' | 'banner' | 'card' | 'badge';
  className?: string;
  title?: string;
  description?: string;
}

export const SmartlinkPromo: React.FC<SmartlinkPromoProps> = ({
  variant = 'banner',
  className = '',
  title = 'Special Partner Deals for Freelancers & Sellers',
  description = 'Unlock verified high-converting resources, growth hacks, and exclusive tools recommended by our network.',
}) => {
  if (variant === 'button') {
    return (
      <a
        href={SMARTLINK_URL}
        target="_blank"
        rel="noopener noreferrer sponsored"
        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xs hover:from-amber-600 hover:to-orange-600 transition-all cursor-pointer ${className}`}
      >
        <Flame className="w-3.5 h-3.5 animate-pulse" />
        <span>Partner Deals</span>
        <ExternalLink className="w-3 h-3 opacity-80" />
      </a>
    );
  }

  if (variant === 'badge') {
    return (
      <a
        href={SMARTLINK_URL}
        target="_blank"
        rel="noopener noreferrer sponsored"
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition-colors ${className}`}
      >
        <Sparkles className="w-3 h-3 text-amber-500" />
        <span>Featured Partner Offer</span>
        <ExternalLink className="w-2.5 h-2.5 opacity-60" />
      </a>
    );
  }

  if (variant === 'card') {
    return (
      <div className={`rounded-xl border border-amber-200/80 bg-gradient-to-br from-amber-50/70 via-orange-50/40 to-white p-5 shadow-xs ${className}`}>
        <div className="flex items-center justify-between gap-2 mb-2">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-amber-500 text-white">
            Sponsored Partner
          </span>
          <span className="text-[11px] text-slate-400">Verified Network</span>
        </div>
        <h4 className="text-sm font-bold text-slate-900 mb-1.5 flex items-center gap-1.5">
          <TrendingUp className="w-4 h-4 text-amber-600" />
          {title}
        </h4>
        <p className="text-xs text-slate-600 mb-4 leading-relaxed">
          {description}
        </p>
        <a
          href={SMARTLINK_URL}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 text-white hover:from-amber-700 hover:to-orange-700 shadow-xs transition-all"
        >
          <span>Claim Exclusive Access</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    );
  }

  // Default: Wide Banner
  return (
    <div className={`w-full my-6 rounded-xl border border-amber-200/90 bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-amber-500/10 p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xs ${className}`}>
      <div className="flex items-start sm:items-center gap-3">
        <div className="h-10 w-10 shrink-0 rounded-lg bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-xs">
          <Flame className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded-full">
              Featured Deal
            </span>
            <span className="text-[11px] text-slate-400">Sponsored</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">{title}</h4>
          <p className="text-xs text-slate-600 mt-0.5 max-w-xl">{description}</p>
        </div>
      </div>
      <a
        href={SMARTLINK_URL}
        target="_blank"
        rel="noopener noreferrer sponsored"
        className="shrink-0 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 text-white hover:from-amber-700 hover:to-orange-700 shadow-xs transition-all"
      >
        <span>Explore Now</span>
        <ExternalLink className="w-3.5 h-3.5" />
      </a>
    </div>
  );
};
