import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  LayoutDashboard,
  Grid,
  Bookmark,
  History,
  Star,
  Settings,
  LogOut,
  Layers,
  Menu,
  X,
  ChevronRight,
  ArrowLeft,
  Sparkles,
  ExternalLink,
  DollarSign,
  Info,
} from 'lucide-react';
import { Button } from '../common/Button';

interface DashboardLayoutProps {
  children: React.ReactNode;
  currentPath: string;
  onNavigate: (path: string) => void;
  title?: string;
  subtitle?: string;
  activeNav?: 'dashboard' | 'tools' | 'saved' | 'history' | 'favorites' | 'settings' | 'pricing' | 'about';
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  children,
  currentPath,
  onNavigate,
  title,
  subtitle,
  activeNav = 'dashboard',
}) => {
  const { brandName, user, logout } = useApp();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
    { id: 'tools', label: 'Tools', icon: Grid, path: '/tools' },
    { id: 'saved', label: 'Saved', icon: Bookmark, path: '/saved' },
    { id: 'pricing', label: 'Pricing', icon: DollarSign, path: '/pricing' },
    { id: 'about', label: 'About', icon: Info, path: '/about' },
    { id: 'settings', label: 'Settings', icon: Settings, path: '/settings' },
  ];

  return (
    <div className="min-h-screen bg-[#090b10] text-zinc-100 flex flex-col md:flex-row antialiased">
      {/* Mobile Topbar */}
      <div className="md:hidden flex items-center justify-between h-16 px-4 bg-[#0d1017] border-b border-zinc-800/80 sticky top-0 z-30">
        <button
          onClick={() => onNavigate('/')}
          className="flex items-center gap-2 text-white font-bold cursor-pointer"
        >
          <div className="h-8 w-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs">
            <Layers className="h-4 w-4" />
          </div>
          <span className="tracking-tight">{brandName}</span>
        </button>

        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2 rounded-lg bg-zinc-800/80 text-zinc-300 hover:text-white border border-zinc-700/60 cursor-pointer"
          aria-label="Toggle sidebar"
        >
          {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Sidebar Overlay for Mobile */}
      {sidebarOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/70 backdrop-blur-xs z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed md:sticky top-0 left-0 h-screen w-64 bg-[#0d1017] border-r border-zinc-800/80 z-40 flex flex-col justify-between transition-transform duration-200 ease-in-out shrink-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div>
          {/* Logo Header */}
          <div className="h-16 flex items-center justify-between px-6 border-b border-zinc-800/80">
            <button
              onClick={() => onNavigate('/')}
              className="flex items-center gap-2.5 text-left group focus:outline-none cursor-pointer"
            >
              <div className="h-8 w-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs group-hover:bg-indigo-500 transition-colors">
                <Layers className="h-4 w-4" />
              </div>
              <span className="text-base font-bold text-white tracking-tight">
                {brandName}
              </span>
            </button>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 uppercase tracking-wider">
              {user?.plan?.toUpperCase() || 'PRO'}
            </span>
          </div>

          {/* Quick Return to Public Site */}
          <div className="p-3">
            <button
              onClick={() => onNavigate('/')}
              className="w-full flex items-center justify-between px-3 py-2 text-xs font-medium text-zinc-400 hover:text-white hover:bg-zinc-800/60 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-zinc-800"
            >
              <span className="flex items-center gap-2">
                <ArrowLeft className="h-3.5 w-3.5" />
                Back to Website
              </span>
              <span className="text-[10px] text-zinc-500">Home</span>
            </button>
          </div>

          {/* Nav Items */}
          <nav className="px-3 space-y-1">
            <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-zinc-500 mb-2">
              Workspace Menu
            </p>
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.path);
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-indigo-600/15 text-white font-semibold border border-indigo-500/30'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`h-4 w-4 ${isActive ? 'text-indigo-400' : 'text-zinc-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {isActive && <ChevronRight className="h-3.5 w-3.5 text-indigo-400" />}
                </button>
              );
            })}
          </nav>
        </div>

        {/* User Card & Logout at bottom */}
        <div className="p-4 border-t border-zinc-800/80">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900/80 border border-zinc-800/80 mb-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <img
                src={user?.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${user?.name || 'Alex'}`}
                alt={user?.name || 'User'}
                className="h-8 w-8 rounded-full object-cover bg-zinc-800 shrink-0 border border-zinc-700"
              />
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white truncate">
                  {user?.name || 'Alex'}
                </p>
                <p className="text-[11px] text-zinc-400 truncate">
                  {user?.email || 'alex@toolflow.dev'}
                </p>
              </div>
            </div>
            <button
              onClick={() => logout()}
              title="Sign Out"
              className="p-1.5 text-zinc-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-md transition-colors cursor-pointer"
              aria-label="Log Out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>

          <button
            onClick={() => onNavigate('/pricing')}
            className="w-full flex items-center justify-between p-2.5 rounded-lg bg-zinc-900/60 border border-zinc-800 text-zinc-300 text-xs font-medium hover:border-zinc-700 hover:text-white transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="h-3.5 w-3.5 text-indigo-400 shrink-0" />
              <span>{user?.plan ? `${user.plan.toUpperCase()} Tier` : 'PRO Plan Active'}</span>
            </div>
            <ExternalLink className="h-3 w-3 text-zinc-500" />
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 min-w-0 overflow-y-auto">
        {(title || subtitle) && (
          <header className="bg-[#0d1017]/80 backdrop-blur-md border-b border-zinc-800/80 px-4 sm:px-8 py-5">
            <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                {title && <h1 className="text-2xl font-bold text-white tracking-tight">{title}</h1>}
                {subtitle && <p className="text-sm text-zinc-400 mt-1">{subtitle}</p>}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onNavigate('/tools')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-zinc-800/90 text-zinc-200 border border-zinc-700/80 hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition-colors cursor-pointer"
                >
                  <Grid className="h-3.5 w-3.5" />
                  <span>Explore All Tools</span>
                </button>
              </div>
            </div>
          </header>
        )}
        <div className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8">{children}</div>
      </main>
    </div>
  );
};
