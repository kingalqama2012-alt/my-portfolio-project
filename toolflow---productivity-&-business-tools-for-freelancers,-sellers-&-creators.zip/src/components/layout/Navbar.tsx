import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Button } from '../common/Button';
import { Menu, X, Layers, ChevronDown, User, LogOut, Bookmark, LayoutDashboard, Settings } from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate }) => {
  const { brandName, user, isAuthenticated, logout } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Tools', path: '/tools' },
    { label: 'Pricing', path: '/pricing' },
    { label: 'About', path: '/about' },
  ];

  const handleLinkClick = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo & Brand */}
          <div className="flex items-center gap-8">
            <a
              href="/"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  handleLinkClick('/');
                }
              }}
              className="flex items-center gap-2.5 text-left group focus:outline-none cursor-pointer"
            >
              <div className="h-9 w-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs group-hover:bg-indigo-700 transition-colors">
                <Layers className="h-5 w-5" />
              </div>
              <div>
                <span className="text-lg font-bold tracking-tight text-slate-900 flex items-center gap-1">
                  {brandName}
                  <span className="h-1.5 w-1.5 rounded-full bg-indigo-600 inline-block"></span>
                </span>
              </div>
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => {
                const isActive = currentPath === link.path;
                return (
                  <a
                    key={link.path}
                    href={link.path}
                    onClick={(e) => {
                      if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                        e.preventDefault();
                        handleLinkClick(link.path);
                      }
                    }}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors cursor-pointer ${
                      isActive
                        ? 'text-indigo-600 bg-indigo-50/70 font-semibold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    {link.label}
                  </a>
                );
              })}
              {/* Adsterra Smartlink 31491249 */}
              <a
                href="https://www.profitableratecpmnetwork.com/nc3hnzzf8j?key=250e6704dbcc8d1767a9b80ce3975321"
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="ml-2 inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-gradient-to-r from-amber-500/15 to-orange-500/15 text-amber-700 hover:from-amber-500/25 hover:to-orange-500/25 border border-amber-300/60 transition-all cursor-pointer shadow-2xs"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                <span>🔥 Partner Deals</span>
              </a>
            </nav>
          </div>

          {/* Right Action Buttons */}
          <div className="hidden md:flex items-center gap-3">
            {isAuthenticated && user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 transition-colors border border-slate-200 text-left cursor-pointer"
                >
                  <img
                    src={user.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`}
                    alt={user.name}
                    className="h-7 w-7 rounded-full object-cover bg-slate-100"
                  />
                  <span className="text-xs font-semibold text-slate-700 max-w-[100px] truncate">
                    {user.name}
                  </span>
                  <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white p-1.5 shadow-lg border border-slate-200 z-50">
                    <div className="px-3 py-2 border-b border-slate-100 mb-1">
                      <p className="text-xs font-semibold text-slate-900">{user.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                    </div>
                    <button
                      onClick={() => handleLinkClick('/dashboard')}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg text-left cursor-pointer"
                    >
                      <LayoutDashboard className="h-4 w-4 text-slate-500" />
                      Dashboard
                    </button>
                    <button
                      onClick={() => handleLinkClick('/saved')}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg text-left cursor-pointer"
                    >
                      <Bookmark className="h-4 w-4 text-slate-500" />
                      Saved Results
                    </button>
                    <button
                      onClick={() => handleLinkClick('/settings')}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg text-left cursor-pointer"
                    >
                      <Settings className="h-4 w-4 text-slate-500" />
                      Settings
                    </button>
                    <div className="border-t border-slate-100 my-1" />
                    <button
                      onClick={() => {
                        logout();
                        setUserDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 rounded-lg text-left cursor-pointer"
                    >
                      <LogOut className="h-4 w-4" />
                      Log Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleLinkClick('/login')}
                >
                  Log In
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => handleLinkClick('/signup')}
                >
                  Get Started Free
                </Button>
              </>
            )}

            <Button
              variant="outline"
              size="sm"
              onClick={() => handleLinkClick('/dashboard')}
              leftIcon={<LayoutDashboard className="h-3.5 w-3.5" />}
            >
              Dashboard
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-5 shadow-lg">
          <div className="flex flex-col gap-1.5">
            {navLinks.map((link) => (
              <a
                key={link.path}
                href={link.path}
                onClick={(e) => {
                  if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                    e.preventDefault();
                    handleLinkClick(link.path);
                  }
                }}
                className={`flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium text-left cursor-pointer ${
                  currentPath === link.path
                    ? 'text-indigo-600 bg-indigo-50 font-semibold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                {link.label}
              </a>
            ))}

            {/* Mobile Smartlink */}
            <a
              href="https://www.profitableratecpmnetwork.com/nc3hnzzf8j?key=250e6704dbcc8d1767a9b80ce3975321"
              target="_blank"
              rel="noopener noreferrer sponsored"
              className="flex items-center justify-between px-3 py-2 rounded-lg text-sm font-semibold text-amber-700 bg-amber-50 border border-amber-200/80"
            >
              <span>🔥 Exclusive Partner Deals</span>
              <span className="text-[10px] uppercase tracking-wider bg-amber-500 text-white px-1.5 py-0.5 rounded">Hot</span>
            </a>

            <div className="border-t border-slate-100 my-2" />

            <button
              onClick={() => handleLinkClick('/dashboard')}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
            >
              <LayoutDashboard className="h-4 w-4 text-indigo-600" />
              Workspace Dashboard
            </button>

            <button
              onClick={() => handleLinkClick('/saved')}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
            >
              <Bookmark className="h-4 w-4 text-indigo-600" />
              Saved Results
            </button>

            <button
              onClick={() => handleLinkClick('/settings')}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
            >
              <Settings className="h-4 w-4 text-indigo-600" />
              Settings
            </button>

            <div className="border-t border-slate-100 my-2" />

            {isAuthenticated ? (
              <Button
                variant="outline"
                size="sm"
                className="w-full text-rose-600 border-rose-200"
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
              >
                Log Out
              </Button>
            ) : (
              <div className="flex flex-col gap-2 pt-1">
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => handleLinkClick('/login')}
                >
                  Log In
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  className="w-full"
                  onClick={() => handleLinkClick('/signup')}
                >
                  Get Started Free
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
