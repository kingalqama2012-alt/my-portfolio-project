import React from 'react';
import { useApp } from '../../context/AppContext';
import { Layers, Twitter, Linkedin, Github, Youtube, Sparkles } from 'lucide-react';
import { ResponsiveLeaderboard } from '../ads';

interface FooterProps {
  onNavigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { brandName } = useApp();

  return (
    <footer className="border-t border-slate-200 bg-white text-slate-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand Info */}
          <div className="col-span-2">
            <a
              href="/"
              onClick={(e) => {
                if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                  e.preventDefault();
                  onNavigate('/');
                }
              }}
              className="flex items-center gap-2 mb-3 group cursor-pointer text-left"
            >
              <div className="h-8 w-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white group-hover:bg-indigo-700 transition-colors">
                <Layers className="h-4 w-4" />
              </div>
              <span className="text-lg font-bold text-slate-900 tracking-tight">{brandName}</span>
            </a>
            <p className="text-sm text-slate-500 max-w-sm leading-relaxed mb-6">
              The all-in-one productivity and business toolkit built for freelancers, Amazon sellers, and creators. Work faster with calculators, AI generators, and revenue diagnostics.
            </p>
            <div className="flex items-center gap-3 text-slate-400">
              <a
                href="#twitter"
                onClick={(e) => e.preventDefault()}
                className="p-2 rounded-lg hover:bg-slate-100 hover:text-slate-700 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="#linkedin"
                onClick={(e) => e.preventDefault()}
                className="p-2 rounded-lg hover:bg-slate-100 hover:text-slate-700 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a
                href="#github"
                onClick={(e) => e.preventDefault()}
                className="p-2 rounded-lg hover:bg-slate-100 hover:text-slate-700 transition-colors"
                aria-label="GitHub"
              >
                <Github className="h-4 w-4" />
              </a>
              <a
                href="#youtube"
                onClick={(e) => e.preventDefault()}
                className="p-2 rounded-lg hover:bg-slate-100 hover:text-slate-700 transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Tools */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-4">
              Tools
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href="/tools?category=freelancer"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/tools?category=freelancer');
                    }
                  }}
                  className="hover:text-indigo-600 transition-colors cursor-pointer text-left block"
                >
                  Freelancer Tools
                </a>
              </li>
              <li>
                <a
                  href="/tools?category=amazon"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/tools?category=amazon');
                    }
                  }}
                  className="hover:text-indigo-600 transition-colors cursor-pointer text-left block"
                >
                  Amazon Tools
                </a>
              </li>
              <li>
                <a
                  href="/tools?category=creator"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/tools?category=creator');
                    }
                  }}
                  className="hover:text-indigo-600 transition-colors cursor-pointer text-left block"
                >
                  Creator Tools
                </a>
              </li>
              <li>
                <a
                  href="/tools"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/tools');
                    }
                  }}
                  className="hover:text-indigo-600 transition-colors cursor-pointer text-left font-medium text-slate-900 block"
                >
                  All Tools Directory
                </a>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-4">
              Company
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href="/about"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/about');
                    }
                  }}
                  className="hover:text-indigo-600 transition-colors cursor-pointer text-left block"
                >
                  About
                </a>
              </li>
              <li>
                <a
                  href="/pricing"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/pricing');
                    }
                  }}
                  className="hover:text-indigo-600 transition-colors cursor-pointer text-left block"
                >
                  Pricing
                </a>
              </li>
              <li>
                <a
                  href="/contact"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/contact');
                    }
                  }}
                  className="hover:text-indigo-600 transition-colors cursor-pointer text-left block"
                >
                  Contact
                </a>
              </li>
              <li>
                <a
                  href="/dashboard"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/dashboard');
                    }
                  }}
                  className="hover:text-indigo-600 transition-colors cursor-pointer text-left block"
                >
                  App Dashboard
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-4">
              Resources &amp; Legal
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href="https://www.profitableratecpmnetwork.com/nc3hnzzf8j?key=250e6704dbcc8d1767a9b80ce3975321"
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="inline-flex items-center gap-1.5 text-amber-700 font-semibold hover:text-amber-800"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>🔥 Exclusive Deals</span>
                </a>
              </li>
              <li>
                <a
                  href="/guides/how-to-calculate-freelance-hourly-rate"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/guides/how-to-calculate-freelance-hourly-rate');
                    }
                  }}
                  className="text-slate-600 cursor-pointer hover:text-indigo-600 block"
                >
                  Hourly Rate Guide
                </a>
              </li>
              <li>
                <a
                  href="/privacy"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/privacy');
                    }
                  }}
                  className="text-slate-600 cursor-pointer hover:text-indigo-600 block"
                >
                  Privacy Policy
                </a>
              </li>
              <li>
                <a
                  href="/terms"
                  onClick={(e) => {
                    if (!e.ctrlKey && !e.metaKey && e.button === 0) {
                      e.preventDefault();
                      onNavigate('/terms');
                    }
                  }}
                  className="text-slate-600 cursor-pointer hover:text-indigo-600 block"
                >
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Adsterra Footer Responsive Banner (728x90 desktop / 320x50 mobile) */}
        <div className="mt-10 pt-6 border-t border-slate-200/60 flex justify-center">
          <ResponsiveLeaderboard />
        </div>

        <div className="mt-8 pt-6 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 {brandName}. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span>Built for modern digital professionals</span>
            <span className="inline-flex items-center gap-1.5 text-emerald-600 font-medium">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
              All Systems Operational
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
