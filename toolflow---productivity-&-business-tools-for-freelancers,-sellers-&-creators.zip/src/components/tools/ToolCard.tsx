import React from 'react';
import { ToolItem } from '../../types';
import { Card } from '../common/Card';
import { Badge } from '../common/Badge';
import { Button } from '../common/Button';
import { IconHelper } from '../common/IconHelper';
import { Star, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface ToolCardProps {
  tool: ToolItem;
  onNavigate: (path: string) => void;
  compact?: boolean;
  variant?: 'light' | 'dark';
}

export const ToolCard: React.FC<ToolCardProps> = ({
  tool,
  onNavigate,
  compact = false,
  variant = 'light',
}) => {
  const { isFavorite, toggleFavorite, trackToolUsage } = useApp();
  const favorited = isFavorite(tool.id);

  const handleOpen = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    trackToolUsage(tool.id);
    onNavigate(tool.path);
  };

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(tool.id);
  };

  const categoryBadgeVariants: Record<string, 'indigo' | 'amber' | 'rose'> = {
    freelancer: 'indigo',
    amazon: 'amber',
    creator: 'rose',
  };

  const isDark = variant === 'dark';

  return (
    <div
      onClick={handleOpen}
      className={`flex flex-col justify-between p-5 sm:p-6 transition-all duration-200 group relative rounded-xl border cursor-pointer ${
        isDark
          ? 'bg-[#121624] border-zinc-800/80 hover:border-zinc-700 hover:shadow-xl hover:shadow-black/40 hover:-translate-y-1'
          : 'bg-white border-slate-200/80 hover:border-slate-300 hover:shadow-md hover:-translate-y-0.5'
      }`}
    >
      <div>
        <div className="flex items-start justify-between gap-3 mb-4">
          <div
            className={`p-3 rounded-xl transition-colors ${
              isDark
                ? 'bg-zinc-800/80 text-indigo-400 group-hover:bg-indigo-500/20 group-hover:text-indigo-300 border border-zinc-700/40'
                : 'bg-slate-100/90 text-indigo-600 group-hover:bg-indigo-50 group-hover:text-indigo-700'
            }`}
          >
            <IconHelper name={tool.iconName} className="h-6 w-6" />
          </div>

          <div className="flex items-center gap-1.5">
            {tool.badge && (
              <Badge variant={categoryBadgeVariants[tool.category]} size="sm">
                {tool.badge}
              </Badge>
            )}
            <button
              onClick={handleToggleFavorite}
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                favorited
                  ? 'text-amber-400 fill-amber-400'
                  : isDark
                  ? 'text-zinc-600 hover:text-zinc-300 hover:bg-zinc-800/60'
                  : 'text-slate-300 hover:text-slate-500 hover:bg-slate-100'
              }`}
              title={favorited ? 'Remove from favorites' : 'Add to favorites'}
              aria-label="Toggle favorite"
            >
              <Star className={`h-4 w-4 ${favorited ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>

        <div className="mb-2">
          <span
            className={`text-[10px] font-bold uppercase tracking-wider ${
              isDark ? 'text-zinc-500' : 'text-slate-400'
            }`}
          >
            {tool.categoryLabel}
          </span>
          <h3
            className={`text-base sm:text-lg font-bold tracking-tight transition-colors ${
              isDark
                ? 'text-white group-hover:text-indigo-400'
                : 'text-slate-900 group-hover:text-indigo-600'
            }`}
          >
            <a
              href={tool.path}
              onClick={handleOpen}
              className="hover:underline focus:outline-none"
            >
              {tool.name}
            </a>
          </h3>
        </div>

        <p
          className={`text-xs sm:text-sm leading-relaxed mb-6 ${
            isDark ? 'text-zinc-400' : 'text-slate-600'
          }`}
        >
          {compact ? tool.shortDescription : tool.description}
        </p>
      </div>

      <div
        className={`pt-4 border-t flex items-center justify-between mt-auto ${
          isDark ? 'border-zinc-800/80' : 'border-slate-100'
        }`}
      >
        <span
          className={`text-xs font-medium flex items-center gap-1 transition-colors ${
            isDark
              ? 'text-zinc-500 group-hover:text-indigo-400'
              : 'text-slate-500 group-hover:text-indigo-600'
          }`}
        >
          Launch utility
        </span>
        <a
          href={tool.path}
          onClick={handleOpen}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
            isDark
              ? 'bg-zinc-800/90 text-zinc-200 border-zinc-700/80 group-hover:bg-indigo-600 group-hover:text-white group-hover:border-indigo-600'
              : 'bg-white text-slate-700 border-slate-300 group-hover:bg-indigo-600 group-hover:text-white group-hover:border-indigo-600'
          }`}
          aria-label={`Open ${tool.name}`}
        >
          <span>Open Tool</span>
          <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
        </a>
      </div>
    </div>
  );
};
