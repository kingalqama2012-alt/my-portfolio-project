import React from 'react';
import { Card } from './Card';

interface StatCardProps {
  label: string;
  value: string | number;
  subtext?: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon?: React.ReactNode;
  variant?: 'default' | 'highlight' | 'success' | 'warning';
  dark?: boolean;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  subtext,
  change,
  changeType = 'neutral',
  icon,
  variant = 'default',
  dark = false,
}) => {
  const lightVariantStyles = {
    default: 'bg-white border-slate-200/80',
    highlight: 'bg-indigo-50/40 border-indigo-200/70',
    success: 'bg-emerald-50/40 border-emerald-200/70',
    warning: 'bg-amber-50/40 border-amber-200/70',
  };

  const darkVariantStyles = {
    default: 'bg-[#11141f] border-zinc-800/80 hover:border-zinc-700',
    highlight: 'bg-[#11141f] border-indigo-500/40 hover:border-indigo-400/60',
    success: 'bg-[#11141f] border-emerald-500/30 hover:border-emerald-400/50',
    warning: 'bg-[#11141f] border-amber-500/30 hover:border-amber-400/50',
  };

  const changeColors = {
    positive: 'text-emerald-700 bg-emerald-50 border border-emerald-200/50',
    negative: 'text-rose-700 bg-rose-50 border border-rose-200/50',
    neutral: dark ? 'text-zinc-300 bg-zinc-800 border border-zinc-700' : 'text-slate-600 bg-slate-100',
  };

  return (
    <Card className={`p-5 transition-colors ${dark ? darkVariantStyles[variant] : lightVariantStyles[variant]}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className={`text-xs font-semibold uppercase tracking-wider ${dark ? 'text-zinc-400' : 'text-slate-500'}`}>
            {label}
          </p>
          <p className={`text-2xl lg:text-3xl font-bold mt-1.5 font-mono tracking-tight ${dark ? 'text-white' : 'text-slate-900'}`}>
            {value}
          </p>
        </div>
        {icon && (
          <div className={`p-2.5 rounded-lg shrink-0 ${dark ? 'bg-zinc-800/80 text-zinc-300 border border-zinc-700/50' : 'bg-slate-100 text-slate-600'}`}>
            {icon}
          </div>
        )}
      </div>

      {(subtext || change) && (
        <div className={`mt-3 flex items-center gap-2 pt-2 border-t ${dark ? 'border-zinc-800/80' : 'border-slate-100/80'}`}>
          {change && (
            <span className={`text-xs font-medium px-1.5 py-0.5 rounded ${changeColors[changeType]}`}>
              {change}
            </span>
          )}
          {subtext && <span className={`text-xs ${dark ? 'text-zinc-400' : 'text-slate-500'}`}>{subtext}</span>}
        </div>
      )}
    </Card>
  );
};
