import React from 'react';
import {
  FileText,
  Calculator,
  TrendingUp,
  BarChart3,
  Search,
  Sparkles,
  Share2,
  Briefcase,
  ShoppingBag,
  Video,
  Star,
  ArrowRight,
  Copy,
  Check,
  RotateCcw,
  Edit3,
  Bookmark,
  Trash2,
  ExternalLink,
  ChevronRight,
  Shield,
  Zap,
  Clock,
  Layers,
  HelpCircle,
  AlertCircle,
  CheckCircle2,
  Info,
  DollarSign,
  Percent,
  TrendingDown,
  User,
  Settings,
  Grid,
  Menu,
  X,
  LogOut,
  Sliders,
  Bell,
  Code,
  Lock,
  Radar,
  Target,
  Stethoscope,
  Activity,
  Hash,
  FlaskConical,
  Shuffle,
  LucideProps,
} from 'lucide-react';

interface IconHelperProps extends LucideProps {
  name: string;
}

export const IconHelper: React.FC<IconHelperProps> = ({ name, ...props }) => {
  switch (name) {
    case 'Radar':
      return <Radar {...props} />;
    case 'Target':
      return <Target {...props} />;
    case 'Stethoscope':
      return <Stethoscope {...props} />;
    case 'Activity':
      return <Activity {...props} />;
    case 'Hash':
      return <Hash {...props} />;
    case 'FlaskConical':
      return <FlaskConical {...props} />;
    case 'Shuffle':
      return <Shuffle {...props} />;
    case 'FileText':
      return <FileText {...props} />;
    case 'Calculator':
      return <Calculator {...props} />;
    case 'TrendingUp':
      return <TrendingUp {...props} />;
    case 'BarChart3':
      return <BarChart3 {...props} />;
    case 'Search':
      return <Search {...props} />;
    case 'Sparkles':
      return <Sparkles {...props} />;
    case 'Share2':
      return <Share2 {...props} />;
    case 'Briefcase':
      return <Briefcase {...props} />;
    case 'ShoppingBag':
      return <ShoppingBag {...props} />;
    case 'Video':
      return <Video {...props} />;
    case 'Star':
      return <Star {...props} />;
    case 'ArrowRight':
      return <ArrowRight {...props} />;
    case 'Copy':
      return <Copy {...props} />;
    case 'Check':
      return <Check {...props} />;
    case 'RotateCcw':
      return <RotateCcw {...props} />;
    case 'Edit3':
      return <Edit3 {...props} />;
    case 'Bookmark':
      return <Bookmark {...props} />;
    case 'Trash2':
      return <Trash2 {...props} />;
    case 'ExternalLink':
      return <ExternalLink {...props} />;
    case 'ChevronRight':
      return <ChevronRight {...props} />;
    case 'Shield':
      return <Shield {...props} />;
    case 'Zap':
      return <Zap {...props} />;
    case 'Clock':
      return <Clock {...props} />;
    case 'Layers':
      return <Layers {...props} />;
    case 'HelpCircle':
      return <HelpCircle {...props} />;
    case 'AlertCircle':
      return <AlertCircle {...props} />;
    case 'CheckCircle2':
      return <CheckCircle2 {...props} />;
    case 'Info':
      return <Info {...props} />;
    case 'DollarSign':
      return <DollarSign {...props} />;
    case 'Percent':
      return <Percent {...props} />;
    case 'TrendingDown':
      return <TrendingDown {...props} />;
    case 'User':
      return <User {...props} />;
    case 'Settings':
      return <Settings {...props} />;
    case 'Grid':
      return <Grid {...props} />;
    case 'Menu':
      return <Menu {...props} />;
    case 'X':
      return <X {...props} />;
    case 'LogOut':
      return <LogOut {...props} />;
    case 'Sliders':
      return <Sliders {...props} />;
    case 'Bell':
      return <Bell {...props} />;
    case 'Code':
      return <Code {...props} />;
    case 'Lock':
      return <Lock {...props} />;
    default:
      return <Sparkles {...props} />;
  }
};
