import { AmazonKeywordFormData, KeywordItem } from '../types';

export interface KeywordResult {
  keywords: KeywordItem[];
  isGemini: boolean;
}

export function generateLocalKeywordsFallback(data: AmazonKeywordFormData): KeywordItem[] {
  const { productName, productCategory, mainFeatures, targetMarket } = data;

  const cleanName = productName.trim().toLowerCase();
  const tokens = cleanName.split(/\s+/).filter(Boolean);
  const featureList = mainFeatures
    .split(/[,;\n]+/)
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  const target = targetMarket.trim().toLowerCase() || 'online shoppers';

  const results: KeywordItem[] = [];

  // Exact / High Intent keywords
  results.push(
    { keyword: `${cleanName}`, type: 'Exact / High Intent', searchVolume: 'Very High', relevance: 99 },
    { keyword: `best ${cleanName} for ${target}`, type: 'Exact / High Intent', searchVolume: 'High', relevance: 96 },
    { keyword: `${cleanName} prime delivery`, type: 'Exact / High Intent', searchVolume: 'High', relevance: 94 },
    { keyword: `premium ${cleanName}`, type: 'Exact / High Intent', searchVolume: 'Medium', relevance: 90 }
  );

  // Long-Tail keywords
  if (featureList.length > 0) {
    featureList.forEach((feat, idx) => {
      results.push({
        keyword: `${cleanName} with ${feat}`,
        type: 'Long-Tail',
        searchVolume: idx === 0 ? 'High' : 'Medium',
        relevance: 92 - idx * 3,
      });
      results.push({
        keyword: `${feat} ${cleanName} for ${target}`,
        type: 'Long-Tail',
        searchVolume: 'Medium',
        relevance: 88 - idx * 2,
      });
    });
  } else {
    results.push(
      { keyword: `heavy duty ${cleanName}`, type: 'Long-Tail', searchVolume: 'Medium', relevance: 87 },
      { keyword: `portable ${cleanName} compact size`, type: 'Long-Tail', searchVolume: 'Medium', relevance: 85 }
    );
  }

  // Broad Match keywords
  results.push(
    { keyword: `${cleanName} deals on amazon`, type: 'Broad Match', searchVolume: 'Trending', relevance: 84 },
    { keyword: `${productCategory.toLowerCase()} ${tokens[0] || 'product'} accessories`, type: 'Broad Match', searchVolume: 'Medium', relevance: 81 },
    { keyword: `top rated ${cleanName} 2026`, type: 'Broad Match', searchVolume: 'High', relevance: 89 },
    { keyword: `gift ideas ${cleanName} for ${target}`, type: 'Broad Match', searchVolume: 'Medium', relevance: 82 }
  );

  // Competitor / Feature / Comparison keywords
  results.push(
    { keyword: `${cleanName} replacement alternative`, type: 'Competitor / Feature', searchVolume: 'Medium', relevance: 79 },
    { keyword: `${cleanName} vs standard brands`, type: 'Competitor / Feature', searchVolume: 'Medium', relevance: 76 },
    { keyword: `durable ${cleanName} set`, type: 'Competitor / Feature', searchVolume: 'High', relevance: 86 }
  );

  return results;
}

export async function generateAmazonKeywords(
  data: AmazonKeywordFormData,
  allowFallback = false
): Promise<KeywordResult> {
  try {
    const res = await fetch('/api/generate-keywords', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    const json = await res.json();

    if (!res.ok) {
      if (allowFallback) {
        return {
          keywords: generateLocalKeywordsFallback(data),
          isGemini: false,
        };
      }
      throw new Error(json.error || 'Gemini Keyword API call failed.');
    }

    return {
      keywords: json.keywords || [],
      isGemini: true,
    };
  } catch (error: any) {
    if (allowFallback) {
      return {
        keywords: generateLocalKeywordsFallback(data),
        isGemini: false,
      };
    }
    throw error;
  }
}
