import { SocialCaptionFormData, GeneratedCaption } from '../types';

export interface CaptionResult {
  captions: GeneratedCaption[];
  isGemini: boolean;
}

export function generateLocalCaptionsFallback(data: SocialCaptionFormData): GeneratedCaption[] {
  const { topic, platform, tone, captionCount } = data;

  const platformGuides: Record<string, { ctaSuffix: string; maxTags: number }> = {
    Instagram: {
      ctaSuffix: 'Save this post to revisit before your next launch! 📌 Drop your thoughts below 👇',
      maxTags: 6,
    },
    TikTok: {
      ctaSuffix: 'Follow for part 2 🚀 What would you add to this?',
      maxTags: 4,
    },
    LinkedIn: {
      ctaSuffix: 'Agree or disagree? I would love to hear how your team approaches this in the comments.',
      maxTags: 3,
    },
    Facebook: {
      ctaSuffix: 'Tag a colleague or friend who needs to see this today! What are your thoughts?',
      maxTags: 4,
    },
    YouTube: {
      ctaSuffix: 'Subscribe for weekly deep-dives and check the link in the pinned comment for the full resource guide.',
      maxTags: 5,
    },
  };

  const selectedPlatform = platformGuides[platform] || platformGuides.Instagram;

  const hookTemplates: Record<string, string[]> = {
    Professional: [
      `The most overlooked strategy when dealing with ${topic}:`,
      `Why most professionals struggle with ${topic} (and how top 1% solve it):`,
      `A high-leverage framework for mastering ${topic} in 2026:`,
    ],
    Funny: [
      `Me pretending I have ${topic} completely figured out: 🙃`,
      `Nobody warned me that ${topic} would look like this:`,
      `My brain trying to organize ${topic} at 2 AM:`,
    ],
    Educational: [
      `3 actionable rules for ${topic} you can implement in under 10 minutes:`,
      `Stop doing this if you want better results with ${topic}:`,
      `The step-by-step breakdown of how ${topic} actually functions:`,
    ],
    Inspirational: [
      `One year from now, you will wish you had started ${topic} today:`,
      `The only thing standing between you and breakthrough results in ${topic}:`,
      `Small consistent efforts with ${topic} create compound results:`,
    ],
    Casual: [
      `Quick honest thoughts on ${topic} right now:`,
      `Let's talk about ${topic} for a second:`,
      `A few quick lessons learned while testing ${topic}:`,
    ],
  };

  const topicTag = topic.toLowerCase().replace(/[^a-z0-9]/g, '');
  const baseHashtags = [
    `#${topicTag || 'productivity'}`,
    `#${platform.toLowerCase()}growth`,
    '#contentcreator',
    '#strategy2026',
    '#smarttools',
  ];

  const captions: GeneratedCaption[] = [];
  const toneHooks = hookTemplates[tone] || hookTemplates.Professional;

  for (let i = 0; i < captionCount; i++) {
    const hook = toneHooks[i % toneHooks.length];
    const bodyPoints = [
      `1. Focus on signal over noise. Many spend 80% of their energy on secondary tweaks instead of primary fundamentals.`,
      `2. Establish a repeatable system. Consistency outperforms sporadic bursts of inspiration every single time.`,
      `3. Measure what moves the needle and eliminate friction early.`,
    ];

    const fullBody = bodyPoints.join('\n\n');
    const tags = baseHashtags.slice(0, selectedPlatform.maxTags);
    const fullText = `${hook}\n\n${fullBody}\n\n${selectedPlatform.ctaSuffix}\n\n${tags.join(' ')}`;

    captions.push({
      id: `cap_fallback_${Date.now()}_${i}`,
      hook,
      body: fullBody,
      callToAction: selectedPlatform.ctaSuffix,
      hashtags: tags,
      fullText,
      charCount: fullText.length,
    });
  }

  return captions;
}

export async function generateSocialCaptions(
  data: SocialCaptionFormData,
  allowFallback = false
): Promise<CaptionResult> {
  try {
    const res = await fetch('/api/generate-captions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    const json = await res.json();

    if (!res.ok) {
      if (allowFallback) {
        return {
          captions: generateLocalCaptionsFallback(data),
          isGemini: false,
        };
      }
      throw new Error(json.error || 'Gemini Captions API call failed.');
    }

    return {
      captions: json.captions || [],
      isGemini: true,
    };
  } catch (error: any) {
    if (allowFallback) {
      return {
        captions: generateLocalCaptionsFallback(data),
        isGemini: false,
      };
    }
    throw error;
  }
}
