import {
  TrendRadarFormData,
  TrendRadarResult,
  ContentGapFormData,
  ContentGapResult,
  HookDoctorFormData,
  HookDoctorResult,
  VideoPerformanceFormData,
  VideoPerformanceResult,
  HashtagMixerFormData,
  HashtagMixerResult,
  ContentExperimentFormData,
  ContentExperimentResult,
} from '../types';

const AI_DISCLAIMER =
  'Notice: These recommendations and trend indicators are AI-assisted analytical estimates based on audience interest patterns and your provided inputs. No tool can guarantee views, followers, or algorithmic virality.';

// ==========================================
// 1. TREND RADAR SERVICE & FALLBACK
// ==========================================
export function getLocalTrendRadarFallback(data: TrendRadarFormData): TrendRadarResult {
  const { platform, niche, targetCountry, contentFormat, optionalTopic } = data;
  const baseTopic = optionalTopic?.trim() || niche;

  return {
    isAiAnalysis: false,
    disclaimer: AI_DISCLAIMER,
    trends: [
      {
        topic: `Beginner-Friendly Frameworks for ${baseTopic}`,
        trendStatus: 'Growing',
        whyRelevant: `Audience demand in ${targetCountry || 'global markets'} is shifting from basic definitions toward actionable, step-by-step implementation templates.`,
        contentAngles: [
          `3 common mistakes that cost creators time with ${baseTopic}`,
          `The complete 0-to-1 blueprint that actually works in 2026`,
          `Why conventional advice on ${baseTopic} is outdated`,
        ],
        searchTerms: [
          `how to learn ${baseTopic} fast`,
          `${baseTopic} roadmap for beginners`,
          `best tools for ${baseTopic} 2026`,
          `${baseTopic} step by step tutorial`,
        ],
        hashtags: [
          `#${niche.replace(/\s+/g, '')}`,
          `#${baseTopic.replace(/\s+/g, '')}Tips`,
          `#Learn${baseTopic.replace(/\s+/g, '')}`,
          `#ContentCreator`,
          `#${platform.replace(/\s+/g, '')}Growth`,
        ],
        suggestedVideoIdea: `A fast-paced 45-second ${contentFormat} breaking down the exact 3-step checklist to master ${baseTopic} without overwhelm.`,
      },
      {
        topic: `Budget vs. Premium Tools in ${niche}`,
        trendStatus: 'Emerging',
        whyRelevant: `Economic mindfulness has created strong viewer interest in cost-effective alternatives and realistic gear or software breakdowns.`,
        contentAngles: [
          `Free tools that perform like expensive industry software`,
          `What I would never buy again as an experienced operator`,
          `The minimal viable setup for high output in ${niche}`,
        ],
        searchTerms: [
          `best free tools for ${baseTopic}`,
          `${niche} software comparison`,
          `is paid ${baseTopic} worth it`,
          `budget setup for ${niche}`,
        ],
        hashtags: [
          `#${niche.replace(/\s+/g, '')}Hacks`,
          `#ProductivityTools`,
          `#CreatorEconomy`,
          `#TechReview`,
          `#FreeAlternatives`,
        ],
        suggestedVideoIdea: `Side-by-side comparison putting a free open-source resource against an industry standard paid product.`,
      },
      {
        topic: `Workflow Automation & AI Assisted ${baseTopic}`,
        trendStatus: 'Established',
        whyRelevant: `High ongoing search volume across ${platform} as professionals look to save hours on repetitive manual tasks.`,
        contentAngles: [
          `Automating 80% of routine tasks in ${baseTopic}`,
          `How modern creators cut turnaround times in half`,
          `Case study: Streamlining a messy workflow step-by-step`,
        ],
        searchTerms: [
          `${baseTopic} automation guide`,
          `AI workflow for ${niche}`,
          `how to scale ${baseTopic}`,
          `speed up ${niche} workflow`,
        ],
        hashtags: [
          `#Automation`,
          `#AIWorkflow`,
          `#${niche.replace(/\s+/g, '')}Strategy`,
          `#SmartWork`,
          `#Efficiency`,
        ],
        suggestedVideoIdea: `Screen-recording walkthrough showing the "Before vs. After" of an automated workflow with time-saved metrics.`,
      },
      {
        topic: `Unpopular Truths & Contrarian Perspectives on ${baseTopic}`,
        trendStatus: 'Growing',
        whyRelevant: `Audiences are fatigued by generic advice; provocative yet grounded takes trigger high comment debates and shareability.`,
        contentAngles: [
          `Why the most popular advice about ${baseTopic} often fails`,
          `What nobody tells you about building in ${niche}`,
          `Stop doing this popular tactic immediately`,
        ],
        searchTerms: [
          `is ${baseTopic} still worth it`,
          `${niche} myths debunked`,
          `the harsh reality of ${baseTopic}`,
          `common mistakes in ${niche}`,
        ],
        hashtags: [
          `#HotTake`,
          `#${niche.replace(/\s+/g, '')}Reality`,
          `#TruthAbout${baseTopic.replace(/\s+/g, '')}`,
          `#CreatorAdvice`,
          `#DeepDive`,
        ],
        suggestedVideoIdea: `Direct-to-camera hook stating: "Almost everyone gets this wrong about ${baseTopic}..." followed by data and practical proof.`,
      },
    ],
  };
}

export async function fetchTrendRadar(data: TrendRadarFormData): Promise<TrendRadarResult> {
  try {
    const res = await fetch('/api/creator/trend-radar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }

    const json = await res.json();
    return {
      trends: json.trends,
      disclaimer: AI_DISCLAIMER,
      isAiAnalysis: true,
    };
  } catch (err) {
    console.warn('Using local fallback for Trend Radar:', err);
    return getLocalTrendRadarFallback(data);
  }
}

// ==========================================
// 2. CONTENT GAP FINDER SERVICE & FALLBACK
// ==========================================
export function getLocalContentGapFallback(data: ContentGapFormData): ContentGapResult {
  const { niche, mainTopic, platform, targetAudience } = data;

  return {
    isAiAnalysis: false,
    disclaimer: AI_DISCLAIMER,
    coveredAngles: [
      `Generic high-level overviews of what ${mainTopic} is`,
      `Over-promising "get rich / grow overnight" surface-level hooks`,
      `Basic tool roundups listing the same 5 popular platforms`,
      `Theory-heavy explanations without showing real behind-the-scenes failures`,
    ],
    unansweredQuestions: [
      `What does daily execution actually look like for ${targetAudience}?`,
      `How do you recover when your strategy for ${mainTopic} completely stalls?`,
      `What are the hidden operational costs nobody warns you about?`,
      `Can beginners succeed with ${mainTopic} without paid ads or prior audience?`,
    ],
    underservedAngles: [
      {
        angle: `The "Uncomfortable Reality" Audit: Real Costs & Timelines`,
        whyUseful: `Most content paints an idealized picture. Transparent breakdown of real timelines and bottlenecks builds immense credibility and viewer trust.`,
        suggestedTitleHook: `The $0 vs $1,000 Reality of ${mainTopic} in 2026 (No Fluff)`,
        contentIdea: `Itemize the exact financial, time, and emotional investments required to get started in ${mainTopic}, comparing realistic results at 30, 90, and 180 days.`,
        opportunityScore: 92,
        scoreReasoning: `High search intent paired with high audience skepticism toward generic "get results fast" videos creates an underserved demand for candid financial transparency.`,
      },
      {
        angle: `Troubleshooting Guide: Fixing When It Doesn't Work`,
        whyUseful: `Almost all videos cover how to start, but virtually zero creators explain how to diagnose and fix a broken campaign, product, or workflow.`,
        suggestedTitleHook: `Why Your ${mainTopic} Is Failing (And How to Fix It in 48 Hours)`,
        contentIdea: `Provide a 4-part decision tree diagram showing where ${targetAudience} is most likely dropping off and the exact calibration to fix each error.`,
        opportunityScore: 88,
        scoreReasoning: `Users searching for diagnostic help have higher retention and save rates because they are actively experiencing friction.`,
      },
      {
        angle: `Day-in-the-Life Workflow Case Study`,
        whyUseful: `Tactical implementation beats theoretical advice. Showing the exact tools, tabs, and keyboard shortcuts bridges the gap between knowledge and action.`,
        suggestedTitleHook: `Watch Me Execute ${mainTopic} From Scratch (Full Unedited Workflow)`,
        contentIdea: `A screen-recorded, timestamped deep-dive revealing the actual raw notes, drafts, or operational setup without jump-cutting the hard parts.`,
        opportunityScore: 84,
        scoreReasoning: `Audience comments routinely ask "show us the actual screen", yet creators avoid it due to editing effort, leaving a major content vacuum.`,
      },
      {
        angle: `Micro-Skill Deep Dive (Zooming into 1 specific phase)`,
        whyUseful: `Broad "complete guides" overwhelm audiences. Isolating one specific high-friction milestone makes the content instantly consumable and actionable.`,
        suggestedTitleHook: `The Only 5 Minutes of ${mainTopic} That Actually Matters`,
        contentIdea: `Focus 100% on the single highest-leverage inflection point (e.g. initial onboarding, research phase, or closing pitch) with template downloads.`,
        opportunityScore: 81,
        scoreReasoning: `Short, ultra-focused tactical guides on ${platform} earn higher completion rates than generic 20-minute overviews.`,
      },
    ],
  };
}

export async function fetchContentGap(data: ContentGapFormData): Promise<ContentGapResult> {
  try {
    const res = await fetch('/api/creator/content-gap', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }

    const json = await res.json();
    return {
      coveredAngles: json.coveredAngles,
      unansweredQuestions: json.unansweredQuestions,
      underservedAngles: json.underservedAngles,
      disclaimer: AI_DISCLAIMER,
      isAiAnalysis: true,
    };
  } catch (err) {
    console.warn('Using local fallback for Content Gap Finder:', err);
    return getLocalContentGapFallback(data);
  }
}

// ==========================================
// 3. HOOK DOCTOR SERVICE & FALLBACK
// ==========================================
export function getLocalHookDoctorFallback(data: HookDoctorFormData): HookDoctorResult {
  const { videoTopic, currentHook, videoFormat, targetAudience } = data;
  const hookClean = currentHook.trim() || `In this video I am going to talk about ${videoTopic}`;

  return {
    isAiAnalysis: false,
    disclaimer: AI_DISCLAIMER,
    analysis: {
      strengths: `The topic "${videoTopic}" has clear conceptual interest and addresses an identifiable challenge for ${targetAudience}.`,
      weaknesses: `The opening phrase relies on passive phrasing ("${hookClean.slice(0, 45)}..."). It delays the emotional payoff, lacks immediate stakes, and gives the viewer permission to swipe away within the first 1.5 seconds.`,
      retentionRiskFactors: [
        'Delayed premise: Takes more than 3 seconds before establishing what is at risk.',
        'Audience friction: Uses introspective or greeting language instead of immediate curiosity stimulus.',
        'Low visual curiosity: Does not imply a counter-intuitive outcome or dramatic before/after transformation.',
      ],
    },
    firstThreeSecondsCue: {
      visualAction: `Start already mid-action (e.g., holding a red marker over a whiteboard, showing a failed dashboard with high red numbers, or slamming a physical notebook onto a desk).`,
      audioSpokenCue: `No greeting ("Hey guys"), no intro song. Begin speaking on the very first frame with high vocal inflection on the key contrast word.`,
      textOnScreen: `Bold high-contrast subtitle on screen: "THIS MISTAKE COST ME 6 MONTHS." (Word-by-word animation)`,
    },
    improvedHooks: [
      {
        type: 'Curiosity-Based (The Unspoken Secret)',
        hookText: `There is a reason 90% of ${targetAudience} quit ${videoTopic} before seeing any results, and it's not what you think.`,
        whyItWorks: `Implies insider knowledge and challenges common assumptions, forcing the brain to seek closure by watching further.`,
        suggestedPacing: `Fast opening, slight 0.5s pause after "not what you think" to let tension land.`,
      },
      {
        type: 'Educational (High Stakes Transformation)',
        hookText: `If you want to master ${videoTopic}, stop following the 2024 rulebook. Here is the exact 3-step protocol that works right now.`,
        whyItWorks: `Creates urgent relevance by signaling outdated knowledge, positioning you as an up-to-date authority figure.`,
        suggestedPacing: `Crisp, authoritative tempo with on-screen numbered bullets appearing sequentially.`,
      },
      {
        type: 'Story-Based (Vulnerable Proof)',
        hookText: `Two years ago, I almost threw away my entire strategy for ${videoTopic}. Until I realized one tiny math error that changed everything.`,
        whyItWorks: `Human narrative disarms skepticism and creates empathy; audiences crave the resolution to personal struggle.`,
        suggestedPacing: `Slightly more intimate cadence, accompanied by visual evidence (old screenshot or timeline).`,
      },
      {
        type: 'Short-Form Punchy (Pattern Interrupt)',
        hookText: `Delete this from your ${videoTopic} checklist immediately.`,
        whyItWorks: `Loss aversion is 2x more psychologically compelling than gain. Telling someone to delete something triggers immediate defensive attention.`,
        suggestedPacing: `Aggressive, under 2 seconds total, quick cut immediately to the item being crossed out.`,
      },
      {
        type: 'Visual & Comparative (A/B Test Contrast)',
        hookText: `This side took 10 hours. This side took 4 minutes. Let me show you what happened when I tested ${videoTopic}.`,
        whyItWorks: `Extreme contrast provides immediate visual payoff and hooks the viewer's desire for efficiency.`,
        suggestedPacing: `Snappy side-by-side split screen with finger pointing left then right.`,
      },
    ],
  };
}

export async function fetchHookDoctor(data: HookDoctorFormData): Promise<HookDoctorResult> {
  try {
    const res = await fetch('/api/creator/hook-doctor', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }

    const json = await res.json();
    return {
      analysis: json.analysis,
      firstThreeSecondsCue: json.firstThreeSecondsCue,
      improvedHooks: json.improvedHooks,
      disclaimer: AI_DISCLAIMER,
      isAiAnalysis: true,
    };
  } catch (err) {
    console.warn('Using local fallback for Hook Doctor:', err);
    return getLocalHookDoctorFallback(data);
  }
}

// ==========================================
// 4. VIDEO PERFORMANCE DOCTOR SERVICE & FALLBACK
// ==========================================
export function getLocalVideoPerformanceFallback(data: VideoPerformanceFormData): VideoPerformanceResult {
  const views = Number(data.views) || 1;
  const likes = Number(data.likes) || 0;
  const comments = Number(data.comments) || 0;
  const shares = Number(data.shares) || 0;
  const totalEngagements = likes + comments + shares;

  const likeToViewRatio = Math.round((likes / views) * 1000) / 10;
  const commentRatio = Math.round((comments / views) * 1000) / 10;
  const shareRatio = Math.round((shares / views) * 1000) / 10;
  const totalEngagementRate = Math.round((totalEngagements / views) * 1000) / 10;

  const avgPct = Number(data.averagePercentageViewed) || 0;
  const ctrVal = Number(data.ctr) || 0;

  return {
    isAiAnalysis: false,
    disclaimer: AI_DISCLAIMER,
    calculations: {
      likeToViewRatio,
      commentRatio,
      shareRatio,
      totalEngagementRate,
      estimatedRetentionRate: avgPct || undefined,
    },
    performanceObservations: `Based on your submitted metrics for this video (${views.toLocaleString()} views, ${likes.toLocaleString()} likes, ${comments.toLocaleString()} comments, ${shares.toLocaleString()} shares): The like-to-view ratio is ${likeToViewRatio}% and comment ratio is ${commentRatio}%. This indicates your audience finds resonance in the subject, but engagement depth can be amplified with clearer mid-video interaction triggers.`,
    possibleStrengths: [
      likeToViewRatio >= 5
        ? `Strong initial resonance: A ${likeToViewRatio}% like ratio shows viewers who completed the opening felt the content was worth acknowledging.`
        : `Baseline viewer validation: Audience acknowledges the core value proposition of your topic.`,
      shares > 0
        ? `Utility-driven shareability: Generating ${shares.toLocaleString()} shares indicates the content contained information worth passing to peers or saving.`
        : `Clear topic relevance to your existing follower base.`,
      comments > 0
        ? `Active audience discussion: Receiving ${comments.toLocaleString()} comments proves the topic sparked curiosity or opinions.`
        : `Clean presentation style without visible high-friction backlash.`,
    ],
    possibleWeaknesses: [
      avgPct > 0 && avgPct < 40
        ? `Mid-video drop-off: An average retention of ${avgPct}% suggests viewer drop-off occurring before the main climax or payoff.`
        : `Pacing drag: Transitions between points may linger longer than necessary for current short-attention audiences.`,
      commentRatio < 0.5
        ? `Low conversation prompt: A ${commentRatio}% comment ratio indicates you didn't leave a clear, specific question or debate prompt for the viewer.`
        : `Soft call to action: Viewers consumed the content passively without a compelling reason to follow or bookmark.`,
      ctrVal > 0 && ctrVal < 4
        ? `Click-through friction: A ${ctrVal}% CTR implies the thumbnail or title didn't create enough contrast against competing feed items.`
        : `Delayed hook payoff: The first 5 seconds may have summarized rather than teased the forthcoming value.`,
    ],
    reachObservations: ctrVal > 0
      ? `Your CTR is currently at ${ctrVal}%. On ${data.platform}, videos with strong concept contrast typically aim for 4.5% to 8% CTR. Testing more emotive, uncluttered visual hooks can expand discovery impressions.`
      : `Impressions distribution on ${data.platform} is heavily dictated by initial 3-second hold rate. A higher like-to-view ratio signals positive algorithmic sentiment, but share velocity is the primary multiplier.`,
    retentionObservations: avgPct > 0
      ? `Your average percentage viewed of ${avgPct}% provides a clear diagnostic signal. Retaining >60% on short-form or >45% on long-form is the benchmark where algorithmic recommendation engines start pushing content into broad explore feeds.`
      : `Watch time is the single largest determinant of reach. If viewers leave early, the platform limits external discovery impressions to preserve user session length.`,
    practicalSuggestions: [
      `Cut the first 2 seconds: Remove any introductory greeting, logo animation, or filler words. Start on frame 1 with the central tension.`,
      `Add dynamic B-roll or visual changes every 3 to 4 seconds: Change camera angles, insert zooms, or display visual annotations to reset the viewer's micro-attention span.`,
      `Replace generic CTAs with an open-ended binary question: Instead of "Like and follow for more", ask "Would you use Method A or Method B in this situation? Let me know below."`,
    ],
    nextVideoRecommendations: [
      `Create a direct "Part 2" or spin-off addressing the #1 most upvoted comment or objection from this video.`,
      `Test a provocative curiosity hook using the exact inverse angle of this topic (e.g. "Why doing X actually ruined my results").`,
      `Shorten the total duration by 20% while delivering the identical value to boost your average percentage viewed.`,
    ],
  };
}

export async function fetchVideoPerformance(data: VideoPerformanceFormData): Promise<VideoPerformanceResult> {
  try {
    const res = await fetch('/api/creator/video-performance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }

    const json = await res.json();
    return {
      calculations: json.calculations,
      performanceObservations: json.performanceObservations,
      possibleStrengths: json.possibleStrengths,
      possibleWeaknesses: json.possibleWeaknesses,
      reachObservations: json.reachObservations,
      retentionObservations: json.retentionObservations,
      practicalSuggestions: json.practicalSuggestions,
      nextVideoRecommendations: json.nextVideoRecommendations,
      disclaimer: AI_DISCLAIMER,
      isAiAnalysis: true,
    };
  } catch (err) {
    console.warn('Using local fallback for Video Performance Doctor:', err);
    return getLocalVideoPerformanceFallback(data);
  }
}

// ==========================================
// 5. SMART HASHTAG & KEYWORD MIXER SERVICE & FALLBACK
// ==========================================
export function getLocalHashtagMixerFallback(data: HashtagMixerFormData): HashtagMixerResult {
  const { platform, topic, niche, targetCountry, contentType } = data;
  const cleanTopic = topic.replace(/[^a-zA-Z0-9]/g, '');
  const cleanNiche = niche.replace(/[^a-zA-Z0-9]/g, '');

  const broadHashtags = [
    `#${cleanNiche}`,
    `#${cleanNiche}Tips`,
    `#ContentCreator`,
    `#DigitalMarketing`,
    `#CreatorEconomy`,
    `#OnlineBusiness`,
  ];

  const nicheHashtags = [
    `#${cleanTopic}`,
    `#${cleanNiche}Strategy`,
    `#${cleanTopic}Tutorial`,
    `#${cleanNiche}Community`,
    `#Learn${cleanNiche}`,
    `#${cleanNiche}Growth`,
  ];

  const specificHashtags = [
    `#HowTo${cleanTopic}`,
    `#${cleanTopic}Hacks`,
    `#${cleanTopic}Tools`,
    `#${cleanTopic}ForBeginners`,
    `#${cleanNiche}In${targetCountry.replace(/\s+/g, '') || '2026'}`,
  ];

  const searchKeywords = [
    `${topic} tutorial for beginners`,
    `how to improve ${topic}`,
    `best ${niche} tools ${targetCountry}`,
    `${topic} checklist ${contentType}`,
    `easy way to learn ${topic}`,
    `${niche} step by step guide`,
  ];

  const longTailKeywords = [
    `is ${topic} still worth it for ${cleanNiche} creators`,
    `how to master ${topic} without spending money`,
    `the biggest mistake people make with ${topic}`,
    `step by step ${topic} routine for beginners`,
  ];

  const captionKeywords = [
    `workflow`,
    `framework`,
    `step-by-step`,
    `strategy`,
    `checklist`,
    `optimization`,
    `results`,
    `actionable`,
  ];

  const suggestedCombinations = [
    {
      title: 'Balanced High-Conversion Mix (3 Broad + 3 Niche + 2 Specific)',
      description: 'Ideal for Instagram and TikTok feeds seeking discovery while keeping topical relevance tight.',
      tags: [broadHashtags[0], broadHashtags[1], nicheHashtags[0], nicheHashtags[1], nicheHashtags[2], specificHashtags[0], specificHashtags[1]],
      readyText: `${broadHashtags[0]} ${broadHashtags[1]} ${nicheHashtags[0]} ${nicheHashtags[1]} ${nicheHashtags[2]} ${specificHashtags[0]} ${specificHashtags[1]}`,
    },
    {
      title: 'SEO Long-Tail Search Cocktail',
      description: 'Optimized for search discovery, recommended video carousels, and search bar queries.',
      tags: [nicheHashtags[0], nicheHashtags[1], specificHashtags[0], specificHashtags[2], specificHashtags[3]],
      readyText: `${nicheHashtags[0]} ${nicheHashtags[1]} ${specificHashtags[0]} ${specificHashtags[2]} ${specificHashtags[3]}`,
    },
    {
      title: 'Minimalist Clean Cluster (Top 4 Tags)',
      description: 'Clean aesthetic for LinkedIn, YouTube Shorts, or understated caption signatures.',
      tags: [broadHashtags[0], nicheHashtags[0], specificHashtags[0], `#CreatorCommunity`],
      readyText: `${broadHashtags[0]} ${nicheHashtags[0]} ${specificHashtags[0]} #CreatorCommunity`,
    },
  ];

  return {
    isAiAnalysis: false,
    disclaimer: AI_DISCLAIMER,
    broadHashtags,
    nicheHashtags,
    specificHashtags,
    searchKeywords,
    longTailKeywords,
    captionKeywords,
    suggestedCombinations,
  };
}

export async function fetchHashtagMixer(data: HashtagMixerFormData): Promise<HashtagMixerResult> {
  try {
    const res = await fetch('/api/creator/hashtag-mixer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }

    const json = await res.json();
    return {
      broadHashtags: json.broadHashtags,
      nicheHashtags: json.nicheHashtags,
      specificHashtags: json.specificHashtags,
      searchKeywords: json.searchKeywords,
      longTailKeywords: json.longTailKeywords,
      captionKeywords: json.captionKeywords,
      suggestedCombinations: json.suggestedCombinations,
      disclaimer: AI_DISCLAIMER,
      isAiAnalysis: true,
    };
  } catch (err) {
    console.warn('Using local fallback for Hashtag Mixer:', err);
    return getLocalHashtagMixerFallback(data);
  }
}

// ==========================================
// 6. CONTENT EXPERIMENT GENERATOR SERVICE & FALLBACK
// ==========================================
export function getLocalContentExperimentFallback(data: ContentExperimentFormData): ContentExperimentResult {
  const { originalIdea, platform, audience, contentFormat, goal } = data;

  return {
    isAiAnalysis: false,
    disclaimer: AI_DISCLAIMER,
    experimentA: {
      name: 'Curiosity & Pattern-Interrupt Angle',
      hook: `Stop doing this immediately if you care about ${originalIdea}.`,
      title: `The 1 Fatal Flaw In Your ${originalIdea} Strategy`,
      contentAngle: `Highlight the counter-intuitive mistake almost everyone in ${audience} commits daily. Reveal the hidden cost and show how flipping the process yields superior output.`,
      cta: `Share this with someone who needs to hear this truth today. Did you fall for this too?`,
      hypothesis: `Testing a negative-constraint curiosity hook provokes defensive attention and generates high initial watch-time retention.`,
    },
    experimentB: {
      name: 'Educational Framework & Actionable Checklist',
      hook: `Here is the exact 4-step framework I use to master ${originalIdea} in under 15 minutes.`,
      title: `The Complete No-Fluff Blueprint for ${originalIdea}`,
      contentAngle: `Step-by-step breakdown using numbered chapters, clear on-screen graphics, and zero fluff. Treat the video as a concise masterclass designed to be referenced repeatedly.`,
      cta: `Save this post right now so you can reference the 4-step checklist during your next project.`,
      hypothesis: `High-density utility content drives above-average bookmark/save rates, which algorithms interpret as evergreen quality signals.`,
    },
    experimentC: {
      name: 'Storytelling, Case Study & Vulnerability',
      hook: `I spent 30 days testing ${originalIdea} so you don't have to make my mistakes. Here is what actually happened.`,
      title: `My Honest 30-Day Reality With ${originalIdea}`,
      contentAngle: `Take the viewer along a chronological journey: the initial expectation, the unexpected obstacle in week two, the breakthrough adjustment, and final tangible metrics.`,
      cta: `Drop a comment with your biggest hurdle with ${originalIdea} and I'll reply with custom advice.`,
      hypothesis: `Personal narratives disarm ad-fatigue, dramatically elevate comment velocity, and foster strong subscriber loyalty.`,
    },
    testingGuidelines: [
      `Keep the core value/lesson identical across all 3 videos; only vary the packaging (opening hook, visual pacing, and title).`,
      `Space each experiment release at least 4 to 7 days apart so audience feedback does not cannibalize initial feed recommendations.`,
      `Track your 3-second retention percentage and share-to-view ratio across all 3 to find your audience's favorite narrative format.`,
    ],
  };
}

export async function fetchContentExperiment(data: ContentExperimentFormData): Promise<ContentExperimentResult> {
  try {
    const res = await fetch('/api/creator/content-experiment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }

    const json = await res.json();
    return {
      experimentA: json.experimentA,
      experimentB: json.experimentB,
      experimentC: json.experimentC,
      testingGuidelines: json.testingGuidelines,
      disclaimer: AI_DISCLAIMER,
      isAiAnalysis: true,
    };
  } catch (err) {
    console.warn('Using local fallback for Content Experiment Generator:', err);
    return getLocalContentExperimentFallback(data);
  }
}
