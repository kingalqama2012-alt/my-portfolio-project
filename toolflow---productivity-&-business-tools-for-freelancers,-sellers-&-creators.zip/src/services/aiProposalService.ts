import { ProposalFormData } from '../types';

export interface ProposalResult {
  proposal: string;
  isGemini: boolean;
}

export function generateLocalProposalFallback(data: ProposalFormData): string {
  const { jobTitle, clientRequirements, yourSkills, experience, projectBudget, tone } = data;

  const toneAdjectives: Record<string, { intro: string; signoff: string }> = {
    Professional: {
      intro: `I am writing to express my strong interest in your project for "${jobTitle}". Having reviewed your specifications, I am confident in delivering a solution that aligns strictly with your operational goals.`,
      signoff: 'I look forward to discussing how we can achieve your target milestones.',
    },
    Friendly: {
      intro: `Hi there! I came across your project for "${jobTitle}" and couldn't resist reaching out. Your vision for this project immediately resonated with the kind of high-impact work I love doing.`,
      signoff: "Let's connect for a quick 15-minute chat whenever works best for your schedule!",
    },
    Persuasive: {
      intro: `If you are looking for a reliable specialist who can take full ownership of "${jobTitle}" and deliver immediate ROI without handholding, here is why my track record fits your criteria.`,
      signoff: 'I am ready to kick off this week and guarantee dedicated attention to your deliverables.',
    },
    Short: {
      intro: `Hi, I saw your post for "${jobTitle}". Based on your criteria, I can deliver this cleanly within your desired timeframe.`,
      signoff: 'Available to begin immediately. Let me know when you would like to review references.',
    },
  };

  const selectedTone = toneAdjectives[tone] || toneAdjectives.Professional;
  const budgetSnippet = projectBudget && projectBudget.trim()
    ? `\n- Proposed Investment: ${projectBudget} (inclusive of milestones, revisions, and deployment)`
    : '\n- Investment: Based on final scoping, aligned with competitive industry standards.';

  return `Dear Hiring Manager,

${selectedTone.intro}

### Understanding Your Project & Objectives
From your project brief:
> "${clientRequirements}"

To make this a complete success, the solution needs to be robust, modern, and deliver measurable business outcomes from day one.

### Why I Am the Right Fit
- Relevant Experience: ${experience}
- Core Technical / Strategic Skills: ${yourSkills}
- Proven Workflow: Clear milestone check-ins, proactive communication, and pristine documentation.

### Scope of Work & Deliverables
1. Discovery & Requirement Alignment: Detailed scoping and roadmap confirmation.
2. Architecture & Production: Iterative milestone delivery with regular review cycles.
3. Quality Assurance & Refinement: Rigorous testing against your specific requirements.
4. Launch Support & Post-Delivery Handover: Clean documentation and video walkthrough.

### Proposed Timeline & Terms${budgetSnippet}
- Estimated Timeline: Realistic sprint milestones with bi-weekly demonstrations.
- Guarantee: Revisions included until your stated acceptance criteria are satisfied.

${selectedTone.signoff}

Best regards,
Alex Morgan
Independent Specialist`;
}

export async function generateProposal(
  data: ProposalFormData,
  allowFallback = false
): Promise<ProposalResult> {
  try {
    const res = await fetch('/api/generate-proposal', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    const json = await res.json();

    if (!res.ok) {
      if (allowFallback) {
        return {
          proposal: generateLocalProposalFallback(data),
          isGemini: false,
        };
      }
      throw new Error(json.error || 'Gemini API call failed.');
    }

    return {
      proposal: json.proposal,
      isGemini: true,
    };
  } catch (error: any) {
    if (allowFallback) {
      return {
        proposal: generateLocalProposalFallback(data),
        isGemini: false,
      };
    }
    throw error;
  }
}
