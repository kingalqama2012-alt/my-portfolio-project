import { ToolItem } from '../types';

export const TOOLS: ToolItem[] = [
  {
    id: 'proposal-generator',
    name: 'AI Proposal Generator',
    shortDescription: 'Craft tailored freelance bids, pitches, and winning client proposals in seconds.',
    description: 'Create customized client proposals calibrated to your exact project scope, rate, tone, and portfolio highlights.',
    category: 'freelancer',
    categoryLabel: 'Freelancers',
    path: '/tools/proposal-generator',
    iconName: 'FileText',
    badge: 'AI Powered',
    featured: true,
    popular: true,
  },
  {
    id: 'freelancer-rate-calculator',
    name: 'Freelancer Rate Calculator',
    shortDescription: 'Calculate your ideal billable hourly rate based on desired income, expenses, and taxes.',
    description: 'Accurately price your services taking into account non-billable hours, self-employment tax, overhead, and profit margins.',
    category: 'freelancer',
    categoryLabel: 'Freelancers',
    path: '/tools/freelancer-rate-calculator',
    iconName: 'Calculator',
    badge: 'Finance',
    featured: false,
    popular: true,
  },
  {
    id: 'amazon-profit-calculator',
    name: 'Amazon Profit Calculator',
    shortDescription: 'Estimate FBA fees, net margins, ROI, and real unit profitability before sourcing.',
    description: 'Input your sourcing, FBA fulfillment, referral, and advertising expenses to compute real net margins and return on investment.',
    category: 'amazon',
    categoryLabel: 'Amazon Sellers',
    path: '/tools/amazon-profit-calculator',
    iconName: 'TrendingUp',
    badge: 'FBA & FBM',
    featured: true,
    popular: true,
  },
  {
    id: 'amazon-ppc-calculator',
    name: 'Amazon PPC / ACOS Calculator',
    shortDescription: 'Audit your ad spend, ACOS, TACOS, and ROAS with actionable performance benchmarks.',
    description: 'Diagnose campaign efficiency, evaluate total ad impact on organic rank, and identify budget optimization thresholds.',
    category: 'amazon',
    categoryLabel: 'Amazon Sellers',
    path: '/tools/amazon-ppc-calculator',
    iconName: 'BarChart3',
    badge: 'Analytics',
    featured: false,
    popular: true,
  },
  {
    id: 'amazon-keyword-generator',
    name: 'Amazon Keyword Generator',
    shortDescription: 'Discover high-intent buyer keywords, backend search terms, and long-tail variants.',
    description: 'Generate comprehensive keyword clusters for product title, bullet points, backend search terms, and PPC campaigns.',
    category: 'amazon',
    categoryLabel: 'Amazon Sellers',
    path: '/tools/amazon-keyword-generator',
    iconName: 'Search',
    badge: 'SEO & PPC',
    featured: false,
    popular: false,
  },
  {
    id: 'social-caption-generator',
    name: 'Social Caption Generator',
    shortDescription: 'Generate platform-optimized hooks, captions, and hashtags for Instagram, TikTok & more.',
    description: 'Create engaging multi-platform captions with targeted call-to-actions, tone selection, and optimal character limits.',
    category: 'creator',
    categoryLabel: 'Creators',
    path: '/tools/social-caption-generator',
    iconName: 'Sparkles',
    badge: 'Multi-Platform',
    featured: true,
    popular: true,
  },
  {
    id: 'engagement-calculator',
    name: 'Engagement Rate Calculator',
    shortDescription: 'Calculate true engagement percentage across likes, comments, shares, and saves.',
    description: 'Benchmark content performance against creator industry standards with total engagement metrics and formula breakdowns.',
    category: 'creator',
    categoryLabel: 'Creators',
    path: '/tools/engagement-calculator',
    iconName: 'Share2',
    badge: 'Audience',
    featured: false,
    popular: false,
  },
  {
    id: 'trend-radar',
    name: 'Trend Radar',
    shortDescription: 'Discover rising topic opportunities, content angles, search queries, and formats for your niche.',
    description: 'AI-assisted topic discovery engine mapping emerging themes, video concepts, and audience search interest.',
    category: 'creator',
    categoryLabel: 'Creators',
    path: '/tools/creator/trend-radar',
    iconName: 'Radar',
    badge: 'AI Research',
    featured: true,
    popular: true,
  },
  {
    id: 'content-gap-finder',
    name: 'Content Gap Finder',
    shortDescription: 'Uncover underserved angles and unanswered audience questions that competitors miss.',
    description: 'Identify high-opportunity content vacuums with AI estimated opportunity scores and tailored hook suggestions.',
    category: 'creator',
    categoryLabel: 'Creators',
    path: '/tools/creator/content-gap-finder',
    iconName: 'Target',
    badge: 'Opportunity',
    featured: true,
    popular: true,
  },
  {
    id: 'hook-doctor',
    name: 'Hook Doctor',
    shortDescription: 'Diagnose opening retention leaks and craft 5 high-converting hook variants for your video.',
    description: 'Analyze first-sentence weakness, pattern-interrupts, and generate curiosity, story, educational, and punchy hooks.',
    category: 'creator',
    categoryLabel: 'Creators',
    path: '/tools/creator/hook-doctor',
    iconName: 'Stethoscope',
    badge: 'Retention',
    featured: true,
    popular: true,
  },
  {
    id: 'video-performance-doctor',
    name: 'Video Performance Doctor',
    shortDescription: 'Analyze video metrics, watch time, CTR, and receive practical diagnostic improvements.',
    description: 'Diagnostic performance audit comparing engagement ratios, retention drop-offs, and next-video fixes.',
    category: 'creator',
    categoryLabel: 'Creators',
    path: '/tools/creator/video-performance-doctor',
    iconName: 'Activity',
    badge: 'Diagnostics',
    featured: false,
    popular: true,
  },
  {
    id: 'hashtag-keyword-mixer',
    name: 'Smart Hashtag & Keyword Mixer',
    shortDescription: 'Blend broad, niche, and long-tail keywords into algorithm-ready copy and search tags.',
    description: 'Generate multi-tier hashtag cocktails and natural in-caption SEO search keywords for discoverability.',
    category: 'creator',
    categoryLabel: 'Creators',
    path: '/tools/creator/hashtag-keyword-mixer',
    iconName: 'Hash',
    badge: 'SEO Mix',
    featured: false,
    popular: true,
  },
  {
    id: 'content-experiment-generator',
    name: 'Content Experiment Generator',
    shortDescription: 'Transform 1 core idea into 3 structured A/B/C testing variations with distinct hooks & CTAs.',
    description: 'Generate curiosity, educational, and storytelling experiment blueprints to systematically test content styles.',
    category: 'creator',
    categoryLabel: 'Creators',
    path: '/tools/creator/content-experiment-generator',
    iconName: 'FlaskConical',
    badge: 'A/B Testing',
    featured: false,
    popular: true,
  },
];

export const CATEGORIES = [
  {
    id: 'freelancer',
    name: 'Freelancer Tools',
    slug: 'freelancers',
    description: 'Tools to help freelancers win clients, manage projects, and grow their business.',
    iconName: 'Briefcase',
    toolCount: 2,
    accentColor: 'indigo',
    tagline: 'Win more deals & protect your revenue',
    tools: ['proposal-generator', 'freelancer-rate-calculator'],
  },
  {
    id: 'amazon',
    name: 'Amazon Seller Tools',
    slug: 'amazon',
    description: 'Tools for Amazon sellers to understand profitability, PPC, keywords, and listings.',
    iconName: 'ShoppingBag',
    toolCount: 3,
    accentColor: 'amber',
    tagline: 'Optimize margins, ACOS & ranking keywords',
    tools: ['amazon-profit-calculator', 'amazon-ppc-calculator', 'amazon-keyword-generator'],
  },
  {
    id: 'creator',
    name: 'Creator Tools',
    slug: 'creators',
    description: 'AI-assisted research, hook diagnostics, content gap analysis, and performance tools for creators.',
    iconName: 'Video',
    toolCount: 8,
    accentColor: 'rose',
    tagline: 'Discover trends, fix hooks, find gaps & analyze retention',
    tools: [
      'trend-radar',
      'content-gap-finder',
      'hook-doctor',
      'video-performance-doctor',
      'hashtag-keyword-mixer',
      'content-experiment-generator',
      'social-caption-generator',
      'engagement-calculator',
    ],
  },
];

// The 6 dedicated Creator Tools requested for prominent display
export const CREATOR_TOOLS_IDS = [
  'trend-radar',
  'content-gap-finder',
  'hook-doctor',
  'video-performance-doctor',
  'hashtag-keyword-mixer',
  'content-experiment-generator',
];

/**
 * Robust local search matching function that handles:
 * - Tool names
 * - Categories (e.g. "amazon", "creator", "freelancer")
 * - Specific keywords / aliases (e.g. "ppc", "proposal", "hashtags", "hooks", "trends")
 * - Descriptions & Badges
 */
export function matchesToolSearch(tool: ToolItem, rawQuery: string): boolean {
  const query = rawQuery.toLowerCase().trim();
  if (!query) return true;

  // Domain keywords & synonyms map
  const keywordMap: Record<string, string[]> = {
    amazon: ['amazon', 'fba', 'fbm', 'seller', 'asin', 'listing', 'store'],
    ppc: ['ppc', 'acos', 'tacos', 'roas', 'ad spend', 'ad cost', 'advertising', 'campaign'],
    proposal: ['proposal', 'proposals', 'pitch', 'pitches', 'bid', 'bids', 'client', 'contract'],
    creator: [
      'creator',
      'creators',
      'influencer',
      'video',
      'youtube',
      'tiktok',
      'reels',
      'instagram',
      'social media',
      'content',
    ],
    hashtags: ['hashtag', 'hashtags', 'tag', 'tags', 'keyword mixer', 'mixer', 'seo tags'],
    hashtag: ['hashtag', 'hashtags', 'tag', 'tags', 'keyword mixer', 'mixer', 'seo tags'],
    hooks: ['hook', 'hooks', 'hook doctor', 'first 3 seconds', 'opening', 'retention', 'intro'],
    hook: ['hook', 'hooks', 'hook doctor', 'first 3 seconds', 'opening', 'retention', 'intro'],
    trends: ['trend', 'trends', 'trend radar', 'radar', 'trending', 'topics', 'viral', 'demand'],
    trend: ['trend', 'trends', 'trend radar', 'radar', 'trending', 'topics', 'viral', 'demand'],
    gap: ['gap', 'content gap', 'vacuum', 'underserved', 'opportunity', 'questions'],
    gaps: ['gap', 'content gap', 'vacuum', 'underserved', 'opportunity', 'questions'],
    doctor: ['doctor', 'performance doctor', 'hook doctor', 'diagnose', 'audit', 'analytics'],
    experiment: ['experiment', 'experiments', 'a/b', 'split test', 'testing', 'variations'],
    rate: ['rate', 'pricing', 'hourly', 'salary', 'income', 'expenses', 'tax'],
    profit: ['profit', 'margin', 'roi', 'fba fee', 'net profit', 'unit profitability'],
    keyword: ['keyword', 'keywords', 'search terms', 'seo', 'backend terms'],
    keywords: ['keyword', 'keywords', 'search terms', 'seo', 'backend terms'],
    caption: ['caption', 'captions', 'copy', 'social caption', 'posts'],
    captions: ['caption', 'captions', 'copy', 'social caption', 'posts'],
    engagement: ['engagement', 'likes', 'comments', 'shares', 'calculator', 'saves'],
  };

  const toolHaystack = [
    tool.name,
    tool.shortDescription,
    tool.description,
    tool.category,
    tool.categoryLabel,
    tool.badge || '',
    tool.id,
  ]
    .join(' ')
    .toLowerCase();

  // Direct substring match
  if (toolHaystack.includes(query)) return true;

  // Stem / Singular check
  const singularQuery = query.endsWith('s') && query.length > 3 ? query.slice(0, -1) : query;
  if (toolHaystack.includes(singularQuery)) return true;

  // Synonyms check
  for (const [key, synonyms] of Object.entries(keywordMap)) {
    if (query === key || synonyms.includes(query) || query.includes(key)) {
      if (
        toolHaystack.includes(key) ||
        synonyms.some((syn) => toolHaystack.includes(syn))
      ) {
        return true;
      }
    }
  }

  return false;
}

