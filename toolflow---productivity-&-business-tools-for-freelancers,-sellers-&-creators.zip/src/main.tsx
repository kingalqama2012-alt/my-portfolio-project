// Ensure window.fetch is writable and configurable
if (typeof window !== 'undefined') {
  try {
    const origFetch = window.fetch ? window.fetch.bind(window) : undefined;
    let _fetchRef = origFetch;
    Object.defineProperty(window, 'fetch', {
      get: () => _fetchRef,
      set: (fn) => {
        _fetchRef = fn;
      },
      configurable: true,
      enumerable: true,
    });
  } catch (e) {
    // Non-fatal if already configured
  }
}

import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);

