import { useEffect } from 'react';
import { PRODUCTION_ORIGIN } from './canonicalUrl';

export interface PageSEOOptions {
  title: string;
  description: string;
  canonicalPath: string;
  robots?: string;
  ogType?: 'website' | 'article';
  jsonLdId?: string;
  jsonLd?: object | object[];
}

/**
 * Custom hook to safely manage page-specific SEO metadata across client-side navigation.
 * Updates <title>, <meta name="description">, canonical <link>, <meta name="robots">,
 * and OpenGraph tags in place without creating duplicates, and cleans up JSON-LD scripts on unmount.
 */
export function usePageSEO({
  title,
  description,
  canonicalPath,
  robots = 'index, follow',
  ogType = 'website',
  jsonLdId,
  jsonLd,
}: PageSEOOptions) {
  useEffect(() => {
    const previousTitle = document.title;
    document.title = title;

    // Meta Description: update existing or create if missing
    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    if (metaDesc) {
      metaDesc.setAttribute('content', description);
    } else {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      metaDesc.setAttribute('content', description);
      document.head.appendChild(metaDesc);
    }

    // Canonical Link: strictly format using the production origin
    const canonicalHref = canonicalPath.startsWith('http')
      ? canonicalPath
      : `${PRODUCTION_ORIGIN}${canonicalPath.startsWith('/') ? canonicalPath : `/${canonicalPath}`}`;

    let canonical = document.querySelector('link[rel="canonical"]');
    const prevCanonical = canonical ? canonical.getAttribute('href') : null;
    if (canonical) {
      canonical.setAttribute('href', canonicalHref);
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      canonical.setAttribute('href', canonicalHref);
      document.head.appendChild(canonical);
    }

    // Robots meta tag
    let robotsMeta = document.querySelector('meta[name="robots"]');
    const prevRobots = robotsMeta ? robotsMeta.getAttribute('content') : '';
    if (robotsMeta) {
      robotsMeta.setAttribute('content', robots);
    } else {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      robotsMeta.setAttribute('content', robots);
      document.head.appendChild(robotsMeta);
    }

    // OpenGraph Title & Description
    let ogTitle = document.querySelector('meta[property="og:title"]');
    const prevOgTitle = ogTitle ? ogTitle.getAttribute('content') : '';
    if (ogTitle) ogTitle.setAttribute('content', title);

    let ogDesc = document.querySelector('meta[property="og:description"]');
    const prevOgDesc = ogDesc ? ogDesc.getAttribute('content') : '';
    if (ogDesc) ogDesc.setAttribute('content', description);

    let ogTypeMeta = document.querySelector('meta[property="og:type"]');
    const prevOgType = ogTypeMeta ? ogTypeMeta.getAttribute('content') : '';
    if (ogTypeMeta) ogTypeMeta.setAttribute('content', ogType);

    // JSON-LD Structured Data
    if (jsonLdId && jsonLd) {
      let script = document.getElementById(jsonLdId) as HTMLScriptElement | null;
      if (!script) {
        script = document.createElement('script');
        script.id = jsonLdId;
        script.type = 'application/ld+json';
        document.head.appendChild(script);
      }
      script.text = JSON.stringify(jsonLd);
    }

    return () => {
      document.title = previousTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      if (ogTitle && prevOgTitle) ogTitle.setAttribute('content', prevOgTitle);
      if (ogDesc && prevOgDesc) ogDesc.setAttribute('content', prevOgDesc);
      if (ogTypeMeta && prevOgType) ogTypeMeta.setAttribute('content', prevOgType);
      if (canonical && prevCanonical) {
        canonical.setAttribute('href', prevCanonical);
      }
      if (robotsMeta && prevRobots) {
        robotsMeta.setAttribute('content', prevRobots);
      }
      if (jsonLdId) {
        const existingScript = document.getElementById(jsonLdId);
        if (existingScript) existingScript.remove();
      }
    };
  }, [title, description, canonicalPath, robots, ogType, jsonLdId, JSON.stringify(jsonLd)]);
}
