/**
 * Canonical URL helper and allowlist for ToolFlow.
 * Enforces safe, absolute, self-referencing canonical URLs
 * strictly using the verified production origin and stripping query parameters.
 */

export const PRODUCTION_ORIGIN =
  'https://toolflow-productivity-business-tools-for-fre-0oe4-910688864791.asia-southeast1.run.app';

export const ALLOWED_CANONICAL_PATHS: ReadonlySet<string> = new Set([
  '/',
  '/tools',
  '/tools/proposal-generator',
  '/tools/freelancer-rate-calculator',
  '/tools/amazon-profit-calculator',
  '/tools/amazon-ppc-calculator',
  '/tools/amazon-keyword-generator',
  '/tools/social-caption-generator',
  '/tools/engagement-calculator',
  '/tools/creator/trend-radar',
  '/tools/creator/content-gap-finder',
  '/tools/creator/hook-doctor',
  '/tools/creator/video-performance-doctor',
  '/tools/creator/hashtag-keyword-mixer',
  '/tools/creator/content-experiment-generator',
  '/guides/how-to-calculate-freelance-hourly-rate',
  '/pricing',
  '/about',
  '/privacy',
  '/terms',
  '/contact',
  '/login',
  '/signup',
  '/dashboard',
  '/saved',
  '/settings',
]);

/**
 * Returns a validated, absolute canonical URL for any given requested path or URL.
 * Strips query parameters and hashes, normalizes trailing slashes, and verifies against
 * the safe allowlist. Never constructs canonical URLs from untrusted host headers.
 */
export function getCanonicalUrl(rawPathOrUrl?: string): string {
  if (!rawPathOrUrl || typeof rawPathOrUrl !== 'string') {
    return `${PRODUCTION_ORIGIN}/`;
  }

  try {
    // 1. Strip hash and query parameters
    const withoutHash = rawPathOrUrl.split('#')[0];
    const pathnameOnly = withoutHash.split('?')[0];

    // 2. Collapse repeated slashes and decode safely
    const cleanPath = pathnameOnly.replace(/\/+/g, '/').trim();

    // 3. Normalize trailing slashes (root '/' remains '/', subpaths lose trailing slash)
    const normalized =
      cleanPath.length > 1 && cleanPath.endsWith('/')
        ? cleanPath.slice(0, -1)
        : cleanPath || '/';

    // 4. Match against allowlisted routes
    if (ALLOWED_CANONICAL_PATHS.has(normalized)) {
      return normalized === '/'
        ? `${PRODUCTION_ORIGIN}/`
        : `${PRODUCTION_ORIGIN}${normalized}`;
    }
  } catch {
    // Fall back safely on any parsing error
  }

  // Safe fallback to homepage canonical
  return `${PRODUCTION_ORIGIN}/`;
}

/**
 * Replaces the canonical link tag in an HTML document string to ensure exactly ONE
 * correct, self-referencing canonical tag exists in the raw HTML response.
 */
export function injectCanonicalTag(html: string, canonicalUrl: string): string {
  const canonicalTagRegex = /<link\s+[^>]*rel=["']canonical["'][^>]*\/?>/i;
  const canonicalTag = `<link rel="canonical" href="${canonicalUrl}" />`;

  if (canonicalTagRegex.test(html)) {
    return html.replace(canonicalTagRegex, canonicalTag);
  }

  // If absent, insert before </head>
  return html.replace('</head>', `    ${canonicalTag}\n  </head>`);
}
